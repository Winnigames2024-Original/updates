/* loopcraft — created by Winnigames2024 */

(function(){
'use strict';
const $=id=>document.getElementById(id);
const rnd=(a,b)=>a+Math.random()*(b-a);
const ri=(a,b)=>Math.floor(rnd(a,b+1));
const clamp=(v,a,b)=>v<a?a:v>b?b:v;

/* ================= ITEMS & BLOCKS ================= */
// kind: block | food | tool | misc ; c = color ; solid ; tr=transparent ; hard = hits to break
const I=[];
function def(o){o.id=I.length;I.push(o);return o.id;}
const AIR=def({n:'Воздух',kind:'block',c:[0,0,0],solid:false,tr:true,hide:true});
const STONE=def({n:'Камень',kind:'block',c:[.52,.52,.54],hard:5,drop:'Булыжник'});
const GRASS=def({n:'Дёрн',kind:'block',c:[.38,.62,.28],side:[.45,.35,.22],hard:2,drop:'Земля'});
const DIRT=def({n:'Земля',kind:'block',c:[.45,.35,.22],hard:2});
const COBBLE=def({n:'Булыжник',kind:'block',c:[.42,.42,.44],hard:5});
const PLANK=def({n:'Доски',kind:'block',c:[.66,.52,.32],hard:3});
const SAND=def({n:'Песок',kind:'block',c:[.86,.80,.58],hard:2});
const GRAVEL=def({n:'Гравий',kind:'block',c:[.5,.47,.45],hard:2});
const LOG=def({n:'Бревно',kind:'block',c:[.45,.32,.18],top:[.6,.48,.3],hard:4});
const LEAF=def({n:'Листва',kind:'block',c:[.22,.48,.2],hard:1,tr:true,drop:null,chance:['Яблоко',.12,'Ветка',.25]});
const WATER=def({n:'Вода',kind:'block',c:[.2,.35,.7],solid:false,tr:true,liquid:true,hide:true});
const GLASS=def({n:'Стекло',kind:'block',c:[.8,.9,1],tr:true,hard:1,drop:null});
const COAL=def({n:'Угольная руда',kind:'block',c:[.3,.3,.3],hard:6,drop:'Уголь'});
const IRONORE=def({n:'Железная руда',kind:'block',c:[.6,.5,.45],hard:7,drop:'Железная руда'});
const GOLDORE=def({n:'Золотая руда',kind:'block',c:[.75,.65,.3],hard:7});
const TORCH=def({n:'Факел',kind:'block',c:[.95,.75,.3],solid:false,tr:true,hard:1,light:true});
const BRICK=def({n:'Кирпич',kind:'block',c:[.6,.3,.25],hard:5});
const MOSSY=def({n:'Мшистый булыжник',kind:'block',c:[.35,.45,.33],hard:5});
const BOOK=def({n:'Книжная полка',kind:'block',c:[.55,.4,.25],hard:3});
const CLAY=def({n:'Глина',kind:'block',c:[.62,.64,.7],hard:2});
const SNOW=def({n:'Снег',kind:'block',c:[.93,.95,.98],hard:1});
const ICE=def({n:'Лёд',kind:'block',c:[.7,.85,1],tr:true,hard:2});
// --- новое, чего нет в оригинале ---
const ASH=def({n:'Пепел',kind:'block',c:[.3,.28,.3],hard:1,desc:'Осыпается с домов, которых здесь не было.'});
const VOID=def({n:'Пустотный камень',kind:'block',c:[.08,.06,.12],hard:12,desc:'Свет в нём тонет.'});
const WHISPER=def({n:'Шепчущий кристалл',kind:'block',c:[.55,.7,.95],tr:true,hard:6,light:true,desc:'Если стоять рядом — слышно голоса.'});
const MOSS=def({n:'Мох',kind:'block',c:[.25,.5,.3],hard:1});
const BONE=def({n:'Костяной блок',kind:'block',c:[.88,.86,.78],hard:4,desc:'Из чьих?'});
const AMBER=def({n:'Янтарь',kind:'block',c:[.9,.6,.2],tr:true,hard:4,desc:'Внутри что-то замерло.'});
const SIGIL=def({n:'Знак-камень',kind:'block',c:[.35,.3,.4],hard:8,desc:'На нём выцарапан символ. Не тобой.'});
const MIRROR=def({n:'Зеркальный камень',kind:'block',c:[.75,.8,.9],hard:6,desc:'В отражении на одного больше.'});
const FOGLAMP=def({n:'Туманный фонарь',kind:'block',c:[.6,.85,.8],solid:false,tr:true,hard:1,light:true,desc:'Отгоняет то, что в тумане. Иногда.'});
const LUNAR=def({n:'Лунная руда',kind:'block',c:[.7,.75,.9],hard:8,drop:'Лунная пыль',desc:'Светится только ночью.'});
const RUST=def({n:'Ржавый блок',kind:'block',c:[.55,.3,.18],hard:5});
const DEADWOOD=def({n:'Мёртвое дерево',kind:'block',c:[.35,.3,.28],top:[.42,.38,.35],hard:4,desc:'Листвы у него не было никогда.'});
const SALT=def({n:'Соль',kind:'block',c:[.95,.93,.9],hard:2,desc:'Круг из соли — старая защита.'});
const OBS=def({n:'Тень-стекло',kind:'block',c:[.1,.1,.18],tr:true,hard:10,desc:'Сквозь него видно тех, кого нет.'});
const REDLEAF=def({n:'Багровая листва',kind:'block',c:[.55,.15,.12],tr:true,hard:1,drop:null,chance:['Кровавая ягода',.2]});
const CANDLE=def({n:'Свеча',kind:'block',c:[.95,.9,.7],solid:false,tr:true,hard:1,light:true});
const MUSHB=def({n:'Гриб-великан',kind:'block',c:[.7,.25,.2],hard:2,drop:'Гриб'});
const BED=def({n:'Кровать',kind:'block',c:[.75,.2,.2],top:[.8,.25,.25],hard:2,desc:'ПКМ ночью — проспать до утра.'});
const LADDER=def({n:'Лестница',kind:'block',c:[.6,.45,.25],solid:false,tr:true,hard:1,desc:'Лезь вверх, держа W.'});
const DOORC=def({n:'Дверь',kind:'block',c:[.55,.4,.22],hard:3,desc:'ПКМ — открыть/закрыть.'});
const DOORO=def({n:'Дверь (открыта)',kind:'block',c:[.55,.4,.22],solid:false,tr:true,hard:3,drop:'Дверь',hide:true});
const FENCE=def({n:'Забор',kind:'block',c:[.6,.45,.28],hard:3});
const BOOM=def({n:'Взрывной порошок',kind:'block',c:[.8,.25,.15],top:[.3,.3,.3],hard:1,desc:'Сломай — рванёт через 3 секунды. Отойди.'});
const CHEST=def({n:'Ящик',kind:'block',c:[.6,.42,.2],top:[.5,.35,.18],hard:3,desc:'Декоративный. Пока.'});
const LAMP=def({n:'Лампа',kind:'block',c:[.95,.9,.6],hard:2,light:true});
const TABLE=def({n:'Верстак',kind:'block',c:[.6,.45,.28],top:[.55,.4,.25],hard:3,desc:'ПКМ — крафт 3×3.'});
const BLOCK_COUNT=I.length;
[[STONE,'stone'],[GRASS,'grass'],[DIRT,'dirt'],[COBBLE,'cobblestone'],[PLANK,'planks'],[SAND,'sand'],[GRAVEL,'gravel'],[LOG,'log'],[LEAF,'leaves'],[WATER,'water'],[GLASS,'glass'],[COAL,'coal_ore'],[IRONORE,'iron_ore'],[GOLDORE,'gold_ore'],[TORCH,'torch'],[BRICK,'brick'],[MOSSY,'mossy_cobblestone'],[BOOK,'bookshelf'],[CLAY,'clay'],[SNOW,'snow'],[ICE,'ice'],[ASH,'ash'],[VOID,'void_stone'],[WHISPER,'whisper_crystal'],[MOSS,'moss'],[BONE,'bone_block'],[AMBER,'amber'],[SIGIL,'sigil_stone'],[MIRROR,'mirror_stone'],[FOGLAMP,'fog_lantern'],[LUNAR,'lunar_ore'],[RUST,'rust_block'],[DEADWOOD,'dead_log'],[SALT,'salt'],[OBS,'shadow_glass'],[REDLEAF,'red_leaves'],[CANDLE,'candle'],[MUSHB,'giant_mushroom'],[BED,'bed'],[LADDER,'ladder'],[DOORC,'door'],[DOORO,'door_open'],[FENCE,'fence'],[BOOM,'boom'],[CHEST,'chest'],[LAMP,'lamp'],[TABLE,'crafting_table']].forEach(([id,k])=>I[id].k=k);
/* ================= TEXTURE ATLAS ================= */
const ATLAS=document.createElement('canvas');ATLAS.width=ATLAS.height=256;const AG=ATLAS.getContext('2d');
const TEX={};let texN=0;const texTile=name=>{if(TEX[name]==null){TEX[name]=texN++;}return TEX[name];};
function tileNoise(t,c,alpha,fn){const col=t%16,row=Math.floor(t/16);const im=AG.createImageData(16,16);for(let y=0;y<16;y++)for(let x=0;x<16;x++){let v=0.86+hash2(x+t*31,y+t*17,t)*0.28;let cc=c;let a=alpha==null?255:alpha;if(fn){const r=fn(x,y);if(r){cc=r.c||c;v*=r.v==null?1:r.v;if(r.a!=null)a=r.a;}}const i=(y*16+x)*4;im.data[i]=clamp(cc[0]*255*v,0,255);im.data[i+1]=clamp(cc[1]*255*v,0,255);im.data[i+2]=clamp(cc[2]*255*v,0,255);im.data[i+3]=a;}AG.putImageData(im,col*16,row*16);}
function faceTex(b,face){const k=I[b].k||'stone';const n=face==='top'?k+'_top':face==='bottom'?k+'_bottom':k+'_side';return TEX[n]!=null?TEX[n]:TEX[k];}
let atlasTex=null;
function buildDefaultAtlas(){AG.clearRect(0,0,256,256);
 for(let b=1;b<BLOCK_COUNT;b++){const it=I[b];const k=it.k;
  const alpha=b===WATER?150:(b===GLASS||b===ICE||b===OBS||b===WHISPER||b===AMBER)?170:255;
  const small=(b===TORCH||b===CANDLE||b===FOGLAMP);
  const stoneDetail=(x,y,seed)=>{ // трещины и пятна как на каменной текстуре
   const r=hash2(x,y,seed),cr=hash2(x>>2,y>>2,seed+1);const crack=(cr<0.35&&((x+y)%7===0||(x*3+y)%11===0))&&hash2(x*7,y*3,seed+2)<0.5;
   return crack?{v:.62}:r<0.12?{v:.82}:r>0.9?{v:1.12}:null;};
  const orePattern=(x,y,seed,oc)=>{const cx=[3,11,6,13,2,9],cy=[3,4,10,12,12,8];for(let i=0;i<6;i++){if(hash2(i,seed,7)<0.35)continue;const dx=x-cx[i],dy=y-cy[i];if(Math.abs(dx)+Math.abs(dy)<=1||(dx*dx+dy*dy<=2&&hash2(x,y,seed+i)<0.6))return {c:oc,v:(dx===0&&dy===0)?1.25:1};}return stoneDetail(x,y,seed);};
  tileNoise(texTile(k),it.side||it.c,alpha,(x,y)=>{
   if(b===STONE)return stoneDetail(x,y,3);
   if(b===COBBLE||b===MOSSY){const cells=[[0,0,5,4],[5,0,5,5],[10,0,6,4],[0,4,4,5],[4,5,6,5],[10,4,6,6],[0,9,6,7],[6,10,5,6],[11,10,5,6]];for(const [cx,cy,w,hh] of cells){if(x>=cx&&x<cx+w&&y>=cy&&y<cy+hh){const edge=x===cx||y===cy||x===cx+w-1||y===cy+hh-1;if(edge)return {v:.5};if(b===MOSSY&&hash2(x,y,7)<0.35)return {c:[.3,.55,.3]};return {v:0.95+hash2(cx,cy,9)*0.25};}}return {v:.5};}
   if(b===DIRT||b===GRAVEL){const r=hash2(x,y,b+1);return r<0.12?{v:.68}:r<0.2?{v:.82}:r>0.92?{v:1.18}:hash2(x>>1,y>>1,b+3)<0.12?{v:.75}:null;}
   if(b===SAND||b===SALT||b===SNOW){const r=hash2(x,y,b+1);return r<0.08?{v:.86}:r>0.94?{v:1.08}:null;}
   if(b===GLASS||b===OBS||b===ICE)return (x===0||y===0||x===15||y===15)?{v:.6}:((x+y)%9===0||(x===3&&y<6)||(y===12&&x>9))?{v:1.25}:{v:1.1};
   if(b===LEAF||b===REDLEAF)return hash2(x,y,b+9)<0.22?{a:0}:null;
   if(b===COAL||b===IRONORE||b===GOLDORE||b===LUNAR){const r=orePattern(x,y,b+5,b===COAL?[.13,.13,.13]:b===IRONORE?[.85,.6,.45]:b===GOLDORE?[.98,.85,.25]:[.85,.9,1]);return r&&r.c?r:Object.assign({c:[.52,.52,.54]},r||{});}
   if(b===BRICK)return ((y%4===0)||((x+((y>>2)%2)*4)%8===0))?{c:[.75,.7,.65]}:null;
   if(b===PLANK){if(y%4===0)return {v:.55};const off=((y>>2)%2)*8;if((x+off)%16===0)return {v:.6};return hash2(x,y,4)<0.15?{v:.88}:hash2(x,y,5)>0.93?{v:1.1}:null;}
   if(b===BOOK)return (y<2||y>13)?{c:[.66,.52,.32]}:(x%4===0?{v:.5}:{c:[[.6,.2,.2],[.2,.4,.7],[.3,.6,.3]][Math.floor(x/4)%3]});
   if(b===LOG||b===DEADWOOD){const r=hash2(x,y,b+2);if(x%4===0)return {v:.62};if(x%4===2&&r<0.3)return {v:.8};return r>0.9?{v:1.12}:null;}
   if(b===SIGIL)return (Math.abs(x-y)<=1||Math.abs(15-x-y)<=1||((x===7||x===8)&&y>2&&y<13))?{c:[.85,.75,.95],v:1.2}:null;
   if(b===MIRROR)return (x+y)%7===0?{v:1.4}:null;
   if(b===BONE)return (y%5===2&&x>1&&x<14)?{c:[.6,.58,.5]}:null;
   if(b===WHISPER)return (Math.abs(x-8)+Math.abs(y-8)<4)?{v:1.5}:null;
   if(b===MUSHB)return hash2(x>>1,y>>1,b)<0.25?{c:[.95,.9,.85]}:null;
   if(b===COBBLE||b===MOSSY){const cx=(x+3*(y>>2))%5,cy=y%4;return (cx===0||cy===0)?{v:.55}:(b===MOSSY&&hash2(x,y,7)<0.3?{c:[.3,.55,.3]}:{v:1+((x>>2)+(y>>2))%2*0.12});}
   if(b===STONE)return hash2(x,y,3)<0.08?{v:.7}:null;
   if(b===DIRT||b===GRAVEL)return hash2(x,y,b+1)<0.15?{v:.7}:hash2(x,y,b+2)<0.1?{v:1.2}:null;
   if(b===SAND||b===SALT||b===SNOW)return hash2(x,y,b+1)<0.1?{v:.85}:null;
   if(b===CLAY)return ((x>>2)+(y>>2))%2?{v:.92}:null;
   if(b===ASH)return hash2(x,y,5)<0.12?{c:[.6,.2,.1],v:1.3}:null;
   if(b===RUST)return hash2(x,y,6)<0.3?{c:[.35,.2,.12]}:hash2(x,y,8)<0.1?{c:[.7,.45,.2]}:null;
   if(b===VOID)return hash2(x,y,9)<0.03?{c:[.5,.4,.7],v:2}:null;
   if(b===AMBER)return hash2(x>>2,y>>2,10)<0.15?{c:[.3,.15,.05]}:null;
   if(b===MOSS)return hash2(x,y,11)<0.3?{v:.7}:null;
   if(b===FENCE)return (x>5&&x<10)||(y===4||y===10)?null:{a:0};
   if(b===LADDER)return (x<3||x>12||y%5===0)?null:{a:0};
   if(b===DOORC||b===DOORO)return (x===7||x===8||y===0||y===15||x===0||x===15)?{v:.6}:(x===12&&y===8?{c:[.9,.8,.3]}:null);
   if(b===BED)return y<6?{c:[.9,.9,.85]}:(y>13?{c:[.4,.25,.15]}:null);
   if(b===CHEST)return (y===7||y===8)?{v:.5}:((x===7||x===8)&&y>5&&y<10?{c:[.8,.7,.3]}:null);
   if(b===LAMP)return (x===0||y===0||x===15||y===15)?{c:[.4,.35,.25]}:{v:1.15};
   if(b===TABLE)return (y<3)?{c:[.75,.6,.4]}:((x>2&&x<7&&y>4&&y<10)||(x>8&&x<13&&y>4&&y<10))?{c:[.35,.25,.15]}:null;
   if(b===BOOM)return (y>5&&y<10)?{c:[.9,.9,.9]}:null;
   if(small)return (x>5&&x<10)?(y<4?{c:[1,.95,.6],v:1.2}:{c:[.5,.38,.2]}):{a:0};
   return null;});
  if(it.top){tileNoise(texTile(k+'_top'),it.top,alpha,(x,y)=>{if(b===LOG||b===DEADWOOD){const d=Math.max(Math.abs(x-7.5),Math.abs(y-7.5));if(d>6.5)return {c:it.c,v:.85};return (Math.floor(d)%2===0)?{v:.72}:{v:1.05};}return null;});}
  if(b===GRASS){tileNoise(texTile('grass_top'),it.c,255,(x,y)=>{const r=hash2(x,y,21);return r<0.15?{v:.78}:r>0.9?{v:1.15}:null;});tileNoise(texTile('grass_side'),it.side,255,(x,y)=>{const edge=3+Math.floor(hash2(x,0,22)*3);if(y<edge)return {c:it.c,v:y===edge-1?.85:1};const r=hash2(x,y,23);return r<0.12?{v:.7}:null;});}
  if(b===SNOW){tileNoise(texTile('snow_side'),[.45,.35,.22],255,(x,y)=>y<4?{c:it.c}:null);}
  if(b===MUSHB){tileNoise(texTile('giant_mushroom_bottom'),[.85,.8,.7],255);}
  if(small){for(const nm of [k+'_top',k+'_bottom'])tileNoise(texTile(nm),it.c,255,(x,y)=>(x>5&&x<10&&y>5&&y<10)?null:{a:0});}
 }
 if(atlasTex)atlasTex.needsUpdate=true;}
async function applyPackZip(blob){const zip=await JSZip.loadAsync(blob);let n=0;const names=Object.keys(TEX);
 for(const f of Object.values(zip.files)){if(f.dir||!/\.png$/i.test(f.name))continue;const base=f.name.split('/').pop().replace(/\.png$/i,'').toLowerCase();
  let nm=names.find(x=>x===base);if(!nm){const it=I.find(o=>o.k&&o.n.toLowerCase()===base);if(it)nm=it.k;}if(!nm)continue;
  const b=await f.async('blob');const im=await createImageBitmap(b);const t=TEX[nm];AG.clearRect((t%16)*16,Math.floor(t/16)*16,16,16);AG.imageSmoothingEnabled=false;AG.drawImage(im,(t%16)*16,Math.floor(t/16)*16,16,16);n++;}
 atlasTex.needsUpdate=true;buildAll();sys('Ресурс-пак применён: '+n+' текстур.');return n;}
function textureList(){return Object.keys(TEX).sort().map(k=>k+'.png').join(', ');}
// --- items ---
const item=(n,kind,c,extra)=>def(Object.assign({n,kind,c},extra||{}));
item('Уголь','misc',[.15,.15,.15]);
item('Ветка','misc',[.5,.38,.2]);
item('Железный слиток','misc',[.8,.8,.82]);
item('Золотой слиток','misc',[.95,.8,.3]);
item('Лунная пыль','misc',[.8,.85,1],{desc:'Сыпучий свет.'});
item('Кость','misc',[.9,.88,.8]);
item('Перо','misc',[.95,.95,.95]);
item('Шерсть','misc',[.9,.9,.85]);
item('Кожа','misc',[.55,.35,.2]);
item('Слизь тумана','misc',[.6,.8,.75]);
item('Нить','misc',[.85,.85,.85]);
item('Осколок зеркала','misc',[.85,.9,1]);
item('Пустое ведро','misc',[.7,.7,.72]);
item('Ведро воды','misc',[.3,.45,.8],{desc:'Выливается по ПКМ. Вода течёт.'});
item('Палка','misc',[.6,.45,.25]);
// tools: power = mining speed multiplier, dmg
item('Деревянная кирка','tool',[.6,.45,.25],{power:2,dmg:2});
item('Каменная кирка','tool',[.5,.5,.5],{power:3,dmg:3});
item('Железная кирка','tool',[.8,.8,.82],{power:5,dmg:4});
item('Лунная кирка','tool',[.7,.75,.95],{power:8,dmg:5,desc:'Ломает даже пустотный камень.'});
item('Деревянный меч','tool',[.6,.45,.25],{power:1,dmg:4});
item('Жезл региона','tool',[.95,.78,.3],{power:1,dmg:1,wand:true,hide:true,desc:'ЛКМ — точка 1, ПКМ — точка 2, затем /rg claim имя'});
item('Железный меч','tool',[.8,.8,.82],{power:1,dmg:6});
item('Костяной клинок','tool',[.9,.88,.8],{power:1,dmg:8,desc:'Он хочет обратно.'});
item('Соляной посох','tool',[.95,.93,.9],{power:1,dmg:2,ward:true,desc:'Удар отгоняет тени и снижает тревогу.'});
// food: food=hunger restore, hp=extra heal, effect
item('Яблоко','food',[.85,.2,.2],{food:4});
item('Хлеб','food',[.8,.6,.35],{food:5});
item('Гриб','food',[.7,.55,.45],{food:2});
item('Грибная похлёбка','food',[.75,.6,.5],{food:8});
item('Сырое мясо','food',[.75,.35,.35],{food:3});
item('Жареное мясо','food',[.55,.3,.2],{food:8});
item('Печенье','food',[.8,.65,.4],{food:2});
item('Пепельные ягоды','food',[.4,.38,.4],{food:3,dread:-8,desc:'Вкус дыма. Успокаивают.'});
item('Лунный плод','food',[.75,.8,1],{food:6,hp:6,desc:'Растёт там, куда не смотрят.'});
item('Пещерный инжир','food',[.4,.2,.35],{food:4});
item('Светящийся пирог','food',[.9,.95,.6],{food:10,hp:4});
item('Костяная похлёбка','food',[.85,.8,.7],{food:7,dread:10,desc:'Питательно. Тревожно.'});
item('Чай из шёпота','food',[.6,.7,.9],{food:2,dread:-25,desc:'Голоса затихают на время.'});
item('Янтарный мёд','food',[.95,.7,.2],{food:6,hp:3});
item('Призрачный перец','food',[.9,.9,1],{food:1,hp:-2,dread:15,desc:'Ты его не видишь, но он жжёт.'});
item('Туманное желе','food',[.7,.9,.85],{food:5,desc:'Дрожит само по себе.'});
item('Морозная дыня','food',[.6,.85,.9],{food:6});
item('Кровавая ягода','food',[.6,.05,.05],{food:3,hp:2});
item('Жареная кость','food',[.8,.7,.6],{food:4});
item('Соляная лепёшка','food',[.95,.9,.85],{food:4,dread:-5});
const byName={};I.forEach(o=>byName[o.n]=o.id);
const N=n=>byName[n];

/* ================= RECIPES ================= */
const R=[
 {out:['Доски',4],ing:[['Бревно',1]]},
 {out:['Палка',4],ing:[['Доски',2]]},
 {out:['Палка',2],ing:[['Ветка',2]]},
 {out:['Факел',4],ing:[['Уголь',1],['Палка',1]]},
 {out:['Свеча',3],ing:[['Нить',1],['Янтарный мёд',1]]},
 {out:['Деревянная кирка',1],ing:[['Доски',3],['Палка',2]]},
 {out:['Каменная кирка',1],ing:[['Булыжник',3],['Палка',2]]},
 {out:['Железная кирка',1],ing:[['Железный слиток',3],['Палка',2]]},
 {out:['Лунная кирка',1],ing:[['Лунная пыль',3],['Пустотный камень',2],['Палка',2]]},
 {out:['Деревянный меч',1],ing:[['Доски',2],['Палка',1]]},
 {out:['Железный меч',1],ing:[['Железный слиток',2],['Палка',1]]},
 {out:['Костяной клинок',1],ing:[['Кость',4],['Осколок зеркала',1]]},
 {out:['Соляной посох',1],ing:[['Соль',3],['Палка',2]]},
 {out:['Железный слиток',1],ing:[['Железная руда',1],['Уголь',1]]},
 {out:['Золотой слиток',1],ing:[['Золотая руда',1],['Уголь',1]]},
 {out:['Хлеб',1],ing:[['Мох',3]]},
 {out:['Грибная похлёбка',1],ing:[['Гриб',2],['Пустое ведро',1]]},
 {out:['Жареное мясо',1],ing:[['Сырое мясо',1],['Уголь',1]]},
 {out:['Печенье',4],ing:[['Хлеб',1],['Янтарный мёд',1]]},
 {out:['Светящийся пирог',1],ing:[['Хлеб',2],['Лунная пыль',1],['Янтарный мёд',1]]},
 {out:['Костяная похлёбка',1],ing:[['Кость',2],['Пустое ведро',1]]},
 {out:['Чай из шёпота',1],ing:[['Шепчущий кристалл',1],['Мох',1]]},
 {out:['Жареная кость',1],ing:[['Кость',1],['Уголь',1]]},
 {out:['Соляная лепёшка',2],ing:[['Соль',1],['Хлеб',1]]},
 {out:['Туманное желе',1],ing:[['Слизь тумана',2]]},
 {out:['Пустое ведро',1],ing:[['Железный слиток',3]]},
 {out:['Туманный фонарь',1],ing:[['Стекло',1],['Слизь тумана',1],['Факел',1]]},
 {out:['Стекло',1],ing:[['Песок',1],['Уголь',1]]},
 {out:['Кирпич',1],ing:[['Глина',2],['Уголь',1]]},
 {out:['Книжная полка',1],ing:[['Доски',6],['Кожа',3]]},
 {out:['Мшистый булыжник',1],ing:[['Булыжник',1],['Мох',1]]},
 {out:['Костяной блок',1],ing:[['Кость',4]]},
 {out:['Соль',1],ing:[['Ведро воды',1],['Песок',2]]},
 {out:['Зеркальный камень',1],ing:[['Стекло',2],['Осколок зеркала',1]]},
 {out:['Знак-камень',1],ing:[['Пустотный камень',1],['Лунная пыль',1],['Кость',1]]},
 {out:['Кровать',1],ing:[['Доски',3],['Шерсть',3]]},
 {out:['Лестница',3],ing:[['Палка',7]]},
 {out:['Дверь',1],ing:[['Доски',6]]},
 {out:['Забор',3],ing:[['Палка',4],['Доски',2]]},
 {out:['Взрывной порошок',1],ing:[['Уголь',2],['Пепел',2],['Песок',1]]},
 {out:['Ящик',1],ing:[['Доски',8]]},
 {out:['Лампа',1],ing:[['Стекло',1],['Лунная пыль',1]]},
 {out:['Верстак',1],ing:[['Доски',4]]},
];

/* ================= WORLD ================= */
/* ================= WORLD (chunks, infinite) ================= */
const H=64,CS=16,SEA=22;
const CH=new Map(); // "cx,cz" -> {v:Uint8Array, w:Uint8Array(water level 1..8, +16 source), cx, cz, meshed:false}
const ck=(cx,cz)=>cx+','+cz;
const lidx=(x,y,z)=>((y*CS)+(z&15))*CS+(x&15);
const chunkAt=(x,z)=>CH.get(ck(x>>4,z>>4));
const inB=(x,y,z)=>y>=0&&y<H&&CH.has(ck(x>>4,z>>4));
function get(x,y,z){if(y<0||y>=H)return AIR;const c=CH.get(ck(x>>4,z>>4));return c?c.v[lidx(x,y,z)]:AIR;}
function set(x,y,z,v){if(y<0||y>=H)return;const c=CH.get(ck(x>>4,z>>4));if(c)c.v[lidx(x,y,z)]=v;}
function wl(x,y,z){if(y<0||y>=H)return 0;const c=CH.get(ck(x>>4,z>>4));return c?c.w[lidx(x,y,z)]:0;}
function setwl(x,y,z,v){if(y<0||y>=H)return;const c=CH.get(ck(x>>4,z>>4));if(c)c.w[lidx(x,y,z)]=v;}
let seed=1337;
function sr(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;}
function hash2(x,z,s){let h=(x*374761393+z*668265263+s*1442695041)>>>0;h=(h^(h>>>13))*1274126177>>>0;return ((h^(h>>>16))>>>0)/4294967296;}
function vnoise(x,z,s,sc){x/=sc;z/=sc;const xi=Math.floor(x),zi=Math.floor(z),fx=x-xi,fz=z-zi,u=fx*fx*(3-2*fx),v=fz*fz*(3-2*fz);
 const a=hash2(xi,zi,s),b=hash2(xi+1,zi,s),c=hash2(xi,zi+1,s),d=hash2(xi+1,zi+1,s);return (a*(1-u)+b*u)*(1-v)+(c*(1-u)+d*u)*v;}
// edits (player changes) — global map + per-chunk index so new chunks get them applied
const edits=new Map();const editIdx=new Map();
function recordEdit(x,y,z,v){edits.set(x+','+y+','+z,v);const k=ck(x>>4,z>>4);let a=editIdx.get(k);if(!a){a=new Map();editIdx.set(k,a);}a.set(x+','+y+','+z,v);}
function clearEdits(){edits.clear();editIdx.clear();}
function applyEdit(k,v){const [x,y,z]=k.split(',').map(Number);recordEdit(x,y,z,v);if(inB(x,y,z)){set(x,y,z,v);setwl(x,y,z,v===WATER?(8|16):0);markDirty(x,y,z);}}
function colH(x,z,s){const n=vnoise(x,z,s,38)*0.6+vnoise(x,z,s+7,14)*0.3+vnoise(x,z,s+13,6)*0.1;const mount=Math.pow(vnoise(x,z,s+99,60),3)*36;return Math.floor(12+n*20+mount);}
function genChunk(cx,cz){const s=seed;const k=ck(cx,cz);if(CH.has(k))return CH.get(k);
 const c={v:new Uint8Array(CS*H*CS),w:new Uint8Array(CS*H*CS),cx,cz,meshed:false};CH.set(k,c);
 const X0=cx*CS,Z0=cz*CS;
 const lset=(x,y,z,b)=>{if(y<0||y>=H||x<X0||x>=X0+CS||z<Z0||z>=Z0+CS)return;c.v[lidx(x,y,z)]=b;};
 const lget=(x,y,z)=>(y<0||y>=H||x<X0||x>=X0+CS||z<Z0||z>=Z0+CS)?AIR:c.v[lidx(x,y,z)];
 for(let x=X0;x<X0+CS;x++)for(let z=Z0;z<Z0+CS;z++){
  const h=colH(x,z,s);const bio=vnoise(x,z,s+55,70);
  for(let y=0;y<=h;y++){let b=STONE;
   if(y===h){b=h<SEA+1?SAND:(bio>0.72?ASH:(h>40?SNOW:GRASS));}
   else if(y>h-4){b=h<SEA+1?SAND:(bio>0.72?ASH:DIRT);}
   else{const r=hash2(x*7+y,z*3+y,s+y);
    if(r<0.02&&y<30)b=COAL;else if(r<0.03&&y<22)b=IRONORE;else if(r<0.035&&y<12)b=GOLDORE;
    else if(r<0.04&&y<26)b=LUNAR;else if(r<0.045&&y<8)b=VOID;else if(r<0.05&&y<30)b=WHISPER;else if(r<0.055&&y<18)b=BONE;else if(r<0.06&&y<24)b=AMBER;
    else if(r<0.07&&y<20)b=GRAVEL;else if(r<0.075)b=CLAY;else if(r<0.077)b=SALT;}
   c.v[lidx(x,y,z)]=b;}
  for(let y=h+1;y<=SEA;y++){c.v[lidx(x,y,z)]=WATER;c.w[lidx(x,y,z)]=8|16;}
  for(let y=4;y<h-2;y++){const cv=vnoise(x+y*3,z-y*2,s+31,9);if(cv>0.78&&vnoise(x,y*4,s+77,7)>0.5)c.v[lidx(x,y,z)]=AIR;}
 }
 // trees & decorations from a margin, so trees on chunk borders are complete
 for(let x=X0-3;x<X0+CS+3;x++)for(let z=Z0-3;z<Z0+CS+3;z++){
  const h=colH(x,z,s);const bio=vnoise(x,z,s+55,70);const t=hash2(x,z,s+3);
  if(h>SEA+1&&h<40&&bio<0.72&&t<0.012){const th=4+Math.floor(hash2(x,z,s+9)*3);for(let y=1;y<=th;y++)lset(x,h+y,z,LOG);
   for(let dx=-2;dx<=2;dx++)for(let dz=-2;dz<=2;dz++)for(let dy=th-2;dy<=th+1;dy++){if(Math.abs(dx)+Math.abs(dz)+Math.abs(dy-th)<=3&&!(dx===0&&dz===0&&dy<=th)&&lget(x+dx,h+dy,z+dz)===AIR)lset(x+dx,h+dy,z+dz,LEAF);}}
  else if(bio>0.72&&t<0.02&&h>SEA+1){const th=3+Math.floor(hash2(x,z,s+9)*3);for(let y=1;y<=th;y++)lset(x,h+y,z,DEADWOOD);if(t<0.006)for(let dx=-1;dx<=1;dx++)for(let dz=-1;dz<=1;dz++)if(lget(x+dx,h+th+1,z+dz)===AIR)lset(x+dx,h+th+1,z+dz,REDLEAF);}
  else if(t>0.995&&h>SEA+1)lset(x,h+1,z,MUSHB);
  else if(t>0.985&&t<0.988&&h>SEA+1&&bio>0.5)lset(x,h+1,z,MOSS);
 }
 // strange structures: one per ~15 chunks, placed by chunk hash (may cross borders — handled by margin)
 for(let ox=-1;ox<=1;ox++)for(let oz=-1;oz<=1;oz++){const scx=cx+ox,scz=cz+oz;const r=hash2(scx,scz,s+500);
  if(r<0.05){const sx=scx*CS+8,sz=scz*CS+8;const hy=colH(sx,sz,s);if(hy>SEA){for(let a=0;a<12;a++){const px=Math.round(sx+Math.cos(a/12*6.283)*3),pz=Math.round(sz+Math.sin(a/12*6.283)*3);const py=colH(px,pz,s);if(py>SEA)lset(px,py+1,pz,SALT);}lset(sx,hy+1,sz,SIGIL);}}
  else if(r<0.085){const sx=scx*CS+8,sz=scz*CS+8;const hy=colH(sx,sz,s);if(hy>SEA){for(let y=1;y<=3;y++)for(let dx=-1;dx<=1;dx++)for(let dz=-1;dz<=1;dz++)if(Math.abs(dx)+Math.abs(dz)===2)lset(sx+dx,hy+y,sz+dz,COBBLE);lset(sx,hy+1,sz,CANDLE);}}
  else if(r<0.1){ // abandoned hut
   const sx=scx*CS+5,sz=scz*CS+5;const hy=colH(sx,sz,s);if(hy>SEA){for(let dx=0;dx<5;dx++)for(let dz=0;dz<5;dz++)for(let y=1;y<=4;y++){const wall=dx===0||dz===0||dx===4||dz===4;if(y===4||wall)lset(sx+dx,hy+y,sz+dz,y===4?PLANK:(hash2(dx,dz+y,s)<0.15?AIR:PLANK));else lset(sx+dx,hy+y,sz+dz,AIR);}
    lset(sx+2,hy+1,sz,DOORC);lset(sx+2,hy+2,sz,AIR);lset(sx+1,hy+1,sz+3,BED);lset(sx+3,hy+1,sz+3,CHEST);lset(sx+3,hy+1,sz+1,BOOK);}}
 }
 // player edits for this chunk
 const ed=editIdx.get(k);if(ed)for(const [ek,v] of ed){const [x,y,z]=ek.split(',').map(Number);c.v[lidx(x,y,z)]=v;c.w[lidx(x,y,z)]=v===WATER?(8|16):0;}
 return c;}
function genWorld(s){seed=s;for(const k of [...CH.keys()])unloadChunk(k);CH.clear();wq.clear();}
function ensureAround(x,z,r){for(let cx=(x>>4)-r;cx<=(x>>4)+r;cx++)for(let cz=(z>>4)-r;cz<=(z>>4)+r;cz++)genChunk(cx,cz);}
function topY(x,z){if(!CH.has(ck(x>>4,z>>4)))return -1;for(let y=H-1;y>=0;y--){const b=get(x,y,z);if(b!==AIR&&b!==WATER)return y;}return 0;}
const opaque=b=>b!==AIR&&!I[b].tr;
/* ---- water & sand physics ---- */
const wq=new Set();const wkey=(x,y,z)=>x+','+y+','+z;
function enq(x,y,z){if(inB(x,y,z))wq.add(wkey(x,y,z));}
function enqAround(x,y,z){enq(x,y,z);enq(x+1,y,z);enq(x-1,y,z);enq(x,y+1,z);enq(x,y-1,z);enq(x,y,z+1);enq(x,y,z-1);}
function setWater(x,y,z,lv,src){set(x,y,z,lv?WATER:AIR);setwl(x,y,z,lv?(lv|(src?16:0)):0);markDirty(x,y,z);enqAround(x,y,z);}
function waterStep(){let n=0;const it=[...wq];wq.clear();
 for(const k of it){if(++n>400){wq.add(k);continue;}const [x,y,z]=k.split(',').map(Number);if(!inB(x,y,z))continue;const b=get(x,y,z);
  if((b===SAND||b===GRAVEL)&&y>0){const bb=get(x,y-1,z);if(bb===AIR||bb===WATER){set(x,y-1,z,b);setwl(x,y-1,z,0);set(x,y,z,AIR);setwl(x,y,z,0);markDirty(x,y,z);markDirty(x,y-1,z);enqAround(x,y,z);enqAround(x,y-1,z);recordEdit(x,y,z,AIR);recordEdit(x,y-1,z,b);continue;}}
  if(b!==AIR&&b!==WATER)continue;
  const cur=wl(x,y,z)&15,src=(wl(x,y,z)&16)!==0;if(src)continue;
  let want=0;const up=get(x,y+1,z);if(up===WATER)want=8;
  else{for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,nz=z+dz;if(!inB(nx,y,nz))continue;if(get(nx,y,nz)!==WATER)continue;
    const below=y>0?get(nx,y-1,nz):STONE;const supported=!(below===AIR);const l=wl(nx,y,nz)&15;if(supported&&l-2>want)want=l-2;}}
  if(want!==cur)setWater(x,y,z,want,false);
 }}
let waterT=0;

/* ================= MESHING ================= */
const meshes=new Map();const dirty=new Set();
const scene=new THREE.Scene();
atlasTex=new THREE.CanvasTexture(ATLAS);atlasTex.magFilter=THREE.NearestFilter;atlasTex.minFilter=THREE.NearestFilter;atlasTex.generateMipmaps=false;
buildDefaultAtlas();
const matOp=new THREE.MeshLambertMaterial({vertexColors:true,map:atlasTex,alphaTest:0.5});
const matTr=new THREE.MeshLambertMaterial({vertexColors:true,map:atlasTex,transparent:true,opacity:.9,depthWrite:false,alphaTest:0.05});
const FACES=[ // dir, corners (4), shade
 {d:[0,1,0],c:[[0,1,0],[0,1,1],[1,1,1],[1,1,0]],s:1.0,side:'top'},
 {d:[0,-1,0],c:[[0,0,1],[0,0,0],[1,0,0],[1,0,1]],s:.5},
 {d:[1,0,0],c:[[1,1,0],[1,1,1],[1,0,1],[1,0,0]],s:.78},
 {d:[-1,0,0],c:[[0,1,1],[0,1,0],[0,0,0],[0,0,1]],s:.78},
 {d:[0,0,1],c:[[1,1,1],[0,1,1],[0,0,1],[1,0,1]],s:.68},
 {d:[0,0,-1],c:[[0,1,0],[1,1,0],[1,0,0],[0,0,0]],s:.68},
];
function buildChunk(cx,cz){
 const pos=[],col=[],nor=[],idxs=[],uv=[];const tpos=[],tcol=[],tnor=[],tidxs=[],tuv=[];
 const CHK=CH.get(ck(cx,cz));if(!CHK)return;CHK.meshed=true;
 for(let x=cx*CS;x<cx*CS+CS;x++)for(let z=cz*CS;z<cz*CS+CS;z++)for(let y=0;y<H;y++){
  const b=CHK.v[lidx(x,y,z)];if(b===AIR)continue;const bi=I[b];
  const isT=!!bi.tr;const P=isT?tpos:pos,C=isT?tcol:col,Nn=isT?tnor:nor,X=isT?tidxs:idxs,U=isT?tuv:uv;
  const small=(b===TORCH||b===CANDLE||b===FOGLAMP);
  for(const f of FACES){
   const nx=x+f.d[0],ny=y+f.d[1],nz=z+f.d[2];const nb=get(nx,ny,nz);
   if(!small){ if(opaque(nb))continue; if(isT&&nb===b&&!(b===WATER&&f.side==='top'&&(CHK.w[lidx(x,y,z)]&15)<8))continue; }
   const fnm=f.side==='top'?'top':f.d[1]===-1?'bottom':'side';const ti=faceTex(b,fnm);const u0=(ti%16)/16+0.002,v0=1-(Math.floor(ti/16)+1)/16+0.002,u1=u0+1/16-0.004,v1=v0+1/16-0.004;
   for(const k of f.c){let uu,vv;if(f.d[1]!==0){uu=k[0];vv=k[2];}else if(f.d[0]!==0){uu=k[2];vv=k[1];}else{uu=k[0];vv=k[1];}U.push(u0+(u1-u0)*uu,v0+(v1-v0)*vv);}
   const v=0.94+hash2(x*3+y,z*5-y,b)*0.12;const sh=f.s*v;const c=[1,1,1];
   const base=P.length/3;const wh=(b===WATER)?(((CHK.w[lidx(x,y,z)]&15)||8)/8)*0.875:1;
   for(const k of f.c){
    let px=x+k[0],py=y+k[1]*wh,pz=z+k[2];
    if(small){px=x+0.35+k[0]*0.3;pz=z+0.35+k[2]*0.3;py=y+k[1]*0.7;}
    P.push(px,py,pz);Nn.push(f.d[0],f.d[1],f.d[2]);C.push(c[0]*sh,c[1]*sh,c[2]*sh);}
   X.push(base,base+1,base+2,base,base+2,base+3);
  }
 }
 const mk=(p,c,n,x,mat,u)=>{if(!x.length)return null;const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(n,3));g.setAttribute('color',new THREE.Float32BufferAttribute(c,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(u,2));g.setIndex(x);const m=new THREE.Mesh(g,mat);m.frustumCulled=true;scene.add(m);return m;};
 const k=ck(cx,cz);const old=meshes.get(k);if(old){for(const m of old)if(m){scene.remove(m);m.geometry.dispose();}}
 meshes.set(k,[mk(pos,col,nor,idxs,matOp,uv),mk(tpos,tcol,tnor,tidxs,matTr,tuv)]);
}
function markDirty(x,y,z){const cx=x>>4,cz=z>>4;dirty.add(ck(cx,cz));const lx=x&15,lz=z&15;
 if(lx===0)dirty.add(ck(cx-1,cz));if(lx===15)dirty.add(ck(cx+1,cz));if(lz===0)dirty.add(ck(cx,cz-1));if(lz===15)dirty.add(ck(cx,cz+1));}
function buildAll(){for(const k of meshes.keys()){const [a,b]=k.split(',').map(Number);buildChunk(a,b);}dirty.clear();}
function flushDirty(){let n=0;for(const k of dirty){const [a,b]=k.split(',').map(Number);if(meshes.has(k))buildChunk(a,b);dirty.delete(k);if(++n>3)break;}}
function unloadChunk(k){const m=meshes.get(k);if(m){for(const x of m)if(x){scene.remove(x);x.geometry.dispose();}meshes.delete(k);}CH.delete(k);}
// streaming: generate around the viewer, mesh when neighbours exist, unload far chunks
function streamChunks(px,pz,budget){const R=Math.max(3,Math.min(9,Math.round(S.dist/16)));const cx0=px>>4,cz0=pz>>4;let n=0;
 const ring=[];for(let cx=cx0-R-1;cx<=cx0+R+1;cx++)for(let cz=cz0-R-1;cz<=cz0+R+1;cz++)ring.push([cx,cz,(cx-cx0)**2+(cz-cz0)**2]);ring.sort((a,b)=>a[2]-b[2]);
 for(const [cx,cz,d] of ring){const k=ck(cx,cz);if(!CH.has(k)){genChunk(cx,cz);if(++n>=budget)return;}
  else if(!meshes.has(k)&&d<=R*R&&CH.has(ck(cx+1,cz))&&CH.has(ck(cx-1,cz))&&CH.has(ck(cx,cz+1))&&CH.has(ck(cx,cz-1))){buildChunk(cx,cz);if(++n>=budget)return;}}
 for(const k of [...CH.keys()]){const [cx,cz]=k.split(',').map(Number);if((cx-cx0)**2+(cz-cz0)**2>(R+4)**2)unloadChunk(k);}}

/* ================= RENDER SETUP ================= */
const canvas=$('gl');
const renderer=new THREE.WebGLRenderer({canvas,antialias:false});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));
const camera=new THREE.PerspectiveCamera(75,1,0.05,220);
const hemi=new THREE.HemisphereLight(0xcfd8ff,0x3b3025,0.9);scene.add(hemi);
const sun=new THREE.DirectionalLight(0xfff2d0,0.9);sun.position.set(40,80,20);scene.add(sun);
scene.fog=new THREE.Fog(0x9aa7c0,20,90);
function resize(){const w=canvas.clientWidth,h=canvas.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}
addEventListener('resize',resize);

/* ================= PLAYER ================= */
function setCookie(k,v){try{document.cookie=k+'='+encodeURIComponent(v)+';max-age=31536000;path=/;SameSite=Lax';}catch(e){}}
function getCookie(k){try{const m=document.cookie.match(new RegExp('(?:^|; )'+k+'=([^;]*)'));return m?decodeURIComponent(m[1]):null;}catch(e){return null;}}
let ACCT=getCookie('nc_acct')||'';let ACCN=getCookie('nc_accn')||'';
let TOK=getCookie('nc_tok');if(!TOK){TOK=Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2);}setCookie('nc_tok',TOK);
const S={fov:75,dist:90,sens:6,inv:false,vol:60,tts:false,myst:1,skin:null,touch:null};try{Object.assign(S,JSON.parse(getCookie('nc_settings')||localStorage.getItem('nc_settings')||'{}'));}catch(e){}
function saveS(){const j=JSON.stringify(S);setCookie('nc_settings',j);try{localStorage.setItem('nc_settings',j);}catch(e){}}
const P={x:64,y:40,z:64,vx:0,vy:0,vz:0,yaw:0,pitch:0,onGround:false,hp:20,hunger:20,dread:0,dead:false,sel:0,name:'Player'};
/* ---- inventory: 36 slots (0-8 hotbar, 9-35 main), stacks of 64 ---- */
const SL=Array.from({length:36},()=>null);
const MAXST=id=>(I[id]&&I[id].kind==='tool')?1:64;
const inv={get(id){let n=0;for(const s of SL)if(s&&s.id===id)n+=s.n;return n||undefined;},
 set(id,n){take(id,this.get(id)||0);if(n>0)give(id,n);},delete(id){take(id,this.get(id)||0);},
 clear(){for(let i=0;i<36;i++)SL[i]=null;renderHot();},
 keys(){return new Set(SL.filter(Boolean).map(s=>s.id)).values();},
 entries(){const m=new Map();for(const s of SL)if(s)m.set(s.id,(m.get(s.id)||0)+s.n);return m.entries();},
 get size(){return new Set(SL.filter(Boolean).map(s=>s.id)).size;},
 forEach(f){for(const [k,v] of this.entries())f(v,k);}};
const hot={get length(){return 9;},indexOf(id){for(let i=0;i<9;i++)if(SL[i]&&SL[i].id===id)return i;return -1;},includes(id){return this.indexOf(id)>=0;},fill(){for(let i=0;i<9;i++)SL[i]=null;},forEach(f){for(let i=0;i<9;i++)f(SL[i]?SL[i].id:-1,i);}};
Object.defineProperties(hot,Object.fromEntries([...Array(9).keys()].map(i=>[i,{get(){return SL[i]?SL[i].id:-1;},set(v){if(v<0)SL[i]=null;else if(!SL[i]||SL[i].id!==v){const from=SL.findIndex((s,j)=>s&&s.id===v&&j!==i);if(from>=0){const t=SL[i];SL[i]=SL[from];SL[from]=t;}}}}])));
function give(id,n){if(id==null||id<0)return 0;n=n||1;const ms=MAXST(id);
 for(let i=0;i<36&&n>0;i++){const s=SL[i];if(s&&s.id===id&&s.n<ms){const add=Math.min(ms-s.n,n);s.n+=add;n-=add;}}
 for(let i=0;i<36&&n>0;i++){if(!SL[i]){const add=Math.min(ms,n);SL[i]={id,n:add};n-=add;}}
 renderHot();if(n>0&&typeof spawnDrop==='function'&&playing){spawnDrop(id,n,P.x,P.y+1,P.z,rnd(-1,1),2,rnd(-1,1));}return n;}
function take(id,n){if(!has(id,n))return false;let left=n;for(let i=35;i>=0&&left>0;i--){const s=SL[i];if(s&&s.id===id){const d=Math.min(s.n,left);s.n-=d;left-=d;if(s.n<=0)SL[i]=null;}}renderHot();return true;}
function has(id,n){return (inv.get(id)||0)>=(n||1);}
const SHAPES=[
 {out:['Доски',4],rows:[['Бревно']]},
 {out:['Палка',4],rows:[['Доски'],['Доски']]},
 {out:['Палка',2],rows:[['Ветка'],['Ветка']]},
 {out:['Факел',4],rows:[['Уголь'],['Палка']]},
 {out:['Верстак',1],rows:[['Доски','Доски'],['Доски','Доски']]},
 {out:['Деревянная кирка',1],rows:[['Доски','Доски','Доски'],[null,'Палка',null],[null,'Палка',null]]},
 {out:['Каменная кирка',1],rows:[['Булыжник','Булыжник','Булыжник'],[null,'Палка',null],[null,'Палка',null]]},
 {out:['Железная кирка',1],rows:[['Железный слиток','Железный слиток','Железный слиток'],[null,'Палка',null],[null,'Палка',null]]},
 {out:['Лунная кирка',1],rows:[['Лунная пыль','Лунная пыль','Лунная пыль'],[null,'Пустотный камень',null],[null,'Палка',null]]},
 {out:['Деревянный меч',1],rows:[['Доски'],['Доски'],['Палка']]},
 {out:['Железный меч',1],rows:[['Железный слиток'],['Железный слиток'],['Палка']]},
 {out:['Костяной клинок',1],rows:[['Кость'],['Кость'],['Осколок зеркала']]},
 {out:['Соляной посох',1],rows:[['Соль'],['Палка'],['Палка']]},
 {out:['Кровать',1],rows:[['Шерсть','Шерсть','Шерсть'],['Доски','Доски','Доски']]},
 {out:['Лестница',3],rows:[['Палка',null,'Палка'],['Палка','Палка','Палка'],['Палка',null,'Палка']]},
 {out:['Дверь',1],rows:[['Доски','Доски'],['Доски','Доски'],['Доски','Доски']]},
 {out:['Забор',3],rows:[['Доски','Палка','Доски'],['Доски','Палка','Доски']]},
 {out:['Ящик',1],rows:[['Доски','Доски','Доски'],['Доски',null,'Доски'],['Доски','Доски','Доски']]},
 {out:['Книжная полка',1],rows:[['Доски','Доски','Доски'],['Кожа','Кожа','Кожа'],['Доски','Доски','Доски']]},
 {out:['Лампа',1],rows:[['Стекло'],['Лунная пыль']]},
 {out:['Свеча',3],rows:[['Нить'],['Янтарный мёд']]},
 {out:['Туманный фонарь',1],rows:[['Стекло'],['Слизь тумана'],['Факел']]},
];
function craftMatch(grid,w){const cells=grid.map(s=>s?s.id:null);
 let minr=w,maxr=-1,minc=w,maxc=-1;for(let r=0;r<w;r++)for(let c=0;c<w;c++)if(cells[r*w+c]!=null){minr=Math.min(minr,r);maxr=Math.max(maxr,r);minc=Math.min(minc,c);maxc=Math.max(maxc,c);}
 if(maxr<0)return null;const H=maxr-minr+1,Wd=maxc-minc+1;
 for(const s of SHAPES){const rw=s.rows.length,cw=Math.max(...s.rows.map(r=>r.length));if(rw!==H||cw!==Wd)continue;let ok=true;
  for(let r=0;r<H&&ok;r++)for(let c=0;c<Wd&&ok;c++){const want=s.rows[r][c]||null;const got=cells[(minr+r)*w+minc+c];if((want==null)!==(got==null))ok=false;else if(want!=null&&N(want)!==got)ok=false;}
  if(ok){const id=N(s.out[0]);if(id!=null)return {id,n:s.out[1]};}}
 const cnt=new Map();for(const s of grid)if(s)cnt.set(s.id,(cnt.get(s.id)||0)+1);
 for(const r of R){const ing=r.ing.filter(([n,c])=>c>0);if(ing.length!==cnt.size)continue;let ok=true;for(const [n,c] of ing){if(cnt.get(N(n))!==c){ok=false;break;}}if(ok){const id=N(r.out[0]);if(id!=null)return {id,n:r.out[1]};}}
 return null;}
function startKit(){give(N('Деревянная кирка'),1);give(N('Факел'),8);give(N('Хлеб'),3);give(N('Пепельные ягоды'),2);give(N('Соль'),4);}
const keys={};
addEventListener('blur',()=>{for(const k in keys)keys[k]=false;mineDown=false;});
addEventListener('keydown',e=>{if(e.target&&(e.target.tagName==='INPUT'||e.target.tagName==='TEXTAREA'||e.target.tagName==='SELECT'))return;if(chatOpen){if(e.key==='Enter'){sendChat();e.preventDefault();}else if(e.key==='Escape'){closeChat();}return;}
 keys[e.code]=true;
 if(!playing)return;
 if(e.code==='KeyE'){toggleInv();e.preventDefault();}
 if(e.code==='Tab'){showTab(true);e.preventDefault();}
 if(e.code==='Escape'&&invOpen){closeInv();e.preventDefault();return;}
 if(e.code==='KeyT'&&!invOpen&&!paused){openChat();e.preventDefault();}
 if(e.code==='Slash'&&!invOpen&&!paused){openChat();$('chatin').value='/';e.preventDefault();}
 if(e.code==='Escape'){if(setOpen)toggleSettings();else if(invOpen)toggleInv();else togglePause();}
 if(e.code>='Digit1'&&e.code<='Digit9'){P.sel=+e.code[5]-1;renderHot();}
 if(e.code==='KeyG'&&!invOpen){dropSelected();}
 if(e.code==='KeyQ'&&!invOpen&&!e.repeat){dropSelected();e.preventDefault();}
 if(e.code==='F1'){$('hud').classList.toggle('nohud');e.preventDefault();}
 if(e.code==='F3'){$('topleft').hidden=!$('topleft').hidden;e.preventDefault();}
 if(e.code==='F2'){$('bars').hidden=!$('bars').hidden;e.preventDefault();}
});
addEventListener('keyup',e=>{keys[e.code]=false;if(e.code==='Tab')$('tablist').hidden=true;});
function renderTab(){const el=$('tablist');if(!el||el.hidden)return;const rows=[[P.name,isOp,true]];for(const o of others.values())rows.push([o.name.replace(/^\[.*?\] /,''),false,false]);
 el.innerHTML='<div class="tabhead">'+(netOn?serverName+' · игроков: '+rows.length:'одиночная игра')+(netOn?' · PvP '+(pvpOn?'вкл':'выкл'):'')+'</div>'+rows.map(([n,op,me])=>'<div class="tabrow'+(me?' me':'')+'">'+(clanMap[n]?'<span class="tag">['+clanMap[n]+']</span> ':'')+n+(op?' <span class="tag">op</span>':'')+'</div>').join('');}
function showTab(v){const el=$('tablist');if(!el)return;el.hidden=!v;if(v)renderTab();}
addEventListener('wheel',e=>{if(!playing||invOpen||paused)return;P.sel=(P.sel+(e.deltaY>0?1:8))%9;renderHot();});
let locked=false;
function lockMouse(){if(!playing||invOpen||paused||setOpen||isTouch||locked)return;try{const p=canvas.requestPointerLock({unadjustedMovement:true});if(p&&p.catch)p.catch(()=>{try{canvas.requestPointerLock();}catch(e){}});}catch(e){try{canvas.requestPointerLock();}catch(e2){}}}
canvas.addEventListener('click',lockMouse);$('lockhint').addEventListener('click',lockMouse);$('hud').addEventListener('click',e=>{if(e.target===$('hud')||e.target.id==='vignette'||e.target.id==='cross')lockMouse();});
document.addEventListener('pointerlockerror',()=>{sys('Браузер не дал захватить мышь. Нажми Esc и кликни по миру ещё раз.');});
document.addEventListener('pointerlockchange',()=>{locked=document.pointerLockElement===canvas;});
addEventListener('mousemove',e=>{if(!locked)return;const k=0.0004*S.sens;P.yaw-=e.movementX*k;P.pitch=clamp(P.pitch-e.movementY*k*(S.inv?-1:1),-1.55,1.55);});
canvas.addEventListener('mousedown',e=>{if(!playing||invOpen||paused||setOpen||isTouch||!locked)return;if(e.button===0){if(isWand()){wandSel(1);return;}mineDown=true;}if(e.button===2){if(isWand()){wandSel(2);return;}placeBlock();}});
addEventListener('mouseup',e=>{if(e.button===0)mineDown=false;});
canvas.addEventListener('contextmenu',e=>e.preventDefault());
let mineDown=false,mineProg=0,mineTarget=null,sprintT=false;

function collide(x,y,z){const r=0.3;for(const dx of[-r,r])for(const dz of[-r,r])for(const dy of[0,0.9,1.75]){const b=get(Math.floor(x+dx),Math.floor(y+dy),Math.floor(z+dz));if(b!==AIR&&I[b].solid!==false)return true;}return false;}
function physics(dt){if(!CH.has(ck(Math.floor(P.x)>>4,Math.floor(P.z)>>4)))return;
 const sp=(keys.ShiftLeft?3.2:(keys.ControlLeft||sprintT)?8:5.4);if((keys.ControlLeft||sprintT)&&(keys.KeyW||tmove.y<-0.2)&&Math.random()<0.01&&P.hunger>0){P.hunger--;renderBars();}
 let fx=0,fz=0;
 if(keys.KeyW||tmove.y<-0.2)fz-=1;if(keys.KeyS||tmove.y>0.2)fz+=1;if(keys.KeyA||tmove.x<-0.2)fx-=1;if(keys.KeyD||tmove.x>0.2)fx+=1;
 if(isTouch){fx=tmove.x;fz=tmove.y;}
 const l=Math.hypot(fx,fz)||1;if(l>1){fx/=l;fz/=l;}
 const s=Math.sin(P.yaw),c=Math.cos(P.yaw);
 const inW=get(Math.floor(P.x),Math.floor(P.y+0.5),Math.floor(P.z))===WATER;const onLad=get(Math.floor(P.x),Math.floor(P.y+0.5),Math.floor(P.z))===LADDER||get(Math.floor(P.x),Math.floor(P.y+1.2),Math.floor(P.z))===LADDER;
 const mx=(fx*c+fz*s)*sp*(inW?.5:1),mz=(fz*c-fx*s)*sp*(inW?.5:1);
 P.vx+=(mx-P.vx)*(P.onGround?0.35:0.08);P.vz+=(mz-P.vz)*(P.onGround?0.35:0.08);
 if(inW){const headAir=get(Math.floor(P.x),Math.floor(P.y+1.4),Math.floor(P.z))===AIR;
  if(keys.Space||tjump){P.vy=Math.min(P.vy+40*dt,headAir?7.5:4);}else P.vy=Math.max(P.vy-9*dt,-2.5);
  P.vy*=0.96;
  const py=Math.floor(P.y+0.5);const l=wl(Math.floor(P.x),py,Math.floor(P.z))&15;if(l&&l<8){for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=Math.floor(P.x)+dx,nz=Math.floor(P.z)+dz;if(get(nx,py,nz)===WATER&&(wl(nx,py,nz)&15)<l){P.vx+=dx*dt*3;P.vz+=dz*dt*3;}}}
 }else if(P.fly){P.vy=(keys.Space||tjump)?6:(keys.ShiftLeft?-6:0);}else if(onLad){P.vy=(keys.KeyW||keys.Space||tjump||tmove.y<-0.2)?3:(keys.ShiftLeft?0:-1.5);}else P.vy-=24*dt;
 if((keys.Space||tjump)&&P.onGround){P.vy=8.2;P.onGround=false;}
 let nx=P.x+P.vx*dt;if(!collide(nx,P.y,P.z))P.x=nx;else P.vx=0;
 let nz=P.z+P.vz*dt;if(!collide(P.x,P.y,nz))P.z=nz;else P.vz=0;
 let ny=P.y+P.vy*dt;if(!collide(P.x,ny,P.z)){P.y=ny;P.onGround=false;}else{if(P.vy<-14)damage(Math.floor((-P.vy-14)*0.6),'упал');if(P.vy<0)P.onGround=true;P.vy=0;}
 if(P.y<-10)damage(5,'пустота');
}
function damage(n,src){if(P.dead||n<=0||(P.creative&&src!=='команда'))return;P.hp-=n;$('dmg').style.opacity=.8;setTimeout(()=>$('dmg').style.opacity=0,200);if(P.hp<=0){die(src);}renderBars();}
function die(src){P.dead=true;$('dead').classList.add('on');$('deadmsg').textContent=['Ты умер.','Тебя не стало.','Он забрал тебя.','Свет погас.'][ri(0,3)];$('deadsub').textContent='Причина: '+src;document.exitPointerLock&&document.exitPointerLock();}
$('bRespawn').onclick=()=>{P.dead=false;P.hp=20;P.hunger=20;P.dread=Math.max(0,P.dread-30);if(S.home&&netOn){P.x=S.home.x;P.y=S.home.y;P.z=S.home.z;ensureAround(Math.floor(P.x),Math.floor(P.z),2);}else if(worldSpawn){P.x=worldSpawn.x;P.y=worldSpawn.y;P.z=worldSpawn.z;ensureAround(Math.floor(P.x),Math.floor(P.z),2);}else spawnPlayer();$('dead').classList.remove('on');renderBars();};
function spawnPlayer(){ // одинаковая для всех точка: первая суша по спирали от (0,0)
 let sx=0,sz=0,found=false;for(let r=0;r<12&&!found;r++){for(let dx=-r;dx<=r&&!found;dx++)for(let dz=-r;dz<=r&&!found;dz++){if(Math.max(Math.abs(dx),Math.abs(dz))!==r)continue;const x=dx*8,z=dz*8;ensureAround(x,z,1);if(topY(x,z)>SEA+1){sx=x;sz=z;found=true;}}}
 sx+=ri(-2,2);sz+=ri(-2,2);ensureAround(sx,sz,2);P.x=sx+.5;P.z=sz+.5;P.y=topY(sx,sz)+1.2;P.vx=P.vy=P.vz=0;}

/* ---- raycast ---- */
function ray(max){
 const ox=P.x,oy=P.y+1.62,oz=P.z;
 const dx=-Math.sin(P.yaw)*Math.cos(P.pitch),dy=Math.sin(P.pitch),dz=-Math.cos(P.yaw)*Math.cos(P.pitch);
 let x=Math.floor(ox),y=Math.floor(oy),z=Math.floor(oz);
 const sx=Math.sign(dx),sy=Math.sign(dy),sz=Math.sign(dz);
 const tdx=Math.abs(1/dx),tdy=Math.abs(1/dy),tdz=Math.abs(1/dz);
 let tx=(sx>0?(x+1-ox):(ox-x))*tdx,ty=(sy>0?(y+1-oy):(oy-y))*tdy,tz=(sz>0?(z+1-oz):(oz-z))*tdz;
 let face=[0,0,0];
 for(let i=0;i<max*3;i++){
  const b=get(x,y,z);if(b!==AIR&&b!==WATER)return{x,y,z,b,face};
  if(tx<ty&&tx<tz){if(tx>max)break;x+=sx;tx+=tdx;face=[-sx,0,0];}
  else if(ty<tz){if(ty>max)break;y+=sy;ty+=tdy;face=[0,-sy,0];}
  else{if(tz>max)break;z+=sz;tz+=tdz;face=[0,0,-sz];}
 }
 return null;
}
function rayWater(max){const ox=P.x,oy=P.y+1.62,oz=P.z;const dx=-Math.sin(P.yaw)*Math.cos(P.pitch),dy=Math.sin(P.pitch),dz=-Math.cos(P.yaw)*Math.cos(P.pitch);
 for(let t=0;t<max;t+=0.1){const x=Math.floor(ox+dx*t),y=Math.floor(oy+dy*t),z=Math.floor(oz+dz*t);const b=get(x,y,z);if(b===WATER)return{x,y,z};if(b!==AIR)return null;}return null;}
const hl=new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(1.002,1.002,1.002)),new THREE.LineBasicMaterial({color:0x000000}));scene.add(hl);
function mining(dt){
 const h=ray(5);hl.visible=!!h;if(h){hl.position.set(h.x+.5,h.y+.5,h.z+.5);}
 if(!mineDown&&!tbreak&&mineProg<900){mineProg=0;return;}
 if(!h){mineProg=0;hitMob();return;}
 if(isWand()){mineProg=0;return;}if(!canBuildHere(h.x,h.y,h.z)){if(mineProg===0)protectMsg(h.x,h.y,h.z);mineProg=0.01;return;}
 const k=h.x+','+h.y+','+h.z;if(mineTarget!==k){mineTarget=k;mineProg=0;}
 const tool=I[hot[P.sel]]||{};const pw=tool.power||1;const bi=I[h.b];
 let hard=bi.hard||3;if(h.b===VOID&&pw<8)hard=60;
 mineProg+=dt*pw*2.2;
 if(mineProg>=hard*0.35){mineProg=0;breakAt(h.x,h.y,h.z,true);}
}
function explode(x,y,z,r){for(let dx=-r;dx<=r;dx++)for(let dy=-r;dy<=r;dy++)for(let dz=-r;dz<=r;dz++){if(dx*dx+dy*dy+dz*dz>r*r)continue;const b=get(x+dx,y+dy,z+dz);if(b===AIR||b===WATER||b===VOID)continue;if(b===BOOM){setBlock(x+dx,y+dy,z+dz,AIR,true);setTimeout(()=>explode(x+dx,y+dy,z+dz,3),150);continue;}setBlock(x+dx,y+dy,z+dz,AIR,true);}
 const d=Math.hypot(P.x-x-.5,P.y+.9-y-.5,P.z-z-.5);if(d<r+2)damage(Math.ceil((r+2-d)*4),'взрыв');$('flash').style.opacity=.8;setTimeout(()=>$('flash').style.opacity=0,120);glitchT=0.4;beep();
 for(const m of [...mobs]){if(Math.hypot(m.x-x,m.y-y,m.z-z)<r+1&&!m.t.watcher&&!m.t.special){m.hp-=12;if(m.hp<=0)killMob(m);}}}
function breakAt(x,y,z,drop){const b=get(x,y,z);if(b===AIR)return;setBlock(x,y,z,AIR,true);
 if(b===BOOM){sys('Шипит… отойди!');setTimeout(()=>explode(x,y,z,3),3000);return;}NC._fire('break',{x,y,z,block:b});
 if(drop){const bi=I[b];const at=(id,n)=>spawnDrop(id,n,x+.5,y+.4,z+.5,rnd(-1,1),3,rnd(-1,1));
  if(bi.chance){for(let i=0;i<bi.chance.length;i+=2)if(Math.random()<bi.chance[i+1])at(N(bi.chance[i]),1);}
  else if(bi.drop!==null){at(bi.drop?N(bi.drop):b,1);}
  if(b===WHISPER)addDread(6);if(b===SIGIL){addDread(25);whisper('Ты сломал знак. Теперь он знает, где ты.');}if(b===MIRROR){at(N('Осколок зеркала'),2);addDread(10);}}}
/* ---- dropped items with physics ---- */
const drops=[];const texCache={};
function itemTex(id){if(texCache[id])return texCache[id];const t=new THREE.Texture();const im=new Image();im.onload=()=>{t.image=im;t.needsUpdate=true;};im.src=pixIcon(id);t.magFilter=THREE.NearestFilter;texCache[id]=t;return t;}
function spawnDrop(id,n,x,y,z,vx,vy,vz){if(id==null||id<0)return;const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:itemTex(id),transparent:true}));sp.scale.set(.45,.45,.45);sp.position.set(x,y,z);scene.add(sp);
 drops.push({id,n:n||1,x,y,z,vx:vx||0,vy:vy||0,vz:vz||0,mesh:sp,age:0,ph:Math.random()*6});}
function solidAt(x,y,z){const b=get(Math.floor(x),Math.floor(y),Math.floor(z));return b!==AIR&&I[b].solid!==false;}
function dropsTick(dt){for(const d of [...drops]){d.age+=dt;
 const inW=get(Math.floor(d.x),Math.floor(d.y),Math.floor(d.z))===WATER;
 d.vy-=(inW?4:22)*dt;if(inW){d.vy*=0.85;d.vx*=0.9;d.vz*=0.9;}
 let nx=d.x+d.vx*dt;if(!solidAt(nx,d.y,d.z))d.x=nx;else d.vx*=-0.4;
 let nz=d.z+d.vz*dt;if(!solidAt(d.x,d.y,nz))d.z=nz;else d.vz*=-0.4;
 let ny=d.y+d.vy*dt;if(!solidAt(d.x,ny-0.15,d.z)){d.y=ny;}else{if(d.vy<-3)d.vy=-d.vy*0.35;else d.vy=0;d.vx*=0.8;d.vz*=0.8;d.y=Math.floor(d.y-0.15)+1.15;}
 if(d.y<-5){scene.remove(d.mesh);drops.splice(drops.indexOf(d),1);continue;}
 d.mesh.position.set(d.x,d.y+Math.sin(time*3+d.ph)*0.06,d.z);
 // merge with same nearby
 for(const o of drops){if(o!==d&&o.id===d.id&&Math.hypot(o.x-d.x,o.y-d.y,o.z-d.z)<0.5){d.n+=o.n;scene.remove(o.mesh);drops.splice(drops.indexOf(o),1);break;}}
 // pickup
 if(d.age>0.6&&!P.dead&&Math.hypot(d.x-P.x,d.y-(P.y+0.8),d.z-P.z)<1.4){give(d.id,d.n);scene.remove(d.mesh);drops.splice(drops.indexOf(d),1);}
 else if(d.age>0.3&&Math.hypot(d.x-P.x,d.y-(P.y+0.8),d.z-P.z)<2.6){const k=Math.hypot(d.x-P.x,d.z-P.z)||1;d.vx-=(d.x-P.x)/k*dt*6;d.vz-=(d.z-P.z)/k*dt*6;}
 if(d.age>300){scene.remove(d.mesh);drops.splice(drops.indexOf(d),1);}
}}
function dropSelected(){const id=hot[P.sel];if(id<0)return;if(!take(id,1))return;const dx=-Math.sin(P.yaw),dz=-Math.cos(P.yaw);spawnDrop(id,1,P.x+dx*0.6,P.y+1.4,P.z+dz*0.6,dx*5,2.5,dz*5);}
function setBlock(x,y,z,v,net){if(y<0||y>=H)return;if(net&&netOn){if(!canBuildHere(x,y,z)){protectMsg(x,y,z);return;}prevBlocks.set(x+','+y+','+z,get(x,y,z));if(prevBlocks.size>400)prevBlocks.delete(prevBlocks.keys().next().value);}recordEdit(x,y,z,v);if(!inB(x,y,z))return;set(x,y,z,v);setwl(x,y,z,v===WATER?(8|16):0);enqAround(x,y,z);markDirty(x,y,z);if(net&&netOn)wsend({t:'block',x,y,z,v});}
function placeBlock(){const id=hot[P.sel];if(id<0)return;const it=I[id];if(it.wand){wandSel(2);return;}
 if(id===N('Пустое ведро')){const h=rayWater(5);if(h){take(id,1);give(N('Ведро воды'),1);setWater(h.x,h.y,h.z,0,false);recordEdit(h.x,h.y,h.z,AIR);if(netOn)wsend({t:'block',x:h.x,y:h.y,z:h.z,v:AIR});}return;}
 if(id===N('Ведро воды')){const h=ray(5);if(!h)return;const x=h.x+h.face[0],y=h.y+h.face[1],z=h.z+h.face[2];if(get(x,y,z)!==AIR)return;take(id,1);give(N('Пустое ведро'),1);setBlock(x,y,z,WATER,true);return;}
 { const h0=ray(5); if(h0){ if(h0.b===TABLE){openInv(3);return;} if(h0.b===DOORC||h0.b===DOORO){setBlock(h0.x,h0.y,h0.z,h0.b===DOORC?DOORO:DOORC,true);return;}
   if(h0.b===BED){if(isNight()){if(netOn)wsend({t:'chat',text:'/sleep'});else{time=Math.ceil(time/DAY)*DAY+40;}sys('Ты проспал до утра.');addDread(-10);}else sys('Спать можно только ночью.');return;} } }
 if(it.kind!=='block'){eatOrUse();return;}
 const h=ray(5);if(!h)return;const x=h.x+h.face[0],y=h.y+h.face[1],z=h.z+h.face[2];
 if(get(x,y,z)!==AIR&&get(x,y,z)!==WATER)return;
 if(it.solid!==false){ // don't place inside player
  const px=Math.floor(P.x),pz=Math.floor(P.z);if(x===px&&z===pz&&(y===Math.floor(P.y)||y===Math.floor(P.y+1)))return;}
 if(!P.creative&&!take(id,1))return;setBlock(x,y,z,id,true);NC._fire('place',{x,y,z,block:id});
 if(id===SALT)addDread(-2);if(id===FOGLAMP)addDread(-5);if(id===SIGIL){addDread(12);}
}
function eatOrUse(){const id=hot[P.sel];if(id<0)return;const it=I[id];if(it.kind!=='food')return;
 if(P.hunger>=20&&!it.hp&&!it.dread)return;take(id,1);P.hunger=clamp(P.hunger+it.food,0,20);if(it.hp)P.hp=clamp(P.hp+it.hp,0,20);if(it.dread)addDread(it.dread);renderBars();sys('Съедено: '+it.n);if(P.hp<=0)die(it.n);}
function addDread(n){P.dread=clamp(P.dread+n,0,100);$('dread').firstElementChild.style.width=P.dread+'%';}

/* ================= MOBS ================= */
const MOBS={
 mokhnach:{n:'Мохнач',c:0xd8d0c0,c2:0xe8e0d0,w:.9,h:.9,hp:8,hostile:false,drops:['Шерсть',2,'Сырое мясо',1],speed:1.4},
 krol:{n:'Кроль',c:0x8a6a4a,c2:0xa08060,w:.5,h:.5,hp:4,hostile:false,drops:['Сырое мясо',1,'Кожа',1],speed:2.6,hop:true},
 klyuv:{n:'Клюв',c:0xe0e0e0,c2:0xd04020,w:.5,h:.6,hp:4,hostile:false,drops:['Перо',2,'Сырое мясо',1],speed:1.2},
 klyk:{n:'Клык',c:0x5a4a3a,c2:0x302018,w:.8,h:.9,hp:14,hostile:true,dmg:3,drops:['Кожа',1,'Кость',1],speed:3.2},
 tennik:{n:'Тенник',c:0x101018,c2:0x303050,w:.6,h:1.9,hp:18,hostile:true,dmg:4,drops:['Слизь тумана',2,'Пустотный камень',1],speed:2.4,night:true,dread:true},
 svetlyak:{n:'Светляк',c:0xc8ffb0,c2:0xffffc0,w:.35,h:.35,hp:2,hostile:false,drops:['Лунная пыль',1],speed:1.6,fly:true},
 dreyf:{n:'Дрейф',c:0x9ad0c8,c2:0xc8f0e8,w:.9,h:.9,hp:10,hostile:false,drops:['Слизь тумана',3,'Туманное желе',1],speed:.8,fly:true},
 kostyak:{n:'Костяк',c:0xe8e4d8,c2:0x606060,w:.6,h:1.9,hp:16,hostile:true,dmg:3,drops:['Кость',3,'Кровавая ягода',1],speed:2.0,night:true},
 golem:{n:'Ржавый голем',c:0x8a4a2a,c2:0x503020,w:1.2,h:2.4,hp:40,hostile:true,dmg:6,drops:['Ржавый блок',2,'Железный слиток',2],speed:1.4,rare:true},
 watcher:{n:'Смотрящий',c:0x2a8a8a,c2:0x1a2030,w:.6,h:1.9,hp:9999,hostile:false,drops:[],speed:0,watcher:true},
 nulevoy:{n:'Нулевой',c:0x050508,c2:0x050508,w:.6,h:2.1,hp:9999,hostile:false,drops:[],speed:0,special:'nulevoy',eyes:true},
 dvoynik:{n:'Двойник',c:0x3a3a4a,c2:0xe0b090,w:.6,h:1.8,hp:9999,hostile:false,drops:[],speed:0,special:'dvoynik'},
 polzun:{n:'Ползун',c:0x2a1a1a,c2:0x4a2a2a,w:1.2,h:.45,hp:30,hostile:true,dmg:5,drops:['Кость',2,'Слизь тумана',2],speed:3.6,night:true,dread:true,crawl:true},
};
const mobs=[];
function mobMesh(t){const g=new THREE.Group();
 const body=new THREE.Mesh(new THREE.BoxGeometry(t.w,t.h*0.55,t.w*0.8),new THREE.MeshLambertMaterial({color:t.c}));body.position.y=t.h*0.5;g.add(body);
 const head=new THREE.Mesh(new THREE.BoxGeometry(t.w*0.7,t.h*0.35,t.w*0.7),new THREE.MeshLambertMaterial({color:t.c2}));head.position.y=t.h*0.95;head.position.z=t.w*0.2;g.add(head);
 if(t.watcher||t.eyes){const em=new THREE.MeshBasicMaterial({color:0xffffff});for(const s of[-1,1]){const e=new THREE.Mesh(new THREE.BoxGeometry(.12,.12,.05),em);e.position.set(s*.13,t.h*1.0,t.w*.56);g.add(e);}}
 if(!t.fly){for(const s of[-1,1]){const leg=new THREE.Mesh(new THREE.BoxGeometry(t.w*0.3,t.h*0.35,t.w*0.3),new THREE.MeshLambertMaterial({color:t.c2}));leg.position.set(s*t.w*0.25,t.h*0.17,0);g.add(leg);}}
 if(t.fly){const gl=new THREE.PointLight(t.c,0.6,6);gl.position.y=t.h*.6;g.add(gl);}
 scene.add(g);return g;}
function spawnMob(type,x,y,z){const t=MOBS[type];const m={type,t,x,y,z,vy:0,hp:t.hp,dir:rnd(0,6.28),tm:0,mesh:mobMesh(t),cool:0,hurt:0,born:time};mobs.push(m);return m;}
function killMob(m){scene.remove(m.mesh);mobs.splice(mobs.indexOf(m),1);}
function groundAt(x,y,z){let gy=Math.floor(y);while(gy>0&&get(Math.floor(x),gy-1,Math.floor(z))!==AIR&&I[get(Math.floor(x),gy-1,Math.floor(z))].solid===false)gy--;while(gy>0&&(get(Math.floor(x),gy-1,Math.floor(z))===AIR||I[get(Math.floor(x),gy-1,Math.floor(z))].solid===false))gy--;return gy;}
function mobTick(dt){
 const night=isNight();
 for(const m of [...mobs]){
  m.tm-=dt;m.cool-=dt;if(m.hurt>0)m.hurt-=dt;
  const dxp=P.x-m.x,dzp=P.z-m.z,dist=Math.hypot(dxp,dzp);
  if(m.t.watcher){watcherTick(m,dt,dist);continue;}
  if(m.t.special){specialTick(m,dt,dist);continue;}
  if(m.tm<=0){m.tm=rnd(1,4);m.dir=rnd(0,6.28);m.moving=Math.random()<0.6;}
  let sp=m.t.speed,dir=m.dir,moving=m.moving;
  if(m.t.hostile&&dist<14&&!P.dead){dir=Math.atan2(dxp,dzp);moving=true;sp*=1.3;
   if(dist<1.6&&m.cool<=0){m.cool=1.1;damage(m.t.dmg,m.t.n);if(m.t.dread)addDread(4);}}
  if(m.hurt>0){dir=Math.atan2(-dxp,-dzp);moving=true;sp*=2;}
  if(moving){const nx=m.x+Math.sin(dir)*sp*dt,nz=m.z+Math.cos(dir)*sp*dt;
   if(m.t.fly){m.x=nx;m.z=nz;m.y+=Math.sin(time*2+m.dir)*dt*0.6;const g=topY(Math.floor(m.x),Math.floor(m.z));m.y=clamp(m.y,g+1.5,g+7);}
   else{const gy=topY(Math.floor(nx),Math.floor(nz));if(gy>=0&&gy+1-m.y<1.2&&gy>SEA-1){m.x=nx;m.z=nz;if(gy+1>m.y)m.y=gy+1;}else m.dir+=2;
    if(m.t.hop&&Math.random()<0.05)m.vy=5;}
   m.mesh.rotation.y=dir;}
  if(!m.t.fly){const gt=topY(Math.floor(m.x),Math.floor(m.z));if(gt<0){killMob(m);continue;}m.vy-=20*dt;const ny=m.y+m.vy*dt;const gy=gt+1;if(ny<=gy){m.y=gy;m.vy=0;}else m.y=ny;}
  m.mesh.position.set(m.x,m.y,m.z);
  m.mesh.children.forEach((c,i)=>{if(i===0)c.material.emissive?.setHex(m.hurt>0?0x660000:0);});
  // despawn far
  if(dist>70&&Math.random()<0.01)killMob(m);
  if(m.t.night&&!night&&Math.random()<0.002){killMob(m);}
 }
 // spawning
 if(mobs.length<26&&Math.random()<0.02){
  const a=rnd(0,6.28),r=rnd(18,40);const x=Math.floor(P.x+Math.sin(a)*r),z=Math.floor(P.z+Math.cos(a)*r);
  if(inB(x,0,z)){const y=topY(x,z)+1;if(y>SEA){
   let pool=night?(horrorOn?['klyk','tennik','kostyak','tennik','svetlyak','mokhnach','polzun']:['klyk','klyk','mokhnach','svetlyak','kostyak']):['mokhnach','krol','klyuv','svetlyak','dreyf','klyk'];
   if(horrorOn&&P.dread>50)pool.push('tennik','polzun');if(Math.random()<0.02)pool=['golem'];
   spawnMob(pool[ri(0,pool.length-1)],x+.5,y,z+.5);}}}
}
const rc=new THREE.Raycaster();
/* ---- регионы (приват), кланы, pvp, жезл ---- */
let regions=[],clanMap={},pvpOn=true,wandA=null,wandB=null;const prevBlocks=new Map();
const isWand=()=>{const it=I[hot[P.sel]];return !!(it&&it.wand);};
function regionAt(x,y,z){for(const g of regions)if(x>=g.x1&&x<=g.x2&&z>=g.z1&&z<=g.z2&&y>=g.y1&&y<=g.y2)return g;return null;}
function canBuildHere(x,y,z){if(!netOn||isOp)return true;const g=regionAt(x,y,z);if(!g)return true;const n=P.name.toLowerCase();if(g.owner===n||g.members.includes(n))return true;const myClan=clanMap[P.name];if(myClan&&clanMap[g.owner]===myClan)return true;return false;}
function protectMsg(x,y,z){const g=regionAt(x,y,z);sys('Это приват'+(g?' «'+g.name+'» игрока '+g.owner:'')+'. Строить здесь нельзя.');}
function wandSel(n){const h=ray(6);if(!h){sys('Смотри на блок.');return;}if(n===1)wandA=[h.x,h.y,h.z];else wandB=[h.x,h.y,h.z];sys('Точка '+n+': '+h.x+' '+h.y+' '+h.z+(wandA&&wandB?' · область '+((Math.abs(wandA[0]-wandB[0])+1)*(Math.abs(wandA[2]-wandB[2])+1))+' блоков → /rg claim имя':''));}
function hitPlayer(){if(!netOn||hitCool>0)return false;rc.setFromCamera(new THREE.Vector2(0,0),camera);rc.far=4.5;for(const [id,o] of others){const hit=rc.intersectObject(o.g,true);if(hit.length){hitCool=0.4;const tool=I[hot[P.sel]]||{};wsend({t:'hit',id,dmg:tool.dmg||1});return true;}}return false;}
function hitMob(){if(hitCool>0)return;if(isWand()){wandSel(1);hitCool=0.3;return;}if(hitPlayer())return;
 rc.setFromCamera(new THREE.Vector2(0,0),camera);rc.far=4;
 for(const m of mobs){const hit=rc.intersectObject(m.mesh,true);if(hit.length){hitCool=0.35;const tool=I[hot[P.sel]]||{};const d=tool.dmg||1;
   if(m.t.watcher){addDread(20);whisper('Он не тот, кого можно ударить.');vanishWatcher(m);return;}
   m.hp-=d;m.hurt=0.4;if(tool.ward&&m.t.dread){m.hp-=6;addDread(-6);}
   if(m.hp<=0){for(let i=0;i<m.t.drops.length;i+=2)if(Math.random()<0.8)spawnDrop(N(m.t.drops[i]),ri(1,m.t.drops[i+1]),m.x,m.y+.5,m.z,rnd(-1.5,1.5),3,rnd(-1.5,1.5));killMob(m);if(m.t.hostile)addDread(-2);}
   return;}}}
let hitCool=0;

/* ---- the Watcher & mystical activity ---- */
let watcher=null,watchLook=0,nextEvent=25,glitchT=0;
const WHISPERS=['я тут','не оборачивайся','ты не один','это не твой мир','я строил это','выходи из воды','посмотри наверх','сзади','мы ждали','404','тот, кто смотрит, не моргает','не ставь свет','твои вещи — мои','я помню тебя','кто-то есть в шахте','твой дом стоит не там','иди спать','я зову тебя по имени','двери здесь никогда не было'];
function watcherTick(m,dt,dist){
 // faces player
 m.mesh.rotation.y=Math.atan2(P.x-m.x,P.z-m.z);m.mesh.position.set(m.x,m.y,m.z);
 // looked at?
 const dx=-Math.sin(P.yaw)*Math.cos(P.pitch),dz=-Math.cos(P.yaw)*Math.cos(P.pitch);
 const tx=(m.x-P.x)/dist,tz=(m.z-P.z)/dist;const dot=dx*tx+dz*tz;
 if(dot>0.96&&dist<60){watchLook+=dt;addDread(dt*3);if(watchLook>3.5){vanishWatcher(m);return;}}
 if(dist<6){addDread(15);whisper('…');vanishWatcher(m);return;}
 if(time-m.born>40)vanishWatcher(m);
}
/* ---- creepy specials ---- */
let specialCool=0;
function specialTick(m,dt,dist){m.st=(m.st||0)+dt;
 const dx=-Math.sin(P.yaw)*Math.cos(P.pitch),dz=-Math.cos(P.yaw)*Math.cos(P.pitch);const tx=(m.x-P.x)/(dist||1),tz=(m.z-P.z)/(dist||1);const looked=(dx*tx+dz*tz)>0.9;
 if(m.t.special==='nulevoy'){ // stands behind you; teleports when you look; sometimes strikes
  m.mesh.rotation.y=Math.atan2(P.x-m.x,P.z-m.z);
  if(looked){m.looks=(m.looks||0)+dt;glitchT=Math.max(glitchT,0.3);addDread(dt*6);
   if(m.looks>1.2){m.looks=0;const a=P.yaw+Math.PI+rnd(-0.6,0.6);const r=rnd(5,9);const nx=Math.floor(P.x+Math.sin(a)*r),nz=Math.floor(P.z+Math.cos(a)*r);if(inB(nx,0,nz)){m.x=nx+.5;m.z=nz+.5;m.y=topY(nx,nz)+1;}beep();m.tp=(m.tp||0)+1;if(m.tp>=4){vanishWatcher(m);whisper('0');return;}}}
  if(dist<2.2&&m.st>4){damage(5,'Нулевой');addDread(20);$('flash').style.opacity=.9;setTimeout(()=>$('flash').style.opacity=0,120);vanishWatcher(m);return;}
  if(m.st>50)vanishWatcher(m);}
 else if(m.t.special==='dvoynik'){ // mirrors your moves around an anchor point
  if(!m.ax){m.ax=(m.x+P.x)/2;m.az=(m.z+P.z)/2;}
  const nx=2*m.ax-P.x,nz=2*m.az-P.z;m.x+=(nx-m.x)*0.2;m.z+=(nz-m.z)*0.2;const gy=topY(Math.floor(m.x),Math.floor(m.z))+1;m.y+=(gy-m.y)*0.3;
  m.mesh.rotation.y=P.yaw+Math.PI;
  if(dist<3||m.st>45){vanishWatcher(m);whisper('ты — это я');addDread(12);return;}}
 m.mesh.position.set(m.x,m.y,m.z);}
function summonSpecial(type){const a=rnd(0,6.28),r=rnd(8,16);const x=Math.floor(P.x+Math.sin(a)*r),z=Math.floor(P.z+Math.cos(a)*r);if(!inB(x,0,z))return;const y=topY(x,z)+1;if(y<=SEA)return;spawnMob(type,x+.5,y,z+.5);}
let eyesT=0,eyesMesh=null,zovT=0,zovX=0,zovZ=0;
function skyEyes(){if(eyesMesh)return;const g=new THREE.Group();const mat=new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.85,fog:false});for(const s of[-1,1]){const e=new THREE.Mesh(new THREE.PlaneGeometry(6,3),mat);e.position.x=s*6;g.add(e);const p=new THREE.Mesh(new THREE.PlaneGeometry(1.6,3),new THREE.MeshBasicMaterial({color:0x000000,fog:false}));p.position.set(s*6,0,0.05);g.add(p);}
 scene.add(g);eyesMesh=g;eyesT=7;}
function creepyTick(dt){if(eyesMesh){eyesT-=dt;const a=P.yaw;eyesMesh.position.set(P.x-Math.sin(a)*60,P.y+35,P.z-Math.cos(a)*60);eyesMesh.lookAt(P.x,P.y,P.z);addDread(dt*2);if(eyesT<=0){scene.remove(eyesMesh);eyesMesh=null;}}
 if(zovT>0){zovT-=dt;const k=Math.hypot(zovX-P.x,zovZ-P.z)||1;P.vx+=(zovX-P.x)/k*dt*3;P.vz+=(zovZ-P.z)/k*dt*3;if(k<2){zovT=0;damage(2,'Зов');addDread(15);whisper('пришёл');}}}
function vanishWatcher(m){killMob(m);watcher=null;watchLook=0;$('flash').style.opacity=.6;setTimeout(()=>$('flash').style.opacity=0,80);glitchT=1.2;}
function summonWatcher(){if(watcher)return;const a=rnd(0,6.28),r=rnd(18,34);const x=Math.floor(P.x+Math.sin(a)*r),z=Math.floor(P.z+Math.cos(a)*r);if(!inB(x,0,z))return;const y=topY(x,z)+1;if(y<=SEA)return;watcher=spawnMob('watcher',x+.5,y,z+.5);}
function whisper(t){const d=document.createElement('div');d.className='whisper';d.textContent='<???> '+t;$('chat').appendChild(d);trimChat();beep();}
function mystic(dt){
 nextEvent-=dt*(1+P.dread/60)*S.myst;
 if(glitchT>0){glitchT-=dt;$('static').style.opacity=Math.random()*0.35;if(glitchT<=0)$('static').style.opacity=0;}
 $('vignette').style.opacity=P.dread/100;
 if(nextEvent>0)return;nextEvent=rnd(12,40)-P.dread/6;
 const r=Math.random()*100;
 if(r<22){whisper(WHISPERS[ri(0,WHISPERS.length-1)]);addDread(3);}
 else if(r<34){summonWatcher();}
 else if(r<40){summonSpecial(isNight()||P.dread>40?'nulevoy':'dvoynik');}
 else if(r<50){ // torches go out
  let n=0;for(const [k,v] of edits){if(v===TORCH&&Math.random()<0.5){const [x,y,z]=k.split(',').map(Number);setBlock(x,y,z,AIR,true);n++;}}if(n){sys('Факелы погасли.');addDread(8);}}
 else if(r<60){ // dead tree appears near player
  const x=Math.floor(P.x+ri(-8,8)),z=Math.floor(P.z+ri(-8,8));if(inB(x,0,z)){const y=topY(x,z);if(y>SEA){for(let i=1;i<=5;i++)setBlock(x,y+i,z,DEADWOOD,true);addDread(5);}}}
 else if(r<68){ // tunnel 2x2 dug
  const x=Math.floor(P.x+ri(-10,10)),z=Math.floor(P.z+ri(-10,10));const y=topY(x,z);const dir=ri(0,1);for(let i=0;i<7;i++)for(let h=0;h<2;h++)setBlock(x+(dir?i:0),y-1+h-Math.floor(i/2),z+(dir?0:i),AIR,true);sys('Где-то рядом кто-то копал.');addDread(6);}
 else if(r<76){ // sigil placed near
  const x=Math.floor(P.x+ri(-5,5)),z=Math.floor(P.z+ri(-5,5));const y=topY(x,z);if(y>SEA){setBlock(x,y+1,z,SIGIL,true);addDread(8);whisper('знак поставлен');}}
 else if(r<80){glitchT=1.5;sys('§k§l§');addDread(4);}
 else if(r<84){if(isNight())skyEyes();else{zovT=10;const a=rnd(0,6.28);zovX=P.x+Math.sin(a)*14;zovZ=P.z+Math.cos(a)*14;whisper(P.name.toLowerCase()+'… иди сюда');}}
 else if(r<90){ // sky flash red
  redSky=6;whisper('небо помнит');addDread(6);}
 else if(r<95){ // player inventory item stolen
  if(inv.size){const ks=[...inv.keys()];const id=ks[ri(0,ks.length-1)];take(id,1);sys('Пропал предмет: '+I[id].n);addDread(10);}}
 else{ // candles circle
  const x=Math.floor(P.x),z=Math.floor(P.z);for(let a=0;a<8;a++){const px=Math.round(x+Math.cos(a/8*6.283)*4),pz=Math.round(z+Math.sin(a/8*6.283)*4);const py=topY(px,pz);if(py>SEA&&get(px,py+1,pz)===AIR)setBlock(px,py+1,pz,CANDLE,true);}whisper('круг замкнут');addDread(12);}
 if(P.dread>=100){damage(3,'страх');addDread(-20);whisper('хватит');}
}
let redSky=0;
/* audio */
let actx=null;function beep(){try{if(!actx)actx=new (window.AudioContext||window.webkitAudioContext)();const o=actx.createOscillator(),g=actx.createGain();o.type='sine';o.frequency.value=rnd(90,180);g.gain.value=0.0001;g.gain.exponentialRampToValueAtTime(0.12*S.vol/60+0.0001,actx.currentTime+0.4);g.gain.exponentialRampToValueAtTime(0.0001,actx.currentTime+2.2);o.connect(g);g.connect(actx.destination);o.start();o.stop(actx.currentTime+2.3);}catch(e){}}

/* ================= DAY / NIGHT ================= */
let time=0;const DAY=420;
const isNight=()=>{const t=(time%DAY)/DAY;return t>0.55&&t<0.95;};
function sky(){const t=(time%DAY)/DAY;let day=Math.cos((t-0.25)*6.283)*0.5+0.5;day=Math.pow(day,0.7);
 const dark=new THREE.Color(0x05050c),light=new THREE.Color(0x9aa7c0),dusk=new THREE.Color(0x6b4a52);
 let c=dark.clone().lerp(light,day);if(day>0.3&&day<0.6)c.lerp(dusk,0.4);
 if(redSky>0){redSky-=1/60;c.lerp(new THREE.Color(0x6a1010),0.6);}
 if(weather==='rain'||weather==='storm'){c.lerp(new THREE.Color(0x3a3f4a),0.5);if(weather==='storm'&&Math.random()<0.003){$('flash').style.opacity=.7;setTimeout(()=>$('flash').style.opacity=0,90);}}
 const dr=P.dread/100;c.lerp(new THREE.Color(0x1a1420),dr*0.4);
 scene.background=c;scene.fog.color=c;const ds=S.dist/90*(weather==='clear'?1:0.6);scene.fog.near=(8+day*14-dr*6)*ds;scene.fog.far=(28+day*70-dr*30)*ds;
 sun.intensity=0.15+day*0.9;hemi.intensity=0.35+day*0.6;sun.position.set(Math.cos(t*6.283)*80,Math.sin(t*6.283)*80+10,20);}

/* ================= UI ================= */
function hexc(c,m){m=m||1;const f=v=>Math.round(clamp(v*255*m,0,255)).toString(16).padStart(2,'0');return '#'+f(c[0])+f(c[1])+f(c[2]);}
function svgIcon(id){const it=I[id],c=it.c;let b='';
 if(it.kind==='block'){const top=it.top||c,side=it.side||c;
  b=`<polygon points="16,3 29,10 16,17 3,10" fill="${hexc(top,1.05)}"/><polygon points="3,10 16,17 16,31 3,24" fill="${hexc(side,0.8)}"/><polygon points="29,10 16,17 16,31 29,24" fill="${hexc(side,0.62)}"/>`+(it.tr?`<polygon points="16,3 29,10 16,17 3,10" fill="#fff" opacity=".25"/>`:'')+(it.light?`<circle cx="16" cy="12" r="4" fill="#fff5c0" opacity=".9"/>`:'');
  if(id===TORCH||id===CANDLE||id===FOGLAMP)b=`<rect x="13" y="12" width="6" height="18" fill="${hexc([.5,.38,.2])}"/><rect x="11" y="6" width="10" height="8" fill="${hexc(c)}"/><circle cx="16" cy="8" r="7" fill="#ffe08a" opacity=".45"/>`;}
 else if(it.kind==='food'){b=`<ellipse cx="16" cy="18" rx="11" ry="10" fill="${hexc(c)}"/><ellipse cx="12" cy="14" rx="4" ry="3" fill="#fff" opacity=".35"/><rect x="15" y="5" width="2" height="5" fill="#5a3a1a"/><path d="M17 7 q4 -4 6 0 q-3 3 -6 0z" fill="#4a7a2a"/>`;}
 else if(it.kind==='tool'){const n=it.n;const hc=hexc(c);
  if(/меч|клинок/.test(n))b=`<rect x="14" y="2" width="4" height="18" fill="${hc}"/><polygon points="14,2 18,2 16,-1" fill="${hc}"/><rect x="9" y="19" width="14" height="3" fill="#8a6a30"/><rect x="14" y="22" width="4" height="9" fill="#5a3a1a"/>`;
  else if(/посох/.test(n))b=`<rect x="15" y="6" width="3" height="25" fill="#7a5a30" transform="rotate(15 16 18)"/><circle cx="17" cy="6" r="5" fill="${hc}"/><circle cx="17" cy="6" r="2" fill="#fff" opacity=".6"/>`;
  else b=`<rect x="15" y="9" width="3" height="22" fill="#7a5a30" transform="rotate(35 16 20)"/><path d="M4 12 q12 -10 24 0 l-3 4 q-9 -7 -18 0z" fill="${hc}"/>`;}
 else{b=`<polygon points="16,4 27,16 16,28 5,16" fill="${hexc(c)}"/><polygon points="16,4 27,16 16,16" fill="#fff" opacity=".25"/><polygon points="16,16 16,28 5,16" fill="#000" opacity=".2"/>`;}
 return 'data:image/svg+xml,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" shape-rendering="crispEdges">${b}</svg>`);}
const iconCache={};
function pixIcon(id){if(iconCache[id])return iconCache[id];const it=I[id],c=it.c;const cv=document.createElement('canvas');cv.width=cv.height=16;const g=cv.getContext('2d');
 const col=(cc,m)=>`rgb(${clamp(cc[0]*255*(m||1),0,255)|0},${clamp(cc[1]*255*(m||1),0,255)|0},${clamp(cc[2]*255*(m||1),0,255)|0})`;
 const px=(x,y,cc,m)=>{g.fillStyle=col(cc,m);g.fillRect(x,y,1,1);};
 if(it.kind==='block'){const t=TEX[it.k]!=null?TEX[it.k]:null;const top=TEX[it.k+'_top']!=null?TEX[it.k+'_top']:t;
  const draw=(tile,dx,dy,dw,dh,shade)=>{if(tile==null)return;g.save();g.imageSmoothingEnabled=false;g.drawImage(ATLAS,(tile%16)*16,Math.floor(tile/16)*16,16,16,dx,dy,dw,dh);if(shade<1){g.globalAlpha=1-shade;g.fillStyle='#000';g.fillRect(dx,dy,dw,dh);}g.restore();};
  if(id===TORCH||id===CANDLE||id===FOGLAMP||id===LADDER||id===DOORC||id===FENCE){draw(t,0,0,16,16,1);}
  else{g.save();g.beginPath();g.moveTo(8,1);g.lineTo(15,5);g.lineTo(8,9);g.lineTo(1,5);g.closePath();g.clip();draw(top,1,1,14,8,1);g.restore();
   g.save();g.beginPath();g.moveTo(1,5);g.lineTo(8,9);g.lineTo(8,16);g.lineTo(1,12);g.closePath();g.clip();draw(t,1,5,7,11,.75);g.restore();
   g.save();g.beginPath();g.moveTo(8,9);g.lineTo(15,5);g.lineTo(15,12);g.lineTo(8,16);g.closePath();g.clip();draw(t,8,5,7,11,.55);g.restore();}}
 else if(it.kind==='tool'){const n=it.n;const h=[.5,.36,.2],hd=[.35,.25,.13];
  if(/меч|клинок/.test(n)){for(let i=0;i<9;i++){px(12-i,3+i,c);px(13-i,3+i,c,1.15);}px(4,11,hd);px(3,12,hd);px(5,12,hd);px(2,13,h);px(1,14,h);px(4,10,hd);}
  else if(/посох/.test(n)){for(let i=0;i<11;i++)px(4+i,14-i,h);px(13,2,c);px(14,2,c);px(13,3,c);px(14,3,c,1.2);px(12,3,c,.8);px(13,4,c,.8);}
  else{for(let i=0;i<9;i++)px(4+i,13-i,h);px(9,2,c);px(10,2,c);px(11,2,c);px(12,3,c);px(13,4,c);px(8,3,c);px(7,4,c);px(6,5,c,.8);px(13,5,c,.8);px(12,2,c,1.2);px(11,3,c,1.1);}}
 else if(it.kind==='food'){const n=it.n;
  if(/хлеб|печенье|лепёшка|пирог/i.test(n)){for(let y=6;y<12;y++)for(let x=2;x<14;x++)px(x,y,c,(y===6||x===2)?1.2:(y===11||x===13)?.7:1);for(let x=4;x<12;x+=3)px(x,8,c,.6);}
  else if(/похлёбка|чай|желе|мёд/i.test(n)){for(let y=7;y<13;y++)for(let x=3;x<13;x++)px(x,y,[.55,.4,.25],(y===12||x===12)?.6:1);for(let y=6;y<9;y++)for(let x=4;x<12;x++)px(x,y,c,y===6?1.2:1);}
  else if(/мясо|кость/i.test(n)){for(let y=4;y<12;y++)for(let x=3;x<12;x++)if(hash2(x,y,id)<.85)px(x,y,c,(x+y)%3===0?.8:1);px(12,11,[.9,.88,.8]);px(13,12,[.9,.88,.8]);px(12,13,[.9,.88,.8]);}
  else{for(let y=4;y<14;y++)for(let x=3;x<13;x++){const d=(x-8)**2/25+(y-9)**2/25;if(d<1)px(x,y,c,d<.35?1.15:d>.8?.7:1);}px(8,3,[.4,.27,.12]);px(8,2,[.4,.27,.12]);px(9,3,[.3,.55,.2]);px(10,2,[.3,.55,.2]);}}
 else{const n=it.n;
  if(/слиток/.test(n)){for(let y=6;y<12;y++)for(let x=2;x<14;x++)px(x,y,c,y===6?1.2:y===11?.65:x>11?.8:1);}
  else if(/палка|ветка/i.test(n)){for(let i=0;i<11;i++){px(3+i,13-i,c);px(4+i,13-i,c,.7);}}
  else if(/пыль|соль|уголь/i.test(n)){for(let y=5;y<14;y++)for(let x=3;x<13;x++)if(hash2(x,y,id)<.6)px(x,y,c,.8+hash2(y,x,id)*.5);}
  else if(/ведро/i.test(n)){for(let y=5;y<13;y++)for(let x=4+(y>10?1:0);x<12-(y>10?1:0);x++)px(x,y,c,x===4?1.2:x===11?.7:1);for(let i=0;i<5;i++)px(5+i,4-(i===2?1:0),[.5,.5,.5]);if(/воды/.test(n))for(let x=5;x<11;x++)px(x,5,[.3,.45,.8]);}
  else if(/перо/i.test(n)){for(let i=0;i<10;i++){px(4+i,13-i,c);px(5+i,13-i,c,.8);if(i%2)px(3+i,13-i,c,.9);}}
  else{for(let y=3;y<14;y++)for(let x=3;x<14;x++){const d=Math.abs(x-8)+Math.abs(y-8);if(d<6)px(x,y,c,d<2?1.2:d>4?.7:1);}}}
 return iconCache[id]=cv.toDataURL();}
function iconFor(id){const im=document.createElement('img');im.className='ic';im.src=pixIcon(id);im.alt=I[id].n;return im;}

function iconForOld(id){const c=I[id].c;const cv=document.createElement('canvas');cv.width=cv.height=8;const g=cv.getContext('2d');for(let y=0;y<8;y++)for(let x=0;x<8;x++){const v=0.85+hash2(x,y,id)*0.3;g.fillStyle=`rgb(${c[0]*255*v|0},${c[1]*255*v|0},${c[2]*255*v|0})`;g.fillRect(x,y,1,1);}
 const k=I[id].kind;if(k==='tool'){g.clearRect(0,0,8,8);g.fillStyle=`rgb(${c[0]*255|0},${c[1]*255|0},${c[2]*255|0})`;g.fillRect(3,0,3,3);g.fillRect(1,1,6,1);g.fillStyle='#7a5a30';for(let i=0;i<5;i++)g.fillRect(3-i*0+i,3+i,1,1);}
 else if(k==='food'){g.clearRect(0,0,8,8);g.fillStyle=`rgb(${c[0]*255|0},${c[1]*255|0},${c[2]*255|0})`;g.beginPath();g.arc(4,4.5,3,0,7);g.fill();g.fillStyle='#4a6a2a';g.fillRect(4,1,1,1);}
 else if(k==='misc'){g.clearRect(0,0,8,8);g.fillStyle=`rgb(${c[0]*255|0},${c[1]*255|0},${c[2]*255|0})`;g.fillRect(2,2,4,4);g.fillRect(3,1,2,6);g.fillRect(1,3,6,2);}
 const im=document.createElement('img');im.className='ic';im.src=cv.toDataURL();im.alt=I[id].n;return im;}
function renderHot(){const hb=$('hotbar');hb.innerHTML='';for(let i=0;i<9;i++){const st=SL[i];const s=document.createElement('div');s.className='slot'+(i===P.sel?' sel':'');if(st){s.appendChild(iconFor(st.id));if(st.n>1){const n=document.createElement('span');n.className='n';n.textContent=st.n;s.appendChild(n);}}s.onclick=()=>{P.sel=i;renderHot();};hb.appendChild(s);}
 const id=hot[P.sel];const sn=$('sel-name');sn.textContent=id>=0?I[id].n:'';sn.style.opacity=1;clearTimeout(sn._t);sn._t=setTimeout(()=>sn.style.opacity=0,1500);}
function renderBars(){const hp=$('hp'),hu=$('hu');hp.innerHTML='';hu.innerHTML='';for(let i=0;i<10;i++){const a=document.createElement('i');a.className='pip'+(P.hp>=i*2+2?' hp':P.hp>=i*2+1?' hp half':'');hp.appendChild(a);const b=document.createElement('i');b.className='pip'+(P.hunger>=i*2+2?' hu':P.hunger>=i*2+1?' hu half':'');hu.appendChild(b);}}
let invOpen=false,craftW=2,craftGrid=[],craftOut=null,cursor=null; // cursor: {id,n} в руке
function openInv(w){craftW=w||2;craftGrid=Array(craftW*craftW).fill(null);craftOut=null;invOpen=true;$('inv').classList.add('on');document.exitPointerLock&&document.exitPointerLock();renderInv();}
function closeInv(){for(let i=0;i<craftGrid.length;i++){if(craftGrid[i]){give(craftGrid[i].id,craftGrid[i].n);craftGrid[i]=null;}}
 if(cursor){give(cursor.id,cursor.n);cursor=null;}invOpen=false;$('inv').classList.remove('on');$('cursorItem').hidden=true;renderHot();}
function toggleInv(){if(invOpen)closeInv();else openInv(2);}
function mkSlot(stack,cls){const s=document.createElement('div');s.className='islot '+(cls||'');if(stack){s.appendChild(iconFor(stack.id));if(stack.n>1){const n=document.createElement('span');n.className='n';n.textContent=stack.n;s.appendChild(n);}s.title=I[stack.id].n+(I[stack.id].desc?' — '+I[stack.id].desc:'');}return s;}
function slotClick(get,set,e,isOut){const st=get();const ms=st?MAXST(st.id):64;
 if(isOut){if(!st)return;if(!cursor){cursor={id:st.id,n:st.n};}else if(cursor.id===st.id&&cursor.n+st.n<=MAXST(st.id)){cursor.n+=st.n;}else return;craftConsume();return;}
 if(e.button===2){
  if(!cursor){if(st){const half=Math.ceil(st.n/2);cursor={id:st.id,n:half};st.n-=half;set(st.n>0?st:null);}}
  else{if(!st){set({id:cursor.id,n:1});cursor.n--;}else if(st.id===cursor.id&&st.n<ms){st.n++;cursor.n--;set(st);}if(cursor.n<=0)cursor=null;}
  return;}
 if(!cursor){if(st){cursor={id:st.id,n:st.n};set(null);}}
 else if(!st){set({id:cursor.id,n:cursor.n});cursor=null;}
 else if(st.id===cursor.id){const add=Math.min(ms-st.n,cursor.n);st.n+=add;cursor.n-=add;set(st);if(cursor.n<=0)cursor=null;}
 else{const t={id:st.id,n:st.n};set({id:cursor.id,n:cursor.n});cursor=t;}}
function craftConsume(){for(let i=0;i<craftGrid.length;i++){if(craftGrid[i]){craftGrid[i].n--;if(craftGrid[i].n<=0)craftGrid[i]=null;}}}
function slotHandlers(s,get,set,quickA,quickB){s.onmousedown=e=>{e.preventDefault();const st=get();if(e.shiftKey&&st&&quickA!=null){set(null);const left=giveRange(st.id,st.n,quickA,quickB);if(left>0)set({id:st.id,n:left});renderInv();return;}slotClick(get,set,e);renderInv();};s.oncontextmenu=e=>e.preventDefault();
 // touch: tap = left click, long press = right click
 let t0=0;s.addEventListener('touchstart',e=>{t0=performance.now();},{passive:true});s.addEventListener('touchend',e=>{e.preventDefault();const long=performance.now()-t0>350;slotClick(get,set,{button:long?2:0});renderInv();});}
function renderInv(){const g=$('invgrid');g.innerHTML='';$('invtitle').textContent=craftW===3?'ВЕРСТАК':'ИНВЕНТАРЬ';
 const cr=$('craftarea');cr.innerHTML='';cr.style.gridTemplateColumns='repeat('+craftW+',var(--isl)) 40px var(--isl)';
 craftOut=craftMatch(craftGrid,craftW);
 for(let i=0;i<craftW*craftW;i++){const s=mkSlot(craftGrid[i]);s.style.gridColumn=(i%craftW)+1;s.style.gridRow=Math.floor(i/craftW)+1;slotHandlers(s,()=>craftGrid[i],v=>craftGrid[i]=v,9,36);cr.appendChild(s);}
 const ar=document.createElement('div');ar.className='carrow';ar.textContent='→';ar.style.gridColumn=craftW+1;ar.style.gridRow='1 / span '+craftW;cr.appendChild(ar);
 const o=mkSlot(craftOut,'out');o.style.gridColumn=craftW+2;o.style.gridRow='1 / span '+craftW;
 const takeOut=e=>{if(e.shiftKey&&craftOut){let guard=0;while(craftOut&&guard++<64){give(craftOut.id,craftOut.n);craftConsume();craftOut=craftMatch(craftGrid,craftW);}renderInv();return;}slotClick(()=>craftOut,()=>{},e,true);renderInv();};
 o.onmousedown=e=>{e.preventDefault();takeOut(e);};o.oncontextmenu=e=>e.preventDefault();o.addEventListener('touchend',e=>{e.preventDefault();takeOut({button:0});});cr.appendChild(o);
 for(let i=9;i<36;i++){const s=mkSlot(SL[i]);slotHandlers(s,()=>SL[i],v=>SL[i]=v,0,9);g.appendChild(s);}
 const hb=$('invhot');hb.innerHTML='';for(let i=0;i<9;i++){const s=mkSlot(SL[i],i===P.sel?'sel':'');slotHandlers(s,()=>SL[i],v=>SL[i]=v,9,36);hb.appendChild(s);}
 const rb=$('recipebook');rb.innerHTML='';const seen=new Set();for(const s of SHAPES){const id=N(s.out[0]);if(id==null||seen.has(id))continue;seen.add(id);const d=mkSlot({id,n:1},'rb');d.title='Рецепт: '+s.out[0]+' — '+s.rows.map(r=>r.map(x=>x||'·').join(' + ')).join(' / ');
  const lay=()=>{if(s.rows.length>craftW||Math.max(...s.rows.map(r=>r.length))>craftW){$('invinfo').textContent='Нужен верстак (3×3) для: '+s.out[0];return;}
   for(let i=0;i<craftGrid.length;i++)if(craftGrid[i]){give(craftGrid[i].id,craftGrid[i].n);craftGrid[i]=null;}
   let ok=true;for(let r=0;r<s.rows.length;r++)for(let c=0;c<s.rows[r].length;c++){const nm=s.rows[r][c];if(!nm)continue;const iid=N(nm);if(has(iid,1)){take(iid,1);craftGrid[r*craftW+c]={id:iid,n:1};}else ok=false;}
   $('invinfo').textContent=ok?'Рецепт выложен: '+s.out[0]:'Не хватает материалов для: '+s.out[0]+' ('+s.rows.map(r=>r.filter(Boolean).join(', ')).join(', ')+')';renderInv();};
  d.onmousedown=e=>{e.preventDefault();lay();};d.addEventListener('touchend',e=>{e.preventDefault();lay();});rb.appendChild(d);}
 renderHot();updCursor();}
function giveRange(id,n,a,b){const ms=MAXST(id);for(let i=a;i<b&&n>0;i++){const s=SL[i];if(s&&s.id===id&&s.n<ms){const add=Math.min(ms-s.n,n);s.n+=add;n-=add;}}for(let i=a;i<b&&n>0;i++){if(!SL[i]){const add=Math.min(ms,n);SL[i]={id,n:add};n-=add;}}return n;}
function updCursor(){const c=$('cursorItem');if(!cursor){c.hidden=true;return;}c.hidden=false;c.innerHTML='';c.appendChild(iconFor(cursor.id));if(cursor.n>1){const n=document.createElement('span');n.className='n';n.textContent=cursor.n;c.appendChild(n);}}
addEventListener('mousemove',e=>{if(!invOpen||!cursor)return;const c=$('cursorItem');c.style.left=e.clientX+'px';c.style.top=e.clientY+'px';});
addEventListener('touchmove',e=>{if(!invOpen||!cursor)return;const t=e.touches[0];const c=$('cursorItem');c.style.left=t.clientX+'px';c.style.top=(t.clientY-40)+'px';},{passive:true});
$('bCloseInv').onclick=closeInv;
$('inv').addEventListener('mousedown',e=>{if(e.target===$('inv')&&cursor){dropSelectedStack(cursor);cursor=null;renderInv();}});
function dropSelectedStack(st){const dx=-Math.sin(P.yaw),dz=-Math.cos(P.yaw);spawnDrop(st.id,st.n,P.x+dx*0.6,P.y+1.4,P.z+dz*0.6,dx*5,2.5,dz*5);}
function setName(v){v=String(v).replace(/[^A-Za-z0-9_]/g,'').slice(0,16)||'Player';P.name=v;setCookie('nc_name',v);try{localStorage.setItem('nc_name',v);}catch(e){}}
try{const nm=getCookie('nc_name')||localStorage.getItem('nc_name');if(nm){P.name=nm;}}catch(e){}
$('pname').value=P.name==='Player'?'':P.name;$('pname').oninput=()=>setName($('pname').value);
/* chat */
let chatOpen=false;
const CMD_HINTS=[['help','список команд'],['sethome','запомнить дом'],['home','телепорт домой'],['wand','жезл выделения региона'],['rg claim <имя>','заприватить выделение'],['rg addmember <регион> <игрок>','доступ к привату'],['rg info','чей приват здесь'],['clan create <имя>','создать клан'],['clan invite <игрок>','пригласить в клан'],['clan accept','принять приглашение'],['c <текст>','чат клана'],['pvp on|off','pvp на сервере (op)'],['list','кто на сервере'],['say <текст>','сообщение от сервера'],['sleep','утро'],['gamemode creative|survival','режим игры'],['tp x y z | tp игрок','телепорт'],['give [игрок] предмет [n]','выдать предмет'],['time day|night','время'],['spawn тип [n]','призвать моба'],['op имя','дать права'],['deop имя','снять права'],['kick имя','выгнать'],['ban имя','забанить'],['unban имя','разбанить'],['whitelist on|off|add|remove','белый список'],['blacklist add|remove','чёрный список'],['horror enable|disable','хоррор'],['weather clear|rain|storm','погода'],['broadcast <текст>','объявление'],['motd <текст>','приветствие'],['stop','остановить сервер'],['restart','перезапуск'],['run by|in|from …','выполнить от имени'],['heal','вылечить'],['fly','полёт'],['sethome','дом'],['home','к дому'],['clear','очистить инвентарь'],['seed','сид'],['pos','координаты'],['skin url','скин'],['clearmobs','убрать мобов'],['setmax n','лимит игроков'],['name имя','название сервера'],['plugins core on|off','встроенный плагин'],['setblock x y z блок','поставить блок'],['fill x1 y1 z1 x2 y2 z2 блок','заполнить область'],['summon тип [n]','призвать'],['tell игрок текст','личное сообщение'],['me текст','действие'],['pardon имя','разбанить'],['setworldspawn','точка появления мира'],['spawnpoint','своя точка появления'],['save-all','сохранить'],['teleport …','= tp'],['time set day|night|noon|midnight','время']];
function updHints(){const v=$('chatin').value;const h=$('hints');if(!v.startsWith('/')){h.hidden=true;return;}const q=v.slice(1).toLowerCase().split(' ')[0];const list=CMD_HINTS.filter(([c])=>c.split(' ')[0].startsWith(q)).slice(0,8);if(!list.length||(netOn&&!isOp)){h.hidden=true;return;}h.innerHTML='';for(const [c,d] of list){const row=document.createElement('div');row.textContent='/'+c+' — '+d;row.onclick=()=>{$('chatin').value='/'+c.split(' ')[0]+' ';$('chatin').focus();updHints();};h.appendChild(row);}h.hidden=false;}
$('chatin').addEventListener('input',updHints);
$('chatin').addEventListener('keydown',e=>{if(e.key==='Tab'){e.preventDefault();const q=$('chatin').value.slice(1).toLowerCase().split(' ')[0];const m=CMD_HINTS.find(([c])=>c.split(' ')[0].startsWith(q));if(m)$('chatin').value='/'+m[0].split(' ')[0]+' ';updHints();}});
function openChat(){chatOpen=true;$('chatin').style.display='block';$('chatin').focus();updHints();document.exitPointerLock&&document.exitPointerLock();}
function closeChat(){chatOpen=false;$('chatin').style.display='none';$('chatin').value='';$('hints').hidden=true;}
function localCmd(t){const a=t.slice(1).split(/\s+/);const c=a[0].toLowerCase();
 if(c==='time'){if(a[1]==='set'||a[1]==='add')a.splice(1,1);time=a[1]==='day'||a[1]==='день'?40:a[1]==='night'||a[1]==='ночь'?260:a[1]==='noon'?100:a[1]==='midnight'?300:+a[1]||time;return 'время: '+(time|0);}
 if(c==='give'){const n=+a[a.length-1]||1;const nm=a.slice(1,isNaN(+a[a.length-1])?undefined:-1).join(' ');const id=N(nm);if(id==null)return 'нет предмета: '+nm;give(id,n);return 'выдано: '+nm+' ×'+n;}
 if(c==='tp'){if(a.length>=4){P.x=+a[1];P.y=+a[2];P.z=+a[3];return 'телепорт';}return '/tp x y z';}
 if(c==='spawn'){for(let i=0;i<(+a[2]||1);i++)spawnMob(MOBS[a[1]]?a[1]:'klyk',P.x+rnd(-3,3),P.y+1,P.z+rnd(-3,3));return 'спавн';}
 if(c==='heal'){P.hp=20;P.hunger=20;renderBars();return 'здоровье восстановлено';}
 if(c==='kill'){die('команда');return 'ты умер';}
 if(c==='clear'){inv.clear();hot.fill(-1);renderHot();return 'инвентарь очищен';}
 if(c==='sethome'){S.home={x:P.x,y:P.y,z:P.z};saveS();return 'дом установлен';}
 if(c==='home'){if(!S.home)return 'дом не установлен (/sethome)';P.x=S.home.x;P.y=S.home.y;P.z=S.home.z;return 'дома';}
 if(c==='fly'){P.fly=!P.fly;return P.fly?'полёт включён (пробел/shift)':'полёт выключен';}
 if(c==='creative'||c==='gamemode'){const arg=(a[1]||'').toLowerCase();P.creative=c==='gamemode'?(arg==='creative'||arg==='1'||arg==='c'):(arg==='0'||arg==='survival'?false:!P.creative);if(P.creative){for(let i=1;i<I.length&&i<40;i++)if(!I[i].hide&&!has(i,1))give(i,I[i].kind==='tool'?1:64);}renderHot();return P.creative?'творческий режим: все предметы, нет урона':'режим выживания';}
 if(c==='seed')return 'сид мира: '+worldSeed;
 if(c==='skin'){if(!a[1]){S.skin=null;saveS();return 'стандартный скин';}S.skin=a[1];saveS();return 'скин: '+a[1];}
 if(c==='horror'){horrorOn=a[1]==='enable'||a[1]==='on'||a[1]==='вкл';if(!horrorOn){$('vignette').style.opacity=0;}return 'хоррор '+(horrorOn?'включён':'выключен');}
 if(c==='dread'){P.dread=clamp(+a[1]||0,0,100);addDread(0);return 'тревога: '+P.dread;}
 if(c==='pos')return 'XYZ '+P.x.toFixed(1)+' '+P.y.toFixed(1)+' '+P.z.toFixed(1);
 if(c==='setblock'){const id=blockByName(a.slice(4).join(' '));if(id==null)return 'нет блока';setBlock(+a[1],+a[2],+a[3],id,true);return 'поставлено';}
 if(c==='fill'){const id=blockByName(a.slice(7).join(' '));if(id==null)return 'нет блока';let n=0;for(let x=Math.min(+a[1],+a[4]);x<=Math.max(+a[1],+a[4])&&n<20000;x++)for(let y=Math.min(+a[2],+a[5]);y<=Math.max(+a[2],+a[5]);y++)for(let z=Math.min(+a[3],+a[6]);z<=Math.max(+a[3],+a[6]);z++){ensureAround(x,z,0);setBlock(x,y,z,id,true);n++;}return 'заполнено: '+n;}
 if(c==='summon')return localCmd('/spawn '+a.slice(1).join(' '));
 if(c==='teleport')return localCmd('/tp '+a.slice(1).join(' '));
 if(c==='me'){addChat('*',P.name+' '+a.slice(1).join(' '));return '';}
 if(c==='say'){addChat('[сервер]',a.slice(1).join(' '));return '';}
 if(c==='setworldspawn'||c==='spawnpoint'){S.home={x:P.x,y:P.y,z:P.z};saveS();return 'точка появления установлена';}
 if(c==='save-all'||c==='save'){saveWorld(false);return 'сохраняю…';}
 if(c==='weather'){weather=a[1]||'clear';$('rain').style.opacity=weather==='rain'||weather==='storm'?1:0;return 'погода: '+weather;}
 if(c==='xp'||c==='effect'||c==='difficulty')return 'в loopcraft нет опыта/эффектов';
 if(c==='help')return 'локально: /time set /give /tp /summon /setblock /fill /heal /kill /clear /sethome /home /spawnpoint /fly /gamemode /seed /weather /say /me · на сервере: /help';
 if(c==='sleep'){time=Math.ceil(time/DAY)*DAY+40;return 'утро';}
 return 'неизвестная команда';}
const LOCAL_CMDS=['heal','kill','clear','sethome','home','fly','creative','gamemode','seed','dread','pos','skin','setblock','fill','summon','weather'];
const CLIENT_ONLY=['pos','dread','skin','creative'];
function runCmd(t){const a=t.slice(1).split(/\s+/);const c=a[0].toLowerCase();
 if(!netOn){if(c==='wand'){give(N('Жезл региона'),1);console_('жезл выдан (приват работает только на сервере)');return;}if(c==='rg'||c==='clan'||c==='c'){console_('регионы и кланы работают только на сервере');return;}console_(localCmd(t));return;}
 if(CLIENT_ONLY.includes(c)||(isOp&&LOCAL_CMDS.includes(c)&&!['sethome','home','heal','kill','clear','fly'].includes(c))){console_(localCmd(t));return;}
 if(c==='rg'&&(a[1]||'').toLowerCase()==='claim'){if(!wandA||!wandB){console_('сначала /wand и выдели две точки (ЛКМ / ПКМ)');return;}t='/rg claim '+(a[2]||'')+' '+wandA.join(' ')+' '+wandB.join(' ');}
 wsend({t:'chat',text:t});}
function console_(t){addChat('консоль',t,'sys');const l=$('conlog');if(l){l.textContent+=t+'\n';l.scrollTop=1e9;}}
$('conin').addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Enter'){const t=$('conin').value.trim();$('conin').value='';if(!t)return;const l=$('conlog');l.textContent+='> '+t+'\n';runCmd(t.startsWith('/')?t:'/'+t);}});
$('bConsole').onclick=()=>{const c=$('console');c.hidden=!c.hidden;if(!c.hidden)$('conin').focus();};
function sendChat(){const t=$('chatin').value.trim();closeChat();if(!t)return;if(t.startsWith('/')){runCmd(t);return;}addChat(P.name,t);if(netOn)wsend({t:'chat',text:t});
 if(/кто ты|ты кто|кто здесь|who/i.test(t))setTimeout(()=>whisper(['я','никто','ты'][ri(0,2)]),1500);}
function addChat(n,t,cls){const d=document.createElement('div');if(cls)d.className=cls;d.textContent='<'+n+'> '+t;$('chat').appendChild(d);trimChat();
 if(!cls&&S.tts&&n!==P.name){try{const u=new SpeechSynthesisUtterance(n+': '+t);u.lang='ru-RU';speechSynthesis.speak(u);}catch(e){}}}
function sys(t){addChat('*',t,'sys');}
function trimChat(){const c=$('chat');while(c.children.length>8)c.removeChild(c.firstChild);}
/* pause */
let paused=false;
function togglePause(){paused=!paused;if(paused){saveWorld(true);renderFriends();$('bPanel').href='servers_panel/?tok='+encodeURIComponent(ACCT||'');}$('pause').classList.toggle('on',paused);if(paused){document.exitPointerLock&&document.exitPointerLock();$('linkbox').value=shareLink();}}
$('bResume').onclick=togglePause;
function loadInv(l){for(let i=0;i<36;i++)SL[i]=null;if(Array.isArray(l.inv)&&l.inv.length===36&&!l.hot){l.inv.forEach((s,i)=>{if(s&&I[s[0]])SL[i]={id:s[0],n:s[1]};});}else{const hotIds=l.hot||[];(l.inv||[]).forEach(([i,c])=>{if(!I[i])return;const hi=hotIds.indexOf(i);if(hi>=0&&!SL[hi])SL[hi]={id:i,n:Math.min(c,MAXST(i))};const left=c-(hi>=0&&SL[hi]?SL[hi].n:0);if(left>0)giveRange(i,left,9,36);});}}
function saveData(){return JSON.stringify({seed:worldSeed,code:worldCode,edits:[...edits],p:{x:P.x,y:P.y,z:P.z,hp:P.hp,hunger:P.hunger,dread:P.dread},inv:SL.map(s=>s?[s.id,s.n]:null),time});}
async function saveWorld(quiet){if(!playing)return;const j=saveData();try{localStorage.setItem('nc_save',j);}catch(e){}
 try{const r=await fetch(NODE+'api/world?tok='+TOK+'&name='+encodeURIComponent(worldName||worldCode||'local'),{method:'POST',headers:authH(),body:j});if(!r.ok)throw 0;if(!quiet)sys('Мир сохранён на сервере.');}catch(e){if(!quiet)sys('Сервер недоступен — сохранено только в браузере.');}}
async function loadWorld(name){try{const r=await fetch(NODE+'api/world?tok='+TOK+'&name='+encodeURIComponent(name),{headers:authH()});if(r.ok)return await r.json();}catch(e){}try{const s=localStorage.getItem('nc_save');if(s)return JSON.parse(s);}catch(e){}return null;}
$('bSave').onclick=()=>saveWorld(false);
setInterval(()=>{if(playing&&!P.dead)saveWorld(true);},30000);
addEventListener('beforeunload',()=>{if(playing){try{localStorage.setItem('nc_save',saveData());navigator.sendBeacon&&!ACCT&&navigator.sendBeacon(NODE+'api/world?tok='+TOK+'&name='+encodeURIComponent(worldName||worldCode||'local'),saveData());}catch(e){}}});
$('bCopy').onclick=()=>{const t=$('linkbox').value;navigator.clipboard?.writeText(t).then(()=>sys('Ссылка скопирована.')).catch(()=>{$('linkbox').select();});};
$('bToMenu').onclick=()=>{saveWorld(true);setTimeout(()=>{location.href=location.href.split('#')[0];},300);};
/* touch */
const isPhoneUA=/Android|iPhone|iPad|iPod|Mobile|Tablet/i.test(navigator.userAgent)||(navigator.maxTouchPoints>1&&/Macintosh/.test(navigator.userAgent));
if(S.touchV!==2){S.touch=null;}
const isTouch=(S.touch==null?(isPhoneUA||(!matchMedia('(any-pointer:fine)').matches&&('ontouchstart' in window))):!!S.touch);
const tmove={x:0,y:0};let tjump=false,tbreak=false;
if(isTouch){$('touch').classList.add('on');document.body.classList.add('touchmode');
 // ---- крестовина (как в Bedrock): кнопки ↑ ↓ ← →, диагонали, двойной тап ↑ = бег ----
 const dpad={KeyW:false,KeyS:false,KeyA:false,KeyD:false};let lastUp=0;
 const updMove=()=>{tmove.x=(dpad.KeyD?1:0)-(dpad.KeyA?1:0);tmove.y=(dpad.KeyS?1:0)-(dpad.KeyW?1:0);};
 for(const [id,k] of [['dU','KeyW'],['dD','KeyS'],['dL','KeyA'],['dR','KeyD']]){const el=$(id);
  el.addEventListener('pointerdown',e=>{e.preventDefault();el.setPointerCapture&&el.setPointerCapture(e.pointerId);dpad[k]=true;el.classList.add('down');if(k==='KeyW'){const now=performance.now();if(now-lastUp<300){sprintT=true;$('dU').classList.add('sprint');}lastUp=now;}updMove();});
  const off=e=>{dpad[k]=false;el.classList.remove('down');if(k==='KeyW'){sprintT=false;$('dU').classList.remove('sprint');}updMove();};
  el.addEventListener('pointerup',off);el.addEventListener('pointercancel',off);}
 // ---- обзор + тап/долгое нажатие по миру (как в Bedrock: тап = поставить/использовать, удержание = ломать/бить) ----
 let lid=null,lx=0,ly=0,tapT=0,tapMoved=false,holdTimer=null,holding=false;
 canvas.addEventListener('pointerdown',e=>{if(!playing||invOpen||paused||setOpen)return;e.preventDefault();lid=e.pointerId;lx=e.clientX;ly=e.clientY;tapT=performance.now();tapMoved=false;holding=false;canvas.setPointerCapture&&canvas.setPointerCapture(e.pointerId);
  clearTimeout(holdTimer);holdTimer=setTimeout(()=>{if(lid!==null&&!tapMoved){holding=true;tbreak=true;hitMob();}},350);});
 canvas.addEventListener('pointermove',e=>{if(e.pointerId!==lid)return;const k=0.0009*S.sens;const dx=e.clientX-lx,dy=e.clientY-ly;if(Math.abs(dx)+Math.abs(dy)>8&&!holding)tapMoved=true;P.yaw-=dx*k;P.pitch=clamp(P.pitch-dy*k*(S.inv?-1:1),-1.55,1.55);lx=e.clientX;ly=e.clientY;});
 const tapEnd=e=>{if(e.pointerId!==lid)return;lid=null;clearTimeout(holdTimer);if(holding){holding=false;tbreak=false;mineProg=0;return;}if(!tapMoved&&performance.now()-tapT<350){placeBlock();}};
 canvas.addEventListener('pointerup',tapEnd);canvas.addEventListener('pointercancel',tapEnd);
 // ---- кнопки справа ----
 const hold=(id,on,off)=>{const el=$(id);el.addEventListener('pointerdown',e=>{e.preventDefault();el.classList.add('down');on();});const o=()=>{el.classList.remove('down');off();};el.addEventListener('pointerup',o);el.addEventListener('pointercancel',o);el.addEventListener('pointerleave',o);};
 hold('tjump',()=>tjump=true,()=>tjump=false);
 hold('ttab',()=>showTab(true),()=>showTab(false));
 hold('tsneak',()=>keys.ShiftLeft=true,()=>keys.ShiftLeft=false);
 $('tchat').addEventListener('pointerdown',e=>{e.preventDefault();openChat();});
 $('tinv').addEventListener('pointerdown',e=>{e.preventDefault();toggleInv();});
 $('tmenu').addEventListener('pointerdown',e=>{e.preventDefault();togglePause();});
 // выбор слота: тап по горячей панели (уже есть onclick), удержание слота = выбросить
 $('hotbar').addEventListener('contextmenu',e=>e.preventDefault());
}

/* ================= MULTIPLAYER (WebSocket via nginx → node) ================= */
const BASE=location.pathname.replace(/[^/]*$/,'');
// игровой сервер (node) доступен напрямую на порту 3000 — не зависит от настроек nginx
const NODE=(location.protocol==='https:'?'https://':'http://')+location.hostname+':3000/';
const WSURL=(location.protocol==='https:'?'wss://':'ws://')+location.hostname+':3000/ws';
let roomClosed=false,isOwner=false,isOp=false,serverName='',horrorOn=false,coreOn=true,weather='clear';
let createOpts={};let worldName='';let worldSpawn=null;
function blockByName(n){n=String(n||'').toLowerCase().replace(/^minecraft:/,'');for(let i=1;i<I.length;i++){if(I[i].kind!=='block')continue;if(I[i].n.toLowerCase()===n||(I[i].k&&I[i].k===n)||String(i)===n)return i;}if(n==='air'||n==='воздух')return AIR;return null;}
let ws=null,myId=null,worldCode='',others=new Map(),netOn=false,roomMods=[],roomPack=null;
function shareLink(){const u=location.href.split('#')[0].split('?')[0];return worldCode?u+'#'+worldCode+'   (адрес: '+location.host+':'+worldCode+')':u;}
const CODE_RE=/^[a-z0-9][a-z0-9_\-]{2,23}$/;
function codeFromSeed(s){return String(s);}
function seedFromCode(c){c=String(c).trim().toLowerCase();return CODE_RE.test(c)?1:null;}
function wsend(o){if(ws&&ws.readyState===1)ws.send(JSON.stringify(o));}
function connect(code){
 try{ws=new WebSocket(WSURL);}catch(e){$('netst').textContent='Сеть: не удалось открыть соединение';return;}
 ws.onopen=()=>{wsend({t:'join',room:code,name:P.name,create:!!createOpts.create,serverName:createOpts.name,max:createOpts.max,public:createOpts.public,panelPw:createOpts.panelPw,token:ACCT||undefined});};
 ws.onclose=()=>{if(roomClosed)return;netOn=false;$('netst').textContent='Сеть: нет связи с портом 3000, переподключаюсь…';updPlayersCount();sys('Нет связи с игровым сервером (порт 3000).');for(const id of [...others.keys()])removeOther(id);setTimeout(()=>{if(playing&&worldCode)connect(worldCode);},3000);};
 ws.onerror=()=>{};
 ws.onmessage=ev=>{let m;try{m=JSON.parse(ev.data);}catch(e){return;}
  if(m.t==='closed'&&/Создатель сервера вышел/.test(String(m.reason||''))){return;}
  if(m.t==='closed'){roomClosed=true;netOn=false;paused=false;$('pause').classList.remove('on');document.exitPointerLock&&document.exitPointerLock();$('dead').classList.add('on');$('deadmsg').textContent='Мир закрыт';$('deadsub').textContent=String(m.reason||'Создатель мира вышел')+'. Возвращаемся в меню…';$('bRespawn').style.display='none';setTimeout(()=>{location.href=location.href.split('#')[0];},4000);return;}
  if(m.t==='welcome'){myId=m.id;isOwner=!!m.owner;isOp=!!m.op;worldSpawn=m.spawn||null;serverName=String(m.name||code);if(m.time!=null)time=+m.time;netOn=true;horrorOn=!!m.horror;coreOn=m.core!==false;weather=String(m.weather||'clear');$('rain').style.opacity=weather==='rain'||weather==='storm'?1:0;regions=m.regions||[];pvpOn=m.pvp!==false;clanMap=m.clans||{};if(m.motd)sys(m.motd);$('netst').textContent='Сеть: подключено · мир '+code;
   if(m.seed&&m.seed!==worldSeed){worldSeed=m.seed;genWorld(worldSeed);clearEdits();spawnPlayer();}
   for(const k in m.edits)applyEdit(k,m.edits[k]);
   buildAll();for(const p of m.players)updOther(p);
   sys('Сетевой мир '+code+'. Игроков: '+(m.players.length+1)+'. Ссылка — в паузе (Esc).');if(isOwner)sys('Ты создатель сервера. Панель: /minecraft/servers_panel/ (вход аккаунтом).');
   applyRoomMods(m.mods||[]);applyRoomPack(m.pack||null);applyRoomPlugins(m.plugins||[]);if(isOp)sys('Ты оператор. Консоль: клавиша / или кнопка в паузе.');}
  else if(m.t==='pos')updOther(m);
  else if(m.t==='joined'){sys(String(m.name||'Кто-то').slice(0,16)+' вошёл в мир.');voicePeerJoined(m.id);}
  else if(m.t==='left'){removeOther(m.id);voicePeerLeft(m.id);}
  else if(m.t==='block'){if(I[m.v])setBlock(m.x|0,m.y|0,m.z|0,m.v|0,false);}
  else if(m.t==='chat'){addChat((clanMap[m.name]?'['+clanMap[m.name]+'] ':'')+String(m.name||'?').slice(0,16),String(m.text||'').slice(0,200));NC._fire('chat',{name:m.name,text:m.text,id:m.id});}
  else if(m.t==='mods')applyRoomMods(m.mods||[]);
  else if(m.t==='console')console_(String(m.text||''));
  else if(m.t==='op'){isOp=!!m.op;sys(isOp?'Ты теперь оператор. Команды: /help':'Права оператора сняты.');updPlayersCount();}
  else if(m.t==='tp'){P.x=+m.x;P.y=+m.y;P.z=+m.z;P.vx=P.vy=P.vz=0;sys('Тебя телепортировали.');}
  else if(m.t==='give'){const id=N(String(m.item||''));if(id!=null){give(id,+m.n||1);sys('Получено: '+m.item+' ×'+(+m.n||1));}else console_('нет предмета: '+m.item);}
  else if(m.t==='settime'){time=+m.time||40;}
  else if(m.t==='gamemode'){console_(localCmd('/gamemode '+(m.mode||'survival')));}
  else if(m.t==='spawn'){for(let i=0;i<(+m.n||1);i++)spawnMob(MOBS[m.mob]?m.mob:'klyk',P.x+rnd(-3,3),P.y+1,P.z+rnd(-3,3));}
  else if(m.t==='info'){if(m.name)serverName=String(m.name);}
  else if(m.t==='plugins')applyRoomPlugins(m.plugins||[]);
  else if(m.t==='horror'){horrorOn=!!m.horror;sys(horrorOn?'Хоррор включён. Что-то проснулось.':'Хоррор выключен.');if(!horrorOn)$('vignette').style.opacity=0;}
  else if(m.t==='core'){coreOn=!!m.core;sys('Плагин core '+(coreOn?'включён':'выключен'));}
  else if(m.t==='restart'){sys('Перезапуск сервера…');saveWorld(true);setTimeout(()=>location.reload(),1500);}
  else if(m.t==='broadcast'){const b=$('bcast');b.textContent=String(m.text||'');b.style.opacity=1;clearTimeout(b._t);b._t=setTimeout(()=>b.style.opacity=0,6000);}
  else if(m.t==='weather'){weather=String(m.weather||'clear');$('rain').style.opacity=weather==='rain'||weather==='storm'?1:0;sys('Погода: '+weather);}
  else if(m.t==='clearmobs'){for(const mm of [...mobs])killMob(mm);}
  else if(m.t==='kill'){P.hp=0;die('команда');}
  else if(m.t==='clearinv'){inv.clear();sys('Инвентарь очищен.');}
  else if(m.t==='heal'){P.hp=20;P.hunger=20;renderBars();sys('Здоровье восстановлено.');}
  else if(m.t==='fly'){P.fly=!P.fly;sys(P.fly?'Полёт включён.':'Полёт выключен.');}
  else if(m.t==='setspawn'){if(m.personal){S.home={x:m.x,y:m.y,z:m.z};saveS();}else worldSpawn={x:m.x,y:m.y,z:m.z};}
  else if(m.t==='setblock'){const id=blockByName(m.block);if(id==null){console_('нет блока: '+m.block);}else{ensureAround(m.x|0,m.z|0,1);setBlock(m.x|0,m.y|0,m.z|0,id,true);}}
  else if(m.t==='fill'){const id=blockByName(m.block);if(id==null){console_('нет блока: '+m.block);}else{const [x1,y1,z1]=m.a,[x2,y2,z2]=m.b;let n=0;for(let x=Math.min(x1,x2);x<=Math.max(x1,x2)&&n<20000;x++)for(let y=Math.min(y1,y2);y<=Math.max(y1,y2);y++)for(let z=Math.min(z1,z2);z<=Math.max(z1,z2);z++){ensureAround(x,z,0);setBlock(x,y,z,id,true);n++;}console_('заполнено блоков: '+n);}}
  else if(m.t==='pack')applyRoomPack(m.pack||null);
  else if(m.t==='rtc')voiceSignal(m.from,m.data);
  else if(m.t==='protect'){const k=m.x+','+m.y+','+m.z;const v=m.v!=null?m.v:prevBlocks.get(k);if(v!=null)setBlock(m.x,m.y,m.z,v,false);sys('Приват'+(m.name?' «'+m.name+'» ('+m.owner+')':'')+': изменять нельзя.');}
  else if(m.t==='hurt'){const dx=P.x-m.x,dz=P.z-m.z,l=Math.hypot(dx,dz)||1;P.vx+=dx/l*7;P.vz+=dz/l*7;P.vy=Math.max(P.vy,3.5);damage(+m.dmg||1,'игрок '+m.from);addDread(3);}
  else if(m.t==='regions'){regions=m.regions||[];}
  else if(m.t==='clans'){clanMap=m.map||{};renderTab();}
  else if(m.t==='pvp'){pvpOn=!!m.pvp;sys('PvP '+(pvpOn?'включено':'выключено'));}
  else if(m.t==='event')NC._fire('net:'+m.name,m.data,m.id);
  updPlayersCount();};
}
let lockHintT=0;
function lockHint(){if(isTouch||!playing||paused||invOpen||setOpen||chatOpen){$('lockhint').hidden=true;return;}$('lockhint').hidden=locked;}
setInterval(lockHint,500);
function updPlayersCount(){$('topright').textContent=(netOn?'онлайн · ':'нет связи · ')+'игроков: '+(others.size+1);$('bConsole').hidden=netOn&&!isOp;$('console').hidden=$('console').hidden||(netOn&&!isOp);}
/* ---- player figures: default boxes (PNG skin 32x32 regions) or Blockbench .bbmodel ---- */
function regionUV(geom,rx,ry,rw,rh){const uv=geom.attributes.uv;for(let i=0;i<uv.count;i++){uv.setXY(i,(rx+uv.getX(i)*rw)/32,1-(ry+(1-uv.getY(i))*rh)/32);}uv.needsUpdate=true;}
function defaultFigure(tex){const g=new THREE.Group();const mat=tex?new THREE.MeshLambertMaterial({map:tex}):null;const c=new THREE.Color().setHSL(Math.random(),.5,.5);
 const part=(w,h,d,x,y,z,rx,ry,col)=>{const geo=new THREE.BoxGeometry(w,h,d);if(tex)regionUV(geo,rx,ry,16,16);const m=new THREE.Mesh(geo,tex?mat:new THREE.MeshLambertMaterial({color:col}));m.position.set(x,y,z);g.add(m);return m;};
 part(.5,.5,.5,0,1.8,0,0,0,0xe0b090); part(.6,.9,.35,0,1.1,0,16,0,c.getHex());
 part(.25,.7,.3,-.16,.35,0,0,16,0x334455); part(.25,.7,.3,.16,.35,0,0,16,0x334455);
 part(.22,.8,.3,-.42,1.1,0,16,16,c.getHex()); part(.22,.8,.3,.42,1.1,0,16,16,c.getHex());
 return g;}
function bbFigure(json){const g=new THREE.Group();const res=json.resolution||{width:64,height:64};let tex=null;
 const src=json.textures&&json.textures[0]&&(json.textures[0].source||json.textures[0].image);if(src){tex=new THREE.TextureLoader().load(src);tex.magFilter=THREE.NearestFilter;tex.minFilter=THREE.NearestFilter;}
 const mat=tex?new THREE.MeshLambertMaterial({map:tex,transparent:true,alphaTest:.5}):new THREE.MeshLambertMaterial({color:0x888888});
 const order=['east','west','up','down','south','north'];let minY=1e9,maxY=-1e9;
 for(const el of (json.elements||[])){if(el.type&&el.type!=='cube')continue;const f=el.from,t=el.to;if(!f||!t)continue;const sz=[t[0]-f[0],t[1]-f[1],t[2]-f[2]].map(v=>Math.max(v,0.01)/16);
  const geo=new THREE.BoxGeometry(sz[0],sz[1],sz[2]);const uv=geo.attributes.uv;
  order.forEach((face,fi)=>{const fd=el.faces&&el.faces[face];const u=fd&&fd.uv?fd.uv:[0,0,res.width,res.height];const u0=u[0]/res.width,u1=u[2]/res.width,v0=1-u[1]/res.height,v1=1-u[3]/res.height;
   const b=fi*4;uv.setXY(b,u0,v0);uv.setXY(b+1,u1,v0);uv.setXY(b+2,u0,v1);uv.setXY(b+3,u1,v1);});
  const m=new THREE.Mesh(geo,mat);const cx=(f[0]+t[0])/32,cy=(f[1]+t[1])/32,cz=(f[2]+t[2])/32;
  if(el.rotation&&el.origin){const o=el.origin.map(v=>v/16);const piv=new THREE.Group();piv.position.set(o[0],o[1],o[2]);m.position.set(cx-o[0],cy-o[1],cz-o[2]);const r=el.rotation;piv.rotation.set((r[0]||0)*Math.PI/180,(r[1]||0)*Math.PI/180,(r[2]||0)*Math.PI/180);piv.add(m);g.add(piv);}
  else{m.position.set(cx,cy,cz);g.add(m);}
  minY=Math.min(minY,f[1]/16);maxY=Math.max(maxY,t[1]/16);}
 const hgt=maxY-minY||1;const sc=1.9/hgt;g.scale.set(sc,sc,sc);g.position.y=-minY*sc;const wrap=new THREE.Group();wrap.add(g);return wrap;}
function makeFigure(skinUrl){const g=new THREE.Group();let body=defaultFigure(null);g.add(body);
 const tag=new THREE.Sprite(new THREE.SpriteMaterial({transparent:true,depthTest:false}));tag.position.y=2.35;tag.scale.set(1.6,.4,1);g.add(tag);g.userData.tag=tag;
 if(skinUrl){if(/\.(bbmodel|json)(\?|$)/i.test(skinUrl)){fetch(skinUrl).then(r=>r.json()).then(j=>{const f=bbFigure(j);g.remove(body);body=f;g.add(f);}).catch(()=>{});}
  else{new THREE.TextureLoader().load(skinUrl,t=>{t.magFilter=THREE.NearestFilter;t.minFilter=THREE.NearestFilter;const f=defaultFigure(t);g.remove(body);body=f;g.add(f);});}}
 return g;}
/* ---- skin editor (32x32: голова 0,0 · тело 16,0 · ноги 0,16 · руки 16,16) ---- */
const SK={cv:null,ctx:null,color:'#e0b090',tool:'pen',scale:10};
const SKPAL=['#e0b090','#8a5a3a','#3a2a1a','#111111','#ffffff','#c8102e','#2b6cb0','#2e8b57','#f2c94c','#8e44ad','#7f8c8d','#f39c12','#1abc9c','#e91e63','#5d4037','#00bcd4'];
function skinInit(){if(SK.cv)return;SK.cv=$('skcanvas');SK.ctx=SK.cv.getContext('2d');SK.ctx.imageSmoothingEnabled=false;const pal=$('skpal');pal.innerHTML='';for(const c of SKPAL){const b=document.createElement('button');b.className='skc';b.style.background=c;b.onclick=()=>{SK.color=c;$('skcur').style.background=c;};pal.appendChild(b);}
 $('skcolor').oninput=()=>{SK.color=$('skcolor').value;$('skcur').style.background=SK.color;};
 SK.ctx.fillStyle='#e0b090';SK.ctx.fillRect(0,0,16,16);SK.ctx.fillStyle='#2b6cb0';SK.ctx.fillRect(16,0,16,16);SK.ctx.fillStyle='#334455';SK.ctx.fillRect(0,16,16,16);SK.ctx.fillStyle='#2b6cb0';SK.ctx.fillRect(16,16,16,16);
 SK.ctx.fillStyle='#111';SK.ctx.fillRect(4,6,2,2);SK.ctx.fillRect(10,6,2,2);SK.ctx.fillStyle='#8a5a3a';SK.ctx.fillRect(0,0,16,3);
 let down=false;const px=e=>{const r=SK.cv.getBoundingClientRect();return[Math.floor((e.clientX-r.left)/r.width*32),Math.floor((e.clientY-r.top)/r.height*32)];};
 const paint=e=>{const [x,y]=px(e);if(x<0||y<0||x>31||y>31)return;if(SK.tool==='fill'){fill(x,y);return;}SK.ctx.fillStyle=SK.tool==='eraser'?'#000000':SK.color;SK.ctx.fillRect(x,y,1,1);skPreview();};
 const fill=(x,y)=>{const im=SK.ctx.getImageData(0,0,32,32);const d=im.data;const i0=(y*32+x)*4;const tgt=[d[i0],d[i0+1],d[i0+2]];const nc=SK.color;const rr=parseInt(nc.slice(1,3),16),gg=parseInt(nc.slice(3,5),16),bb=parseInt(nc.slice(5,7),16);if(tgt[0]===rr&&tgt[1]===gg&&tgt[2]===bb)return;const st=[[x,y]];while(st.length){const [a,b]=st.pop();if(a<0||b<0||a>31||b>31)continue;const i=(b*32+a)*4;if(d[i]!==tgt[0]||d[i+1]!==tgt[1]||d[i+2]!==tgt[2])continue;d[i]=rr;d[i+1]=gg;d[i+2]=bb;d[i+3]=255;st.push([a+1,b],[a-1,b],[a,b+1],[a,b-1]);}SK.ctx.putImageData(im,0,0);skPreview();};
 SK.cv.addEventListener('pointerdown',e=>{down=true;paint(e);});SK.cv.addEventListener('pointermove',e=>{if(down)paint(e);});addEventListener('pointerup',()=>down=false);
 $('sktools').querySelectorAll('button').forEach(b=>b.onclick=()=>{SK.tool=b.dataset.t;$('sktools').querySelectorAll('button').forEach(x=>x.classList.toggle('on',x===b));});
 $('skload').onchange=()=>{const f=$('skload').files[0];if(!f)return;const im=new Image();im.onload=()=>{SK.ctx.clearRect(0,0,32,32);SK.ctx.drawImage(im,0,0,32,32);skPreview();};im.src=URL.createObjectURL(f);};
 $('sksave').onclick=async()=>{SK.cv.toBlob(async b=>{try{const r=await upload('skins',(ACCN||P.name||'skin').replace(/\W/g,'_')+'_'+Date.now()+'.png',b);S.skin=NODE+r.url.replace(/^\//,'');saveS();$('s_skin_st').textContent='скин сохранён и надет';sys('Скин сохранён.');}catch(e){$('s_skin_st').textContent='не удалось загрузить';}},'image/png');};
 skPreview();}
let skPrev=null;
function skPreview(){const pc=$('skprev');pc.width=160;pc.height=200;const c=pc.getContext('2d');c.imageSmoothingEnabled=false;c.clearRect(0,0,160,200);
 const d=(sx,sy,x,y,w,h)=>c.drawImage(SK.cv,sx,sy,16,16,x,y,w,h);d(0,0,55,10,50,50);d(16,0,50,60,60,80);d(0,16,50,140,30,55);d(0,16,80,140,30,55);d(16,16,28,60,22,70);d(16,16,110,60,22,70);}
function toggleSkinEd(){const e=$('skined');e.hidden=!e.hidden;if(!e.hidden)skinInit();}
$('s_skined').onclick=toggleSkinEd;$('skclose').onclick=toggleSkinEd;
function updOther(p){if(p.id===myId)return;let o=others.get(p.id);
 if(!o||o.skin!==(p.skin||null)){if(o)scene.remove(o.g);const g=makeFigure(p.skin||null);scene.add(g);o={g,tag:g.userData.tag,tx:p.x,ty:p.y,tz:p.z,ry:p.ry||0,name:'',skin:p.skin||null};others.set(p.id,o);g.position.set(p.x,p.y,p.z);}
 o.tx=p.x;o.ty=p.y;o.tz=p.z;o.ry=p.ry||0;const raw=String(p.name||'Игрок').replace(/[<>]/g,'').slice(0,16);const nm=(clanMap[raw]?'['+clanMap[raw]+'] ':'')+raw;
 if(nm!==o.name){o.name=nm;const cv=document.createElement('canvas');cv.width=256;cv.height=64;const cx=cv.getContext('2d');cx.fillStyle='rgba(0,0,0,.45)';cx.fillRect(0,0,256,64);cx.font='40px VT323, monospace';cx.fillStyle='#fff';cx.textAlign='center';cx.textBaseline='middle';cx.fillText(nm,128,34);const t=new THREE.CanvasTexture(cv);o.tag.material.map=t;o.tag.material.needsUpdate=true;}}
function removeOther(id){const o=others.get(id);if(o){scene.remove(o.g);others.delete(id);}updPlayersCount();}
let presT=0;
function netTick(dt){for(const o of others.values()){o.g.position.lerp(new THREE.Vector3(o.tx,o.ty,o.tz),0.25);o.g.rotation.y=o.ry;}
 if(!netOn)return;presT+=dt;if(presT>0.1){presT=0;if(isOwner&&Math.random()<0.02)wsend({t:'settime',time});wsend({t:'pos',x:+P.x.toFixed(2),y:+P.y.toFixed(2),z:+P.z.toFixed(2),ry:+P.yaw.toFixed(2),name:P.name,skin:S.skin||null});}}

/* ================= UPLOADS / RESOURCE PACKS / MODS ================= */
const authH=()=>ACCT?{'x-token':ACCT}:{};
const srvH=()=>worldCode?{'x-server':worldCode}:{};
async function upload(kind,name,blob){const r=await fetch(NODE+'api/upload',{method:'POST',headers:Object.assign({'x-kind':kind,'x-name':name},authH(),kind==='skins'?{}:srvH()),body:blob});if(!r.ok)throw new Error('upload');return r.json();}
async function listUploads(kind){try{const r=await fetch(NODE+'api/list?kind='+kind+(worldCode?'&server='+worldCode:''));return await r.json();}catch(e){sys('Игровой сервер недоступен (порт 3000). Проверь: systemctl status loopcraft');return[];}}
async function applyRoomPack(url){roomPack=url;renderPackList();if(!url){buildDefaultAtlas();buildAll();sys('Ресурс-пак: стандартный.');return;}
 try{const r=await fetch(packUrl(url));const b=await r.blob();buildDefaultAtlas();await applyPackZip(b);}catch(e){sys('Не удалось загрузить ресурс-пак.');}}
async function renderPackList(){const el=$('packlist');const items=await listUploads('packs');el.innerHTML='';
 if(!items.length){el.textContent='на сервере пока нет паков';return;}
 for(const it of items){if(!/\.zip$/i.test(it.name))continue;const url=worldCode?it.name:NODE+'uploads/packs/'+it.name;const d=document.createElement('div');const n=document.createElement('span');n.className='nm';n.textContent=it.name+' ('+Math.round(it.size/1024)+' КБ)';d.appendChild(n);
  const b=document.createElement('button');b.className='sbtn'+(roomPack===url?' on':'');b.textContent=roomPack===url?'активен':'применить всем';b.onclick=()=>{if(netOn)wsend({t:'pack',pack:url});applyRoomPack(url);};d.appendChild(b);el.appendChild(d);}}
$('s_packup').onclick=async()=>{const f=$('s_pack').files[0];if(!f)return;$('s_packup').disabled=true;try{const r=await upload('packs',f.name,f);sys('Пак загружен: '+f.name);const url=worldCode?f.name.replace(/[^\w.\-]/g,'_'):NODE+r.url.replace(/^\//,'');if(netOn)wsend({t:'pack',pack:url});applyRoomPack(url);}catch(e){sys('Сервер недоступен — пак применён только у тебя.');try{buildDefaultAtlas();await applyPackZip(f);}catch(_){}}$('s_packup').disabled=false;};
$('s_packoff').onclick=()=>{if(netOn)wsend({t:'pack',pack:null});applyRoomPack(null);};
$('s_texlist').onclick=()=>{const w=window.open('','_blank');if(w){w.document.write('<pre style="font:16px monospace;white-space:pre-wrap">'+textureList().replace(/</g,'&lt;')+'</pre>');}else sys(textureList());};
// ---- mods ----
const loadedMods=new Set();const modNodes=new Map();
function modUrl(f){return worldCode?NODE+'servers/'+worldCode+'/mods/'+f:NODE+'uploads/mods/'+f;}
function packUrl(v){return /^(https?:)?\//.test(v)?v:(worldCode?NODE+'servers/'+worldCode+'/resourcepacks/'+v:NODE+'uploads/packs/'+v);}
function plugUrl(f){return worldCode?NODE+'servers/'+worldCode+'/plugins/'+f:NODE+'uploads/plugins/'+f;}
function loadModFile(f){if(loadedMods.has(f))return;loadedMods.add(f);const url=modUrl(f)+'?v='+Date.now();
 if(/\.js$/i.test(f)){const sc=document.createElement('script');sc.src=url;sc.onerror=()=>sys('Мод не загрузился: '+f);document.body.appendChild(sc);modNodes.set(f,sc);}
 else if(/\.css$/i.test(f)){const l=document.createElement('link');l.rel='stylesheet';l.href=url;document.head.appendChild(l);modNodes.set(f,l);}
 else if(/\.html?$/i.test(f)){fetch(url).then(r=>r.text()).then(t=>{const d=document.createElement('div');d.className='modhtml';d.innerHTML=t;$('modui').appendChild(d);modNodes.set(f,d);d.querySelectorAll('script').forEach(o=>{const n=document.createElement('script');if(o.src)n.src=o.src;else n.textContent=o.textContent;o.replaceWith(n);});}).catch(()=>{});}
 sys('Мод включён: '+f);}
function unloadModFile(f){const n=modNodes.get(f);if(n)n.remove();modNodes.delete(f);loadedMods.delete(f);if(/\.js$/i.test(f))sys('Мод '+f+' выключен (JS полностью выгрузится после перезагрузки страницы).');}
function applyRoomMods(list){const want=new Set(list);for(const f of [...loadedMods])if(!want.has(f))unloadModFile(f);for(const f of list)loadModFile(f);roomMods=list;renderModList();}
async function renderModList(){const el=$('modlist');const items=await listUploads('mods');el.innerHTML='';if(!items.length){el.textContent='на сервере пока нет модов';return;}
 const files=[];for(const it of items){if(it.dir)for(const f of it.files)files.push(f);else files.push(it.name);}
 for(const f of files){if(!/\.(js|css|html?)$/i.test(f))continue;const d=document.createElement('div');const n=document.createElement('span');n.className='nm';n.textContent=f;d.appendChild(n);
  const on=roomMods.includes(f);const b=document.createElement('button');b.className='sbtn'+(on?' on':'');b.textContent=on?'включён для всех':'включить всем';
  b.onclick=()=>{const next=on?roomMods.filter(x=>x!==f):[...roomMods,f];if(netOn)wsend({t:'mods',mods:next});applyRoomMods(next);};d.appendChild(b);el.appendChild(d);}}
$('s_modup').onclick=async()=>{const fs=[...$('s_mod').files];if(!fs.length)return;$('s_modup').disabled=true;const added=[];
 try{for(const f of fs){if(/\.zip$/i.test(f.name)){const zip=await JSZip.loadAsync(f);const folder=f.name.replace(/\.zip$/i,'');for(const zf of Object.values(zip.files)){if(zf.dir)continue;const blob=await zf.async('blob');const rel=folder+'/'+zf.name;await upload('mods',rel,blob);if(/\.(js|css|html?)$/i.test(rel))added.push(rel);}}
  else{await upload('mods',f.name,f);added.push(f.name);}}
  sys('Загружено: '+added.length+' файл(ов).');const next=[...new Set([...roomMods,...added])];if(netOn)wsend({t:'mods',mods:next});applyRoomMods(next);}
 catch(e){sys('Ошибка загрузки мода (сервер недоступен?)');}$('s_modup').disabled=false;};
// skin
$('s_skin').onchange=async()=>{const f=$('s_skin').files[0];if(!f)return;try{const r=await upload('skins',Date.now()+'_'+f.name.replace(/[^\w.\-]/g,'_'),f);S.skin=NODE+r.url.replace(/^\//,'');saveS();$('s_skin_st').textContent=/\.(bbmodel|json)$/i.test(f.name)?'модель Blockbench загружена и надета':'скин загружен — другие увидят его на тебе';}catch(e){$('s_skin_st').textContent='не удалось загрузить';}};
$('s_skinoff').onclick=()=>{S.skin=null;saveS();$('s_skin_st').textContent='стандартный вид';};

/* ---- Lua plugins (run on the server creator's client, via fengari) ---- */
let roomPlugins=[];const luaStates=new Map();
function luaAvailable(){return !!(window.fengari&&window.fengari.load);}
function luaApi(){ // JS table exposed to Lua as global `nc`
 return {chat:t=>sys(String(t)),say:t=>{if(netOn)wsend({t:'chat',text:'/say '+String(t)});else sys(String(t));},whisper:t=>whisper(String(t)),log:t=>console_(String(t)),
  cmd:t=>{if(netOn)wsend({t:'plugin',cmd:String(t)});else console_(localCmd('/'+String(t).replace(/^\//,'')));},
  getblock:(x,y,z)=>get(x|0,y|0,z|0),setblock:(x,y,z,v)=>setBlock(x|0,y|0,z|0,typeof v==='string'?N(v):v|0,true),topy:(x,z)=>topY(x|0,z|0),
  give:(name,n)=>give(N(String(name)),n||1),item:name=>N(String(name)),itemname:id=>(I[id]||{}).n,
  player:()=>({x:P.x,y:P.y,z:P.z,name:P.name,hp:P.hp,hunger:P.hunger,dread:P.dread}),players:()=>[P.name,...[...others.values()].map(o=>o.name)],
  spawn:(type,x,y,z)=>spawnMob(MOBS[type]?type:'klyk',x,y,z),mobcount:()=>mobs.length,time:()=>time,settime:v=>{time=+v;if(netOn)wsend({t:'settime',time});},
  dread:n=>addDread(+n),damage:n=>damage(+n,'плагин'),night:()=>isNight(),
  on:(ev,fn)=>NC.on(String(ev),(...a)=>{try{fn(...a.map(x=>typeof x==='object'&&x?JSON.stringify(x):x));}catch(e){console_('lua: '+e.message);}}),
  emit:(name,data)=>NC.emit(name,data),random:(a,b)=>rnd(+a,+b),floor:Math.floor};}
async function runLua(f){if(!luaAvailable()){console_('Lua недоступна: библиотека fengari не загрузилась.');return;}
 if(f==='core.lua')return;
 try{const src=await (await fetch(plugUrl(f)+'?v='+Date.now())).text();
  const pre='local js=require("js") nc=js.global.__ncapi print=function(...) local t={...} for i=1,#t do t[i]=tostring(t[i]) end nc.log(table.concat(t," ")) end\n';
  window.__ncapi=luaApi();fengari.load(pre+src,f)();luaStates.set(f,true);console_('плагин запущен: '+f);}
 catch(e){console_('ошибка плагина '+f+': '+(e&&e.message||e));}}
function applyRoomPlugins(list){roomPlugins=list;renderPluginList();if(netOn&&!isOwner)return; // only the creator runs plugins
 for(const f of list)if(!luaStates.has(f))runLua(f);}
async function renderPluginList(){const el=$('pluginlist');if(!el)return;const items=await listUploads('plugins');el.innerHTML='';
 {const d=document.createElement('div');const n=document.createElement('span');n.className='nm';n.textContent='core (встроенный: /stop /start /restart /horror /run /broadcast /weather…)';d.appendChild(n);const b=document.createElement('button');b.className='sbtn'+(coreOn?' on':'');b.textContent=coreOn?'включён':'выключен';b.onclick=()=>{runCmd('/plugins core '+(coreOn?'off':'on'));coreOn=!coreOn;renderPluginList();};d.appendChild(b);el.appendChild(d);}
 if(!items.length){const d=document.createElement('div');d.className='hint';d.textContent='своих плагинов на сервере пока нет';el.appendChild(d);return;}
 for(const it of items){if(!/\.lua$/i.test(it.name))continue;const f=it.name;const d=document.createElement('div');const n=document.createElement('span');n.className='nm';n.textContent=f;d.appendChild(n);
  const on=roomPlugins.includes(f);const b=document.createElement('button');b.className='sbtn'+(on?' on':'');b.textContent=on?'включён':'включить';
  b.onclick=()=>{const next=on?roomPlugins.filter(x=>x!==f):[...roomPlugins,f];if(netOn)wsend({t:'plugins',plugins:next});else applyRoomPlugins(next);};d.appendChild(b);el.appendChild(d);}}
$('s_plugup').onclick=async()=>{const fs=[...$('s_plug').files];if(!fs.length)return;$('s_plugup').disabled=true;const added=[];
 try{for(const f of fs){await upload('plugins',f.name,f);added.push(f.name);}sys('Загружено плагинов: '+added.length);const next=[...new Set([...roomPlugins,...added])];if(netOn)wsend({t:'plugins',plugins:next});else applyRoomPlugins(next);}
 catch(e){sys('Ошибка загрузки плагина');}$('s_plugup').disabled=false;};
/* ---- mod API (window.NC) ---- */
const NC={version:'1.2.3_03',items:I,N,byName,slots:SL,shapes:SHAPES,world:{get,set:(x,y,z,v)=>setBlock(x,y,z,v,true),topY,H},player:P,inv,give,take,has,mobs,MOBS,spawnMob,spawnDrop,recipes:R,scene,camera,THREE,addDread,
 registerItem(o){const id=def(Object.assign({kind:'misc',c:[.8,.8,.8]},o));byName[o.n]=id;return id;},
 registerRecipe(r){R.push(r);},
 chat(t){sys(String(t));},whisper(t){whisper(String(t));},
 emit(name,data){wsend({t:'event',name:String(name),data});},
 addStyle(css){const st=document.createElement('style');st.textContent=css;document.head.appendChild(st);return st;},
 addHTML(html){const d=document.createElement('div');d.innerHTML=html;$('modui').appendChild(d);return d;},
 setBlockTexture(name,imgUrl){const im=new Image();im.onload=()=>{const t=TEX[name]!=null?TEX[name]:texTile(name);AG.clearRect((t%16)*16,Math.floor(t/16)*16,16,16);AG.imageSmoothingEnabled=false;AG.drawImage(im,(t%16)*16,Math.floor(t/16)*16,16,16);atlasTex.needsUpdate=true;buildAll();};im.src=imgUrl;},
 _h:{},on(ev,fn){(this._h[ev]=this._h[ev]||[]).push(fn);},_fire(ev,...a){for(const f of (this._h[ev]||[]))try{f(...a);}catch(e){console.error('mod error',e);}}};
window.NC=NC;

/* ================= VOICE CHAT (WebRTC, needs HTTPS) ================= */
let micStream=null;const pcs=new Map();
const RTCCFG={iceServers:[{urls:'stun:stun.l.google.com:19302'}]};
$('s_voice').onclick=async()=>{if(micStream){micStream.getTracks().forEach(t=>t.stop());micStream=null;pcs.forEach(pc=>pc.close());pcs.clear();$('s_voice').textContent='Включить микрофон';$('s_voice_st').textContent='';return;}
 if(!navigator.mediaDevices||!window.isSecureContext){$('s_voice_st').textContent='Браузер даёт микрофон только по HTTPS. Подключите домен и сертификат (см. README).';return;}
 try{micStream=await navigator.mediaDevices.getUserMedia({audio:true});}catch(e){$('s_voice_st').textContent='Микрофон не разрешён.';return;}
 $('s_voice').textContent='Выключить микрофон';$('s_voice_st').textContent='Микрофон включён. Соединяюсь с игроками…';
 for(const id of others.keys())voiceOffer(id);};
function voicePC(id){let pc=pcs.get(id);if(pc)return pc;pc=new RTCPeerConnection(RTCCFG);pcs.set(id,pc);
 if(micStream)micStream.getTracks().forEach(t=>pc.addTrack(t,micStream));
 pc.onicecandidate=e=>{if(e.candidate)wsend({t:'rtc',to:id,data:{cand:e.candidate}});};
 pc.ontrack=e=>{let a=document.getElementById('va'+id);if(!a){a=document.createElement('audio');a.id='va'+id;a.autoplay=true;document.body.appendChild(a);}a.srcObject=e.streams[0];};
 return pc;}
async function voiceOffer(id){const pc=voicePC(id);const o=await pc.createOffer();await pc.setLocalDescription(o);wsend({t:'rtc',to:id,data:{sdp:pc.localDescription}});}
async function voiceSignal(from,d){if(!d)return;const pc=voicePC(from);
 if(d.sdp){await pc.setRemoteDescription(d.sdp);if(d.sdp.type==='offer'){const a=await pc.createAnswer();await pc.setLocalDescription(a);wsend({t:'rtc',to:from,data:{sdp:pc.localDescription}});}}
 else if(d.cand){try{await pc.addIceCandidate(d.cand);}catch(e){}}}
function voicePeerJoined(id){if(micStream)setTimeout(()=>voiceOffer(id),1000);}
function voicePeerLeft(id){const pc=pcs.get(id);if(pc){pc.close();pcs.delete(id);}const a=document.getElementById('va'+id);if(a)a.remove();}

/* ================= SETTINGS UI ================= */
let setOpen=false;
function toggleSettings(){setOpen=!setOpen;$('settings').classList.toggle('on',setOpen);if(setOpen){document.exitPointerLock&&document.exitPointerLock();$('s_name').value=P.name;$('s_touch').value=S.touch==null?'auto':(S.touch?'on':'off');$('s_fov').value=S.fov;$('s_dist').value=S.dist;$('s_sens').value=S.sens;$('s_inv').checked=S.inv;$('s_vol').value=S.vol;$('s_tts').checked=S.tts;$('s_myst').value=S.myst;for(const k of['fov','dist','sens','vol'])$('s_'+k+'_v').textContent=S[k];renderPackList();renderModList();renderPluginList();}}
$('bSettings2').onclick=toggleSettings;$('bCloseSet').onclick=toggleSettings;
$('s_name').oninput=()=>setName($('s_name').value);
for(const k of['fov','dist','sens','vol']){$('s_'+k).oninput=()=>{S[k]=+$('s_'+k).value;$('s_'+k+'_v').textContent=S[k];if(k==='fov'){camera.fov=S.fov;camera.updateProjectionMatrix();}if(k==='dist'){camera.far=S.dist*2.5;camera.updateProjectionMatrix();}saveS();};}
$('s_inv').onchange=()=>{S.inv=$('s_inv').checked;saveS();};$('s_touch').onchange=()=>{S.touch=$('s_touch').value==='auto'?null:$('s_touch').value==='on';S.touchV=2;saveS();sys('Управление изменится после перезагрузки страницы.');};$('s_tts').onchange=()=>{S.tts=$('s_tts').checked;saveS();};$('s_myst').onchange=()=>{S.myst=+$('s_myst').value;saveS();};
document.querySelectorAll('#setp input,#setp select').forEach(el=>el.addEventListener('keydown',e=>e.stopPropagation()));

/* ================= MENU (broken on purpose) ================= */
const menu=$('menu');
const SPLASH=['Строй. Выживай. Зови друзей.','Свои серверы и плагины!','Моды на JS, плагины на Lua','Ресурс-паки в zip','Создатель: Winnigames2024','Бесконечный мир','/gamemode creative','Редактор скинов внутри'];
$('splash').textContent=SPLASH[ri(0,SPLASH.length-1)];
$('bOptions').onclick=toggleSettings;
$('bTex').onclick=toggleSettings;
$('bQuit').onclick=()=>{try{window.close();}catch(e){}$('bQuit').textContent='Просто закрой вкладку';};
let playing=false,worldSeed=0,menuBg=false,menuT=0;
function startMenuBg(){try{genWorld(4242);S._menuR=1;menuBg=true;}catch(e){}}
startMenuBg();
function startWorld(s,code,load){
 menuBg=false;worldSeed=s;worldCode=code||'';menu.hidden=true;$('hud').classList.add('on');
 genWorld(s);clearEdits();
 if(load){for(const [k,v] of load.edits)applyEdit(k,v);}
 if(load){P.x=load.p.x;P.y=load.p.y;P.z=load.p.z;ensureAround(Math.floor(P.x),Math.floor(P.z),2);P.hp=load.p.hp;P.hunger=load.p.hunger;P.dread=load.p.dread||0;loadInv(load);time=load.time||0;}
 else{spawnPlayer();startKit();time=40;if(code)loadWorld(code).then(l=>{if(l&&l.p&&l.code===code){P.x=l.p.x;P.y=l.p.y;P.z=l.p.z;P.hp=l.p.hp;P.hunger=l.p.hunger;P.dread=l.p.dread||0;loadInv(l);renderHot();renderBars();}});}
 renderHot();renderBars();addDread(0);playing=true;resize();
 sys('loopcraft. Мир '+(code||'локальный')+'. Есть — ПКМ с едой, выбросить — Q.');
 if(horrorOn)setTimeout(()=>whisper('привет'),9000);
 camera.fov=S.fov;camera.far=S.dist*2.5;camera.updateProjectionMatrix();NC._fire('start');
 if(code)connect(code);
 if(!isTouch)setTimeout(()=>sys('Кликни по миру, чтобы захватить мышь.'),800);
}
$('bSingle').onclick=async()=>{$('bSingle').disabled=true;const load=await loadWorld('local');$('bSingle').disabled=false;worldName='local';
 if(load&&load.seed){startWorld(load.seed,'',load);}else startWorld(ri(1000,999999),'');};
$('bHost').onclick=()=>{$('srvpanel').hidden=!$('srvpanel').hidden;if(!$('srvpanel').hidden)refreshServers();};
async function check(q){try{const r=await fetch(NODE+'api/check?'+q);return await r.json();}catch(e){return null;}}
function menuErr(t){$('srvmsg').textContent=t;$('srvmsg').style.color=t?'var(--danger)':'';}
$('srvip').addEventListener('input',async()=>{const v=$('srvip').value.trim().toLowerCase();$('srvip').value=v;if(!CODE_RE.test(v)){$('ipst').textContent=v?'латиница, цифры, - и _ (3–24)':'';$('ipst').style.color='var(--danger)';return;}const c=await check('room='+encodeURIComponent(v));if(!c){$('ipst').textContent='';return;}$('ipst').textContent=c.roomExists?'занято':'свободно';$('ipst').style.color=c.roomExists?'var(--danger)':'var(--accent)';});
$('bCreate').onclick=async()=>{const nm=($('srvname').value||'').trim();const ip=($('srvip').value||'').trim().toLowerCase();if(!ACCT){menuErr('Серверы доступны только с аккаунтом — войди или зарегистрируйся выше.');return;}
 if(!CODE_RE.test(ip)){menuErr('Адрес (IP-имя) сервера: латиница, цифры, - и _, 3–24 символа.');return;}
 if(!nm){menuErr('Введи название сервера.');return;}
 const c=await check('room='+encodeURIComponent(ip)+'&server='+encodeURIComponent(nm));if(c&&c.roomExists){menuErr('Адрес «'+ip+'» уже занят. Выбери другой.');return;}if(c&&c.serverNameTaken){menuErr('Сервер с таким названием уже есть. Выбери другое.');return;}menuErr('');
 if(($('srvpw').value||'').length<4){menuErr('Задай пароль панели сервера (от 4 символов) — по нему ты будешь входить в панель управления.');return;}
 createOpts={create:true,name:nm.slice(0,32),max:+$('srvmax').value||16,public:$('srvpub').checked,panelPw:$('srvpw').value};startWorld(ri(1000,999999),ip);try{history.replaceState(null,'','#'+ip);}catch(e){}};
async function refreshServers(){const el=$('srvlist');el.textContent='загрузка…';try{const r=await fetch(NODE+'api/rooms');const list=await r.json();el.innerHTML='';if(!list.length){el.textContent='сейчас нет открытых серверов — создай свой';return;}
 for(const s of list){const d=document.createElement('div');d.className='srv';d.innerHTML='<b></b><span class="dim"></span>';d.querySelector('b').textContent=s.name;d.querySelector('span').textContent=' · '+(s.online?'онлайн '+s.players+'/'+s.max:'выключен')+' · адрес '+location.host+':'+s.code+(s.wl?' · белый список':'')+(s.mods?' · моды':'')+(s.pack?' · пак':'');
  const b=document.createElement('button');b.className='sbtn';b.textContent='Войти';b.onclick=()=>joinAddress(s.code);d.appendChild(b);el.appendChild(d);}}catch(e){el.textContent='сервер недоступен';}}
$('bRefresh').onclick=refreshServers;
async function joinAddress(addr){if(!ACCT){menuErr('Серверы доступны только с аккаунтом — войди или зарегистрируйся выше.');return;}addr=String(addr).trim();let host='',code='';addr=addr.replace(/^https?:\/\//,'');const m=/^([^\/:#\s]+(?::\d+)?)(?:\/[^#\s]*)?[#:]([a-z0-9][a-z0-9_\-]{2,23})$/i.exec(addr);
 if(m){host=m[1];code=m[2].toLowerCase();}else if(CODE_RE.test(addr.toLowerCase())){code=addr.toLowerCase();}
 if(!code){$('joincode').value='';$('joincode').placeholder='адрес: имя-сервера или IP:имя-сервера';return;}
 if(host&&host!==location.host&&host!==location.hostname){location.href='http://'+host+'/webminecraft/horror/#'+code;return;}
 const s=seedFromCode(code);createOpts={};
 const c=await check('room='+encodeURIComponent(code.toLowerCase())+'&name='+encodeURIComponent(P.name));
 if(c){if(!c.roomExists){menuErr('Сервера «'+code+'» нет. Проверь адрес или создай свой.');return;}if(c.banned){menuErr('Тебе закрыт вход на этот сервер.');return;}if(!c.whitelisted){menuErr('Сервер по белому списку — тебя в нём нет.');return;}if(c.online&&c.players>=c.max){menuErr('Сервер полон.');return;}}
 menuErr('');startWorld(s,code.toLowerCase());try{history.replaceState(null,'','#'+code.toLowerCase());}catch(e){}}
$('bJoin').onclick=()=>joinAddress($('joincode').value);
/* ---- accounts ---- */
async function accApi(p,body){const r=await fetch(NODE+'api/account/'+p,{method:body?'POST':'GET',headers:Object.assign({'Content-Type':'application/json'},authH()),body:body?JSON.stringify(body):undefined});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||'ошибка');return j;}
function setAcct(tok,name){ACCT=tok||'';ACCN=name||'';setCookie('nc_acct',ACCT);setCookie('nc_accn',ACCN);if(name)setName(name);renderAcc();}
function renderAcc(){$('bAdmin').hidden=!(ACCT&&['minecraft','winnigames2024','loopcraft'].includes(ACCN.toLowerCase()));$('bMyServers').hidden=!ACCT;$('accst').textContent=ACCT?'Вы вошли как '+ACCN:'Без аккаунта: имя может занять кто угодно, миры хранятся по cookie.';$('accform').hidden=!!ACCT;$('bLogout').hidden=!ACCT;$('pname').disabled=!!ACCT;if(ACCT)$('pname').value=ACCN;}
$('bReg').onclick=async()=>{if(!/^[A-Za-z0-9_]{3,16}$/.test($('accname').value)){menuErr('Имя аккаунта: только английские буквы, цифры и _ (3–16 символов).');return;}try{const j=await accApi('register',{name:$('accname').value,password:$('accpw').value});setAcct(j.token,j.name);menuErr('');}catch(e){menuErr(e.message);}};
$('bLogin').onclick=async()=>{try{const j=await accApi('login',{name:$('accname').value,password:$('accpw').value});setAcct(j.token,j.name);menuErr('');}catch(e){menuErr(e.message);}};
$('bLogout').onclick=()=>{setAcct('','');};
$('bAdmin').onclick=()=>{window.open('admin.php?tok='+encodeURIComponent(ACCT),'_blank');};
$('bMyServers').onclick=()=>{window.open('servers_panel/?tok='+encodeURIComponent(ACCT),'_blank');};
renderAcc();if(ACCT)accApi('me').catch(()=>setAcct('',''));
/* ---- friends (pause panel) ---- */
async function renderFriends(){const el=$('frlist');if(!ACCT){el.textContent='Друзья доступны с аккаунтом (войди в меню).';return;}
 try{const me=await accApi('me');el.innerHTML='';
  for(const rq of me.requests){const d=document.createElement('div');d.textContent=rq+' хочет добавить тебя ';const b=document.createElement('button');b.className='sbtn';b.textContent='принять';b.onclick=async()=>{await accApi('friend',{name:rq,action:'accept'});renderFriends();};d.appendChild(b);el.appendChild(d);}
  if(!me.friends.length){const d=document.createElement('div');d.className='hint';d.textContent='пока нет друзей — добавь по имени';el.appendChild(d);}
  for(const f of me.friends){const d=document.createElement('div');const n=document.createElement('span');n.className='nm';n.textContent=f.name+(f.online?' · на сервере «'+f.online.name+'»':' · не в игре');d.appendChild(n);
   if(f.online){const b=document.createElement('button');b.className='sbtn';b.textContent='к другу';b.onclick=()=>{location.href=location.href.split('#')[0]+'#'+f.online.code;location.reload();};d.appendChild(b);}
   const r=document.createElement('button');r.className='sbtn warn';r.textContent='✕';r.onclick=async()=>{await accApi('friend',{name:f.name,action:'remove'});renderFriends();};d.appendChild(r);el.appendChild(d);}}
 catch(e){el.textContent=e.message;}}
$('bFrAdd').onclick=async()=>{if(!ACCT){sys('Друзья доступны только с аккаунтом.');return;}try{const j=await accApi('friend',{name:$('frname').value});sys(j.sent?'Запрос в друзья отправлен.':'Уже в друзьях.');$('frname').value='';renderFriends();}catch(e){sys(e.message);}};
$('frname').addEventListener('keydown',e=>e.stopPropagation());
/* ---- worlds ---- */
async function renderWorlds(){const el=$('wlist');el.textContent='загрузка…';try{const r=await fetch(NODE+'api/world?tok='+TOK+'&list=1',{headers:authH()});const list=await r.json();el.innerHTML='';
 if(!list.length){el.textContent='нет сохранённых миров — создай новый';}
 for(const w of list.sort((a,b)=>b.updated-a.updated)){const d=document.createElement('div');const n=document.createElement('span');n.className='nm';n.textContent=w.name+' · '+new Date(w.updated).toLocaleString();d.appendChild(n);
  const b=document.createElement('button');b.className='sbtn';b.textContent='Играть';b.onclick=async()=>{const load=await loadWorld(w.name);worldName=w.name;if(load&&load.seed)startWorld(load.seed,load.code||'',load);else startWorld(ri(1000,999999),'');};d.appendChild(b);
  const x=document.createElement('button');x.className='sbtn warn';x.textContent='удалить';x.onclick=async()=>{if(x.textContent!=='точно?'){x.textContent='точно?';return;}await fetch(NODE+'api/world?tok='+TOK+'&name='+encodeURIComponent(w.name),{method:'DELETE',headers:authH()});renderWorlds();};d.appendChild(x);el.appendChild(d);}}
 catch(e){el.textContent='сервер недоступен — доступен только локальный мир';const d=document.createElement('div');const b=document.createElement('button');b.className='sbtn';b.textContent='Локальный мир';b.onclick=$('bSingle').onclick;d.appendChild(b);el.appendChild(d);}}
$('bWorlds').onclick=()=>{$('wpanel').hidden=!$('wpanel').hidden;if(!$('wpanel').hidden)renderWorlds();};
$('bNewWorld').onclick=()=>{const nm=($('wname').value||'').trim().replace(/[^\wа-яА-ЯёЁ\- ]/g,'').slice(0,24);if(!nm){menuErr('Введи название мира.');return;}worldName=nm;const seedIn=($('wseed').value||'').trim();const s=seedIn?(parseInt(seedIn)||[...seedIn].reduce((h,c)=>(h*31+c.charCodeAt(0))>>>0,7)):ri(1000,999999);startWorld(s,'');};
$('pname').addEventListener('input',()=>{const v=$('pname').value.trim();$('pname').style.borderColor=/^[A-Za-z0-9_]{3,16}$/.test(v)?'#4d6b4a':'#a33';});
// link with #w-code → auto join
(function(){const h=location.hash.replace('#','').toLowerCase();if(CODE_RE.test(h)){$('joincode').value=location.host+':'+h;setTimeout(()=>{$('bJoin').textContent='Войти на сервер '+h;},10);}})();

/* ================= MAIN LOOP ================= */
let last=performance.now(),hungerT=0,fpsT=0,fps=0,fc=0;
function loop(now){requestAnimationFrame(loop);const dt=Math.min(0.05,(now-last)/1000);last=now;if(!playing)return;
 fc++;fpsT+=dt;if(fpsT>1){fps=fc;fc=0;fpsT=0;}
 if(!paused&&!P.dead){
  time+=dt;if(!invOpen&&!chatOpen&&!setOpen)physics(dt);NC._fire('tick',dt);
  if(!invOpen&&!setOpen)mining(dt);hitCool-=dt;
  mobTick(dt);if(horrorOn){mystic(dt);creepyTick(dt);}dropsTick(dt);waterT+=dt;if(waterT>0.15){waterT=0;waterStep();}
  hungerT+=dt;if(hungerT>10){hungerT=0;if(P.hunger>0)P.hunger--;else damage(1,'голод');if(P.hunger>=16&&P.hp<20)P.hp++;if(P.dread>0)addDread(-1);renderBars();}
  // whisper crystal proximity
  if(horrorOn&&Math.random()<0.02){for(let dx=-3;dx<=3;dx++)for(let dz=-3;dz<=3;dz++){const b=get(Math.floor(P.x)+dx,Math.floor(P.y),Math.floor(P.z)+dz);if(b===WHISPER&&Math.random()<0.3){addDread(2);if(Math.random()<0.3)whisper(WHISPERS[ri(0,WHISPERS.length-1)]);}}}
  streamChunks(Math.floor(P.x),Math.floor(P.z),2);flushDirty();
 }
 netTick(dt);sky();
 camera.position.set(P.x,P.y+1.62,P.z);camera.rotation.set(0,0,0);camera.rotateY(P.yaw);camera.rotateX(P.pitch);
 if(glitchT>0)camera.position.x+=rnd(-0.03,0.03);
 const t=(time%DAY)/DAY;const hrs=Math.floor(((t+0.25)%1)*24),mins=Math.floor((((t+0.25)%1)*24%1)*60);
 $('topleft').textContent=(serverName&&netOn?'сервер: '+serverName+(isOp?' · op':'')+'\n':'')+`XYZ ${P.x.toFixed(1)} ${P.y.toFixed(1)} ${P.z.toFixed(1)}\n${String(hrs).padStart(2,'0')}:${String(mins).padStart(2,'0')} ${isNight()?'ночь':'день'} · ${fps} fps\nтревога ${P.dread|0}%${watcher?' · ОН РЯДОМ':''}`;
 renderer.render(scene,camera);
}
resize();requestAnimationFrame(loop);
function menuLoop(){if(!menuBg)return;requestAnimationFrame(menuLoop);menuT+=0.004;time=140;sky();const cx=Math.sin(menuT)*30,cz=Math.cos(menuT)*30;streamChunks(Math.floor(cx),Math.floor(cz),3);flushDirty();camera.position.set(cx,Math.max(SEA+8,topY(Math.floor(cx),Math.floor(cz))+6),cz);camera.lookAt(0,SEA+4,0);renderer.render(scene,camera);}
menuLoop();
})();
