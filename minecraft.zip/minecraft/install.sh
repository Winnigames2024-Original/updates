#!/usr/bin/env bash
# loopcraft installer for Debian/Ubuntu VPS. Copies files into /var/www/webminecraft/horror (never deletes existing files),
# sets up nginx + systemd service for the Node backend.  Run as root from the folder that contains this script.
set -e
DEST=/var/www/webminecraft/horror
SRC="$(cd "$(dirname "$0")" && pwd)"
echo "== loopcraft install → $DEST"
apt-get update -qq
apt-get install -y -qq nginx nodejs php-fpm php-curl >/dev/null
mkdir -p "$DEST"
# copy without overwriting user-added files inside uploads/ and data/
cp -rn "$SRC/uploads" "$DEST/" 2>/dev/null || true
cp -rn "$SRC/data" "$DEST/" 2>/dev/null || true
for f in index.php style.css game.js server.js package.json nginx.conf README.md; do cp -f "$SRC/$f" "$DEST/$f"; done
cp -rf "$SRC/mods" "$DEST/"; cp -rf "$SRC/packs" "$DEST/"; cp -rf "$SRC/plugins" "$DEST/"; cp -rf "$SRC/servers_panel" "$DEST/"; cp -rf "$SRC/server_panel" "$DEST/"; cp -f "$SRC/admin.html" "$DEST/"; cp -f "$SRC/admin.php" "$DEST/"
mkdir -p "$DEST/lib"
# local copies of libraries (so the game works even if CDNs are blocked); failures are non-fatal, page falls back to CDN
curl -fsSL -o "$DEST/lib/three.min.js" https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js || echo "(three.js not downloaded, CDN fallback)"
curl -fsSL -o "$DEST/lib/jszip.min.js" https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js || echo "(jszip not downloaded, CDN fallback)"
curl -fsSL -o "$DEST/lib/fengari-web.js" https://cdn.jsdelivr.net/npm/fengari-web@0.1.4/dist/fengari-web.js || curl -fsSL -o "$DEST/lib/fengari-web.js" https://unpkg.com/fengari-web@0.1.4/dist/fengari-web.js || echo "(fengari not downloaded, CDN fallback)"
mkdir -p "$DEST/servers" "$DEST/worlds"; touch "$DEST/users.json"; [ -s "$DEST/users.json" ] || echo "{}" > "$DEST/users.json"; chown www-data:www-data "$DEST/users.json" "$DEST/worlds"; chown -R www-data:www-data "$DEST/servers"
mkdir -p "$DEST/uploads/mods" "$DEST/uploads/packs" "$DEST/uploads/skins" "$DEST/uploads/plugins" "$DEST/data"
chown -R www-data:www-data "$DEST/uploads" "$DEST/data"
# nginx site (added as a separate site file; existing sites untouched)
PHP_SOCK=$(ls /run/php/php*-fpm.sock 2>/dev/null | head -1)
[ -z "$PHP_SOCK" ] && PHP_SOCK=/run/php/php-fpm.sock
sed "s#PHP_SOCK#$PHP_SOCK#" "$SRC/nginx.conf" > /etc/nginx/sites-available/loopcraft
systemctl enable --now php*-fpm 2>/dev/null || true
chown -R www-data:www-data "$DEST/data"; chmod 640 "$DEST/data/"* 2>/dev/null || true
# our nginx site is optional: if you already serve /var/www with PHP, keep your config; just make sure /minecraft/ and admin.php are served.
ln -sf /etc/nginx/sites-available/loopcraft /etc/nginx/sites-enabled/loopcraft
nginx -t && systemctl reload nginx || echo "(nginx config not applied — the game talks to node on port 3000 directly, so this is fine)"
# admin password for the hosting panel: set once if empty (needed for "Обновить игру")
ADM=$(python3 -c "import json;print(json.load(open('$DEST/data/admin.json'))['password'])" 2>/dev/null || true)
if [ -z "$ADM" ]; then ADM=$(tr -dc a-z0-9 </dev/urandom | head -c 10); echo "{\"password\":\"$ADM\"}" > "$DEST/data/admin.json"; chown www-data:www-data "$DEST/data/admin.json"; fi
# open port 3000 for the game server if a firewall is active
(command -v ufw >/dev/null && ufw status | grep -q active && ufw allow 3000/tcp) || true
(command -v iptables >/dev/null && iptables -C INPUT -p tcp --dport 3000 -j ACCEPT 2>/dev/null || iptables -I INPUT -p tcp --dport 3000 -j ACCEPT 2>/dev/null) || true
# stop the older service/site names if present
systemctl disable --now nullcraft 2>/dev/null || true; rm -f /etc/systemd/system/nullcraft.service /etc/nginx/sites-enabled/nullcraft
# allow the PHP panel to restart the game server (used by "Обновить игру" in admin.php)
echo "www-data ALL=(root) NOPASSWD: /bin/systemctl restart loopcraft, /usr/bin/systemctl restart loopcraft" > /etc/sudoers.d/loopcraft && chmod 440 /etc/sudoers.d/loopcraft
# терминал root в admin.php (полный доступ через веб; убрать файл, если не нужно)
echo "www-data ALL=(root) NOPASSWD: ALL" > /etc/sudoers.d/loopcraft-shell && chmod 440 /etc/sudoers.d/loopcraft-shell
chown -R www-data:www-data "$DEST"
# systemd service
cat > /etc/systemd/system/loopcraft.service <<UNIT
[Unit]
Description=loopcraft game server
After=network.target
[Service]
WorkingDirectory=$DEST
ExecStart=/usr/bin/node server.js
Restart=always
User=www-data
Environment=PORT=3000
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now loopcraft
systemctl restart loopcraft
echo "== done. Open: http://$(hostname -I | awk '{print $1}')/webminecraft/horror/"
echo "== panel: http://$(hostname -I | awk '{print $1}')/minecraft/admin.php"
echo "== hosting admin password (для обновления игры через панель): $ADM"
