<?php
// loopcraft — панель серверов (PHP). Создатель: Winnigames2024
// Вход в панель своего сервера: адрес (IP-имя) сервера + пароль панели, заданный при создании.
// Файлы сервера: servers/<имя>/server.properties, plugins/, mods/, resourcepacks/, world.json
session_start();
$ROOT=__DIR__;$API='http://127.0.0.1:3000';$SERVERS="$ROOT/servers";
$admin=@json_decode(@file_get_contents("$ROOT/data/admin.json"),true);$PW=$admin['password']??'';$IKEY=trim(@file_get_contents("$ROOT/data/internal.key")?:'');
function h($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function code_ok($c){return (bool)preg_match('/^[a-z0-9][a-z0-9_\-]{2,23}$/',$c);}
function props_read($fp){$o=[];foreach(@file($fp)?:[] as $l){$l=trim($l);if($l===''||$l[0]==='#')continue;$i=strpos($l,'=');if($i===false)continue;$o[trim(substr($l,0,$i))]=trim(substr($l,$i+1));}return $o;}
function props_write($fp,$o){$out="# loopcraft server.properties — списки через запятую\n# Winnigames2024\n";foreach($o as $k=>$v)$out.="$k=$v\n";file_put_contents($fp,$out);}
function curl_json($path,$post=null,$hdr=[]){global $API;$ch=curl_init($API.$path);curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);curl_setopt($ch,CURLOPT_TIMEOUT,5);
 if($post!==null){curl_setopt($ch,CURLOPT_POST,1);curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($post,JSON_UNESCAPED_UNICODE));$hdr[]='Content-Type: application/json';}
 curl_setopt($ch,CURLOPT_HTTPHEADER,$hdr);$r=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);$j=$r===false?null:json_decode($r,true);return func_num_args()>3||true?[$code,$j]:$j;}
function cj($path,$post=null,$hdr=[]){[$c,$j]=curl_json($path,$post,$hdr);return $j;}
$msg='';
if(isset($_GET['logout'])){session_destroy();header('Location: admin.php');exit;}
// ---- вход владельца сервера ----
if(isset($_POST['slogin'])){$addr=strtolower(trim($_POST['addr']??''));if(preg_match('/([a-z0-9][a-z0-9_\-]{2,23})\s*$/',$addr,$m))$addr=$m[1];
 $pf="$SERVERS/$addr/server.properties";
 if(!code_ok($addr)||!is_file($pf))$msg='Сервер с таким адресом не найден';
 else{$p=props_read($pf);if(($p['panel-password-hash']??'')!==''&&hash_equals($p['panel-password-hash'],hash('sha256',$_POST['spw']??''))){$_SESSION['srv']=$addr;}else $msg='Неверный пароль панели';}}
if(isset($_POST['login'])){if($PW!==''&&hash_equals($PW,$_POST['pw']??''))$_SESSION['nc_admin']=1;else $msg='Неверный пароль администратора';}
// вход главного администратора аккаунтом игры (Minecraft / Winnigames2024 / LoopCraft)
$SUPER=['minecraft','winnigames2024','loopcraft'];
if(isset($_POST['alogin'])){[$c,$j]=curl_json('/api/account/login',['name'=>$_POST['aname']??'','password'=>$_POST['apw']??'']);
 if($c===200&&!empty($j['ok'])&&in_array(mb_strtolower($j['name']),$SUPER)){$_SESSION['nc_admin']=1;$_SESSION['nc_admin_name']=$j['name'];}else $msg='Это не аккаунт главного администратора';}
if(!empty($_GET['tok'])){[$c,$me]=curl_json('/api/account/me',null,['x-token: '.$_GET['tok']]);if($c===200&&!empty($me['name'])&&in_array(mb_strtolower($me['name']),$SUPER)){$_SESSION['nc_admin']=1;$_SESSION['nc_admin_name']=$me['name'];}}
if(!empty($_SESSION['nc_admin'])&&isset($_GET['open'])&&code_ok($_GET['open'])&&is_file("$SERVERS/{$_GET['open']}/server.properties"))$_SESSION['srv']=$_GET['open'];
$auth=!empty($_SESSION['nc_admin']);$srv=$_SESSION['srv']??'';if($srv&&!is_file("$SERVERS/$srv/server.properties")){$srv='';unset($_SESSION['srv']);}
$LISTS=['ops'=>'Операторы (op)','whitelist'=>'Белый список','blacklist'=>'Чёрный список','banned'=>'Забаненные'];
$FOLDERS=['plugins'=>'Плагины (lua)','mods'=>'Моды (js/css/html)','resourcepacks'=>'Ресурс-паки (zip)'];
function live_cmd($srv,$text){global $IKEY;$r=cj('/api/admin/cmd',['room'=>$srv,'text'=>$text],['x-internal: '.$IKEY]);return $r?implode("\n",$r):null;}
function live_reload($srv){global $IKEY;cj('/api/admin/cmd',['room'=>$srv,'text'=>'/reloadprops'],['x-internal: '.$IKEY]);}
if($srv){
 $dir="$SERVERS/$srv";$pf="$dir/server.properties";$p=props_read($pf);
 if(isset($_POST['saveprops'])){
  foreach(['name','motd','max-players','seed','weather','time'] as $k)if(isset($_POST[$k]))$p[$k]=str_replace(["\n","\r"],'',mb_substr($_POST[$k],0,120));
  foreach(['public','horror','core','whitelist-enabled'] as $k)$p[$k]=!empty($_POST[$k])?'true':'false';
  foreach(array_keys($LISTS) as $k){$v=strtolower($_POST[$k]??'');$p[$k]=implode(',',array_values(array_filter(array_map('trim',preg_split('/[,\s]+/',$v)))));}
  if(!empty($_POST['newpanelpw'])&&strlen($_POST['newpanelpw'])>=4)$p['panel-password-hash']=hash('sha256',$_POST['newpanelpw']);
  props_write($pf,$p);live_reload($srv);$msg='server.properties сохранён'.(live_cmd($srv,'/list')!==null?' и применён':' (игровой сервер не отвечает — применится при запуске)');}
 if(isset($_POST['rawprops'])){props_write($pf,props_read('data://text/plain,'.rawurlencode($_POST['raw'])));$p=props_read($pf);live_reload($srv);$msg='server.properties перезаписан';}
 if(isset($_POST['cmd'])){$o=live_cmd($srv,$_POST['cmd']);$msg=$o===null?'Игровой сервер не отвечает (systemctl status loopcraft)':$o;$p=props_read($pf);}
 if(isset($_POST['del'])&&isset($FOLDERS[$_POST['folder']])){$f=basename($_POST['del']);$fp="$dir/{$_POST['folder']}/$f";if(is_file($fp)&&$f!=='core.lua'){unlink($fp);$msg="Удалено: $f";}}
 if(isset($_FILES['up'])&&$_FILES['up']['error']===0&&isset($FOLDERS[$_POST['folder']])){$f=preg_replace('/[^\w.\-]/u','_',basename($_FILES['up']['name']));move_uploaded_file($_FILES['up']['tmp_name'],"$dir/{$_POST['folder']}/$f");
  $key=$_POST['folder']==='resourcepacks'?'pack':$_POST['folder'];$p=props_read($pf);
  if($key==='pack')$p['pack']=$f;else{$arr=array_filter(array_map('trim',explode(',',$p[$key]??'')));if(!in_array($f,$arr))$arr[]=$f;$p[$key]=implode(',',$arr);}
  props_write($pf,$p);live_reload($srv);$msg="Загружено и включено: $f";}
 if(isset($_POST['toggle'])&&isset($FOLDERS[$_POST['folder']])){$f=basename($_POST['toggle']);$key=$_POST['folder']==='resourcepacks'?'pack':$_POST['folder'];
  if($key==='pack')$p['pack']=($p['pack']??'')===$f?'':$f;else{$arr=array_values(array_filter(array_map('trim',explode(',',$p[$key]??''))));if(in_array($f,$arr))$arr=array_values(array_diff($arr,[$f]));else $arr[]=$f;$p[$key]=implode(',',$arr);}
  if($f==='core.lua')$p['core']=($p['core']??'true')==='true'?'false':'true';props_write($pf,$p);live_reload($srv);$msg='Изменено: '.$f;}
 $p=props_read($pf);$live=cj('/api/admin/rooms',null,['x-internal: '.$IKEY]);$info=null;if(is_array($live))foreach($live as $r)if($r['code']===$srv)$info=$r;
}
if($auth&&!$srv){
 $zipPath=null;
 if(isset($_FILES['gamezip'])&&$_FILES['gamezip']['error']===0)$zipPath=$_FILES['gamezip']['tmp_name'];
 elseif(!empty($_POST['zipurl'])&&preg_match('#^https?://#',$_POST['zipurl'])){$d=@file_get_contents($_POST['zipurl'],false,stream_context_create(['http'=>['timeout'=>60]]));if($d&&strlen($d)>1000){$zipPath=sys_get_temp_dir().'/lc_dl_'.uniqid().'.zip';file_put_contents($zipPath,$d);}else $msg='Не удалось скачать архив по ссылке';}
 elseif(!empty($_POST['zipb64'])){$d=base64_decode(preg_replace('/\s+/','',$_POST['zipb64']),true);if($d&&strlen($d)>1000){$zipPath=sys_get_temp_dir().'/lc_b64_'.uniqid().'.zip';file_put_contents($zipPath,$d);}else $msg='Архив (base64) не распознан';}
 if($zipPath){ // обновление игры из архива minecraft.zip (папка minecraft/ внутри)
  $tmp=sys_get_temp_dir().'/lc_'.uniqid();@mkdir($tmp);$z=new ZipArchive;
  if($z->open($zipPath)===true){$z->extractTo($tmp);$z->close();
   $src=is_dir("$tmp/minecraft")?"$tmp/minecraft":$tmp;$n=0;
   foreach(['index.php','style.css','game.js','server.js','admin.php','README.md','install.sh','nginx.conf','package.json'] as $f)if(is_file("$src/$f")){copy("$src/$f","$ROOT/$f");$n++;}
   foreach(['mods','packs','plugins','servers_panel','server_panel'] as $d)if(is_dir("$src/$d")){@mkdir("$ROOT/$d");foreach(scandir("$src/$d") as $f)if($f[0]!=='.'&&is_file("$src/$d/$f")){copy("$src/$d/$f","$ROOT/$d/$f");$n++;}}
   $rs=@shell_exec('sudo -n /bin/systemctl restart loopcraft 2>&1 || sudo -n /usr/bin/systemctl restart loopcraft 2>&1');
   $msg="Игра обновлена: $n файлов. ".($rs===null||trim($rs)===''?'Игровой сервер перезапущен.':'Перезапустите игровой сервер вручную: systemctl restart loopcraft ('.trim($rs).')');
  }else $msg='Не удалось открыть zip';}
 if(isset($_POST['newpw'])&&strlen($_POST['newpw'])>=4){file_put_contents("$ROOT/data/admin.json",json_encode(['password'=>$_POST['newpw']]));$msg='Пароль изменён. systemctl restart loopcraft';}
 if(isset($_POST['delserver'])&&code_ok($_POST['delserver'])){$d="$SERVERS/{$_POST['delserver']}";if(is_dir($d)){$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($it as $f)$f->isDir()?rmdir($f):unlink($f);rmdir($d);$msg='Сервер удалён';}}}
?>
<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>loopcraft — панель серверов</title>
<style>
:root{color-scheme:dark}body{margin:0;background:#0b0a0f;color:#e8e2d6;font:17px 'Courier New',monospace;padding:16px}
h1{font-size:20px;margin:0 0 12px;color:#d8d2c6}h2{font-size:18px;color:#8fd18a;margin:18px 0 6px}
input,button,select,textarea{font:inherit;background:#1a1720;color:#fff;border:1px solid #4a4356;padding:5px;max-width:100%}
button{cursor:pointer;background:#4d4858}button:hover{background:#5d5870}button.warn{background:#6a2a2a}button.on{background:#3f6b3a}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:6px 0}
.box{background:#1a1720;border:1px solid #333;padding:10px;margin:8px 0}
.dim{color:#9a9184}pre{background:#000;border:1px solid #333;padding:8px;max-height:40vh;overflow:auto;white-space:pre-wrap;font-size:14px}
table{border-collapse:collapse;width:100%}td,th{border-bottom:1px solid #333;padding:4px 6px;text-align:left;font-size:15px;vertical-align:top}
form.inline{display:inline}.msg{background:#233;border:1px solid #466;padding:8px;white-space:pre-wrap}
label.f{display:flex;flex-direction:column;gap:2px;font-size:14px;color:#9a9184}label.f input,label.f textarea{color:#fff;font-size:16px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px}
</style></head><body>
<h1>loopcraft — панель серверов</h1>
<?php if($msg):?><div class="msg"><?=h($msg)?></div><?php endif;?>

<?php if($srv):?>
<div class="row"><a href="?logout=1"><button>Выйти</button></a><a href="./#<?=h($srv)?>"><button>Открыть игру</button></a>
 <?php if($auth):?><a href="?open="><button>Все серверы</button></a><?php endif;?>
 <span class="dim">сервер <b><?=h($p['name']??$srv)?></b> · адрес <b><?=h($_SERVER['HTTP_HOST'])?>:<?=h($srv)?></b> · <?=$info?($info['online']?'ОНЛАЙН · игроков '.count($info['players']):'выключен (создатель не в игре)'):'игровой сервер не отвечает'?></span></div>

<div class="box"><b>Игроки сейчас</b>
<?php if($info&&$info['players']):?><table><?php foreach($info['players'] as $pl):?><tr><td><?=h($pl)?><?=in_array(mb_strtolower($pl),$info['ops'])?' <span class="dim">(op)</span>':''?></td><td>
 <form method="post" class="inline"><button name="cmd" value="/op <?=h($pl)?>">op</button><button name="cmd" value="/deop <?=h($pl)?>">deop</button><button name="cmd" value="/kick <?=h($pl)?>">kick</button><button class="warn" name="cmd" value="/ban <?=h($pl)?>">ban</button><button class="warn" name="cmd" value="/blacklist add <?=h($pl)?>">в чёрный список</button></form></td></tr><?php endforeach;?></table>
<?php else:?><div class="dim">никого нет</div><?php endif;?>
<form method="post" class="row"><input name="cmd" placeholder="/help — команды (op): /stop /restart /horror enable /run by … /broadcast …" style="flex:1;min-width:240px"><button>Выполнить</button></form>
<div class="row"><form method="post" class="inline"><button name="cmd" value="/horror <?=($p['horror']??'')==='true'?'disable':'enable'?>">хоррор: <?=($p['horror']??'')==='true'?'ВКЛ → выключить':'выкл → включить'?></button><button name="cmd" value="/broadcast Сервер перезапустится через минуту">объявление</button><button name="cmd" value="/restart">перезапуск</button><button class="warn" name="cmd" value="/stop">остановить</button></form></div>
</div>

<div class="box"><b>server.properties</b>
<form method="post"><div class="grid">
 <label class="f">Название<input name="name" value="<?=h($p['name']??'')?>" maxlength="32"></label>
 <label class="f">Приветствие (motd)<input name="motd" value="<?=h($p['motd']??'')?>" maxlength="120"></label>
 <label class="f">Макс. игроков<input name="max-players" value="<?=h($p['max-players']??'16')?>"></label>
 <label class="f">Сид мира<input name="seed" value="<?=h($p['seed']??'')?>"></label>
 <label class="f">Погода (clear/rain/storm)<input name="weather" value="<?=h($p['weather']??'clear')?>"></label>
 <label class="f">Время (пусто = идёт само)<input name="time" value="<?=h($p['time']??'')?>"></label>
</div>
<div class="row">
 <label><input type="checkbox" name="public" <?=($p['public']??'true')!=='false'?'checked':''?>> показывать в списке</label>
 <label><input type="checkbox" name="horror" <?=($p['horror']??'')==='true'?'checked':''?>> хоррор</label>
 <label><input type="checkbox" name="core" <?=($p['core']??'true')!=='false'?'checked':''?>> плагин core</label>
 <label><input type="checkbox" name="whitelist-enabled" <?=($p['whitelist-enabled']??'')==='true'?'checked':''?>> белый список включён</label>
</div>
<div class="grid"><?php foreach($LISTS as $k=>$t):?><label class="f"><?=$t?> (имена через запятую)<textarea name="<?=$k?>" rows="2"><?=h($p[$k]??'')?></textarea></label><?php endforeach;?></div>
<div class="row"><label class="f">Новый пароль панели (оставь пустым, чтобы не менять)<input type="password" name="newpanelpw"></label></div>
<div class="row"><button name="saveprops" value="1">Сохранить и применить</button><span class="dim">владелец: <?=h($p['owner']??'')?> · создан <?=h(substr($p['created']??'',0,10))?></span></div>
</form>
<details><summary class="dim">редактировать файл целиком</summary><form method="post"><textarea name="raw" rows="12" style="width:100%"><?php foreach($p as $k=>$v)echo h("$k=$v")."\n";?></textarea><div class="row"><button name="rawprops" value="1" class="warn">Перезаписать server.properties</button></div></form></details>
</div>

<?php foreach($FOLDERS as $folder=>$title):$key=$folder==='resourcepacks'?'pack':$folder;$enabled=$key==='pack'?[$p['pack']??'']:array_map('trim',explode(',',$p[$key]??''));?>
<div class="box"><b><?=$title?></b> <span class="dim">servers/<?=h($srv)?>/<?=$folder?>/</span>
<table><?php $files=array_values(array_filter(scandir("$dir/$folder")?:[],fn($f)=>$f[0]!=='.'));foreach($files as $f):$on=in_array($f,$enabled)||($f==='core.lua'&&($p['core']??'true')!=='false');?>
<tr><td><?=h($f)?><?=$f==='core.lua'?' <span class="dim">(встроенный плагин)</span>':''?></td><td class="dim"><?=round(filesize("$dir/$folder/$f")/1024)?> КБ</td><td>
 <form method="post" class="inline"><input type="hidden" name="folder" value="<?=$folder?>"><button name="toggle" value="<?=h($f)?>" class="<?=$on?'on':''?>"><?=$on?'включён':'выключен'?></button>
 <?php if($f!=='core.lua'):?><a href="servers/<?=h($srv)?>/<?=$folder?>/<?=h($f)?>" target="_blank"><button type="button">открыть</button></a><button class="warn" name="del" value="<?=h($f)?>" onclick="return confirm('Удалить <?=h($f)?>?')">удалить</button><?php endif;?></form></td></tr>
<?php endforeach;if(!$files):?><tr><td colspan="3" class="dim">пусто</td></tr><?php endif;?></table>
<form method="post" enctype="multipart/form-data" class="row"><input type="hidden" name="folder" value="<?=$folder?>"><input type="file" name="up"><button>Загрузить и включить</button></form>
</div>
<?php endforeach;?>
<h2>Лог сервера</h2><pre><?php $lg=cj('/api/admin/log',null,['x-internal: '.$IKEY]);echo h(is_array($lg)?implode("\n",array_values(array_filter($lg,fn($l)=>strpos($l,"[$srv]")!==false))):'нет данных');?></pre>

<?php elseif($auth):?>
<div class="row"><a href="?logout=1"><button>Выйти</button></a><a href="./"><button>Открыть игру</button></a><span class="dim">администратор хостинга</span></div>
<h2>Все серверы</h2>
<?php $live=cj('/api/admin/rooms',null,['x-internal: '.$IKEY]);$codes=array_values(array_filter(scandir($SERVERS)?:[],fn($c)=>is_file("$SERVERS/$c/server.properties")));
foreach($codes as $c):$pp=props_read("$SERVERS/$c/server.properties");$li=null;if(is_array($live))foreach($live as $r)if($r['code']===$c)$li=$r;?>
<div class="box"><b style="color:#8fd18a"><?=h($pp['name']??$c)?></b> <span class="dim">адрес <?=h($c)?> · владелец <?=h($pp['owner']??'')?> · <?=$li&&$li['online']?'онлайн '.count($li['players']):'выключен'?> · <?=($pp['public']??'true')!=='false'?'публичный':'скрытый'?></span>
 <div class="row"><a href="?open=<?=h($c)?>"><button>Открыть панель</button></a><form method="post" class="inline" onsubmit="return confirm('Удалить сервер <?=h($c)?> со всеми файлами?')"><button class="warn" name="delserver" value="<?=h($c)?>">Удалить сервер</button></form></div></div>
<?php endforeach;if(!$codes):?><div class="box dim">серверов ещё нет — создаются в игре</div><?php endif;?>
<h2>Лог</h2><pre><?php $lg=cj('/api/admin/log',null,['x-internal: '.$IKEY]);echo h(is_array($lg)?implode("\n",$lg):'игровой сервер не отвечает');?></pre>
<h2>Пользователи (users.json)</h2>
<?php $users=@json_decode(@file_get_contents("$ROOT/users.json"),true)?:[];?>
<div class="box"><table><tr><th>имя</th><th>друзья</th><th>миры</th><th>создан</th></tr><?php foreach($users as $k=>$uu):$wd="$ROOT/worlds/".preg_replace('/[^\w\-а-яА-ЯёЁ.]/u','_',$uu['name']);$wn=is_dir($wd)?count(array_filter(scandir($wd),fn($d)=>$d[0]!=='.')):0;?>
<tr><td><?=h($uu['name'])?></td><td class="dim"><?=count($uu['friends']??[])?></td><td class="dim"><?=$wn?></td><td class="dim"><?=isset($uu['created'])?date('Y-m-d',intval($uu['created']/1000)):''?></td></tr><?php endforeach;if(!$users):?><tr><td colspan="4" class="dim">пока нет</td></tr><?php endif;?></table></div>
<h2>Обновить игру</h2><form method="post" enctype="multipart/form-data" class="row"><input type="file" name="gamezip" accept=".zip"><button>Загрузить minecraft.zip и обновить</button></form>
<form method="post" class="row"><input name="zipurl" placeholder="или ссылка на minecraft.zip (http…)" style="flex:1;min-width:260px"><button>Скачать и обновить</button></form>
<details><summary class="dim">или вставить архив как текст (base64)</summary><form method="post"><textarea name="zipb64" rows="4" style="width:100%" placeholder="содержимое minecraft.zip в base64"></textarea><div class="row"><button>Обновить из base64</button></div></form></details>
<div class="dim">Заменяет файлы игры (index.php, game.js, server.js, admin.php…) и перезапускает игровой сервер. Серверы, миры и аккаунты не трогаются.</div>
<h2>Пароль администратора</h2><form method="post" class="row"><input type="password" name="newpw" placeholder="новый пароль"><button>Сменить</button></form>

<?php else:?>
<div class="box"><b>Панель своего сервера</b> — <a href="servers_panel/" style="color:#8fd18a">Мои серверы</a> (вход аккаунтом игры: свои серверы, ссылка на 10 минут)</div>
<form method="post" class="box"><b>Панель по паролю сервера</b><div class="row"><input name="addr" placeholder="адрес: my-server или <?=h($_SERVER['HTTP_HOST'])?>:my-server" style="min-width:260px"><input type="password" name="spw" placeholder="пароль панели"><button name="slogin" value="1">Войти</button></div>
<div class="dim">Пароль задаётся при создании сервера в игре. Панель работает и когда сервер выключен.</div></form>
<form method="post" class="box"><b>Главный администратор</b> <span class="dim">(аккаунты Minecraft, Winnigames2024, LoopCraft)</span><div class="row"><input name="aname" placeholder="имя аккаунта"><input type="password" name="apw" placeholder="пароль аккаунта"><button name="alogin" value="1">Войти</button></div></form>
<?php if($PW!==''):?><details><summary class="dim">вход по паролю хостинга</summary><form method="post" class="box"><div class="row"><input type="password" name="pw" placeholder="пароль"><button name="login" value="1">Войти</button></div></form></details><?php endif;?>
<?php endif;?>
</body></html>
