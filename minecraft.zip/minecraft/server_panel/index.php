<?php
// loopcraft — /server/<имя>/?uuid=<токен на 10 минут> : панель одного сервера. Создатель: Winnigames2024
$API='http://127.0.0.1:3000';$ROOT=dirname(__DIR__,2);$SERVERS="$ROOT/servers";
function h($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function api($path,$post=null,$hdr=[]){global $API;$ch=curl_init($API.$path);curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);curl_setopt($ch,CURLOPT_TIMEOUT,5);
 if($post!==null){curl_setopt($ch,CURLOPT_POST,1);curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($post,JSON_UNESCAPED_UNICODE));$hdr[]='Content-Type: application/json';}
 curl_setopt($ch,CURLOPT_HTTPHEADER,$hdr);$r=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);return [$code,$r===false?null:json_decode($r,true)];}
function props_read($fp){$o=[];foreach(@file($fp)?:[] as $l){$l=trim($l);if($l===''||$l[0]==='#')continue;$i=strpos($l,'=');if($i===false)continue;$o[trim(substr($l,0,$i))]=trim(substr($l,$i+1));}return $o;}
function props_write($fp,$o){$out="# loopcraft server.properties — списки через запятую\n# Winnigames2024\n";foreach($o as $k=>$v)$out.="$k=$v\n";file_put_contents($fp,$out);}
$code=strtolower(preg_replace('/[^a-z0-9_\-]/i','',$_GET['s']??''));$uuid=preg_replace('/[^a-f0-9]/','',$_GET['uuid']??'');
$hdr=['x-panel: '.$uuid];[$c,$info]=api('/api/server/info',null,$hdr);
$ok=$c===200&&is_array($info)&&$info['code']===$code;$msg='';
$LISTS=['ops'=>'Операторы (op)','whitelist'=>'Белый список','blacklist'=>'Чёрный список','banned'=>'Забаненные'];
$FOLDERS=['mods'=>'Моды (js/css/html)','resourcepacks'=>'Ресурс-паки (zip)'];$UP=dirname(__DIR__).'/uploads/plugins';
function rrm($d){if(!is_dir($d))return;foreach(scandir($d) as $f){if($f==='.'||$f==='..')continue;$q="$d/$f";is_dir($q)?rrm($q):unlink($q);}rmdir($d);}
function pmeta($d){$j=@json_decode(@file_get_contents("$d/_data.json"),true);return is_array($j)?$j:null;}
function plist_set($pf,$fn){$p=props_read($pf);$arr=array_values(array_filter(array_map('trim',explode(',',$p['plugins']??''))));$arr=$fn($arr);$p['plugins']=implode(',',array_values(array_unique($arr)));props_write($pf,$p);}
if($ok){$dir="$SERVERS/$code";$pf="$dir/server.properties";
 if(isset($_POST['cmd'])){[$cc,$o]=api('/api/server/cmd',['text'=>$_POST['cmd']],$hdr);$msg=is_array($o)?implode("\n",$o):'ошибка';}
 if(isset($_POST['saveprops'])){$p=props_read($pf);
  foreach(['name','motd','max-players','seed','weather','time'] as $k)if(isset($_POST[$k]))$p[$k]=str_replace(["\n","\r"],'',mb_substr($_POST[$k],0,120));
  foreach(['public','horror','core','whitelist-enabled'] as $k)$p[$k]=!empty($_POST[$k])?'true':'false';
  foreach(array_keys($LISTS) as $k){$v=strtolower($_POST[$k]??'');$p[$k]=implode(',',array_values(array_filter(array_map('trim',preg_split('/[,\s]+/',$v)))));}
  if(!empty($_POST['newpanelpw'])&&strlen($_POST['newpanelpw'])>=4)$p['panel-password-hash']=hash('sha256',$_POST['newpanelpw']);
  props_write($pf,$p);api('/api/server/reload',null,$hdr);$msg='server.properties сохранён и применён';}
 if(isset($_POST['del'])&&isset($FOLDERS[$_POST['folder']])){$f=basename($_POST['del']);$fp="$dir/{$_POST['folder']}/$f";if(is_file($fp)&&$f!=='core.lua'){unlink($fp);$msg="Удалено: $f";}}
 if(isset($_FILES['up'])&&$_FILES['up']['error']===0&&isset($FOLDERS[$_POST['folder']])){$f=preg_replace('/[^\w.\-]/u','_',basename($_FILES['up']['name']));move_uploaded_file($_FILES['up']['tmp_name'],"$dir/{$_POST['folder']}/$f");
  $key=$_POST['folder']==='resourcepacks'?'pack':$_POST['folder'];$p=props_read($pf);
  if($key==='pack')$p['pack']=$f;else{$arr=array_filter(array_map('trim',explode(',',$p[$key]??'')));if(!in_array($f,$arr))$arr[]=$f;$p[$key]=implode(',',$arr);}
  props_write($pf,$p);api('/api/server/reload',null,$hdr);$msg="Загружено и включено: $f";}
 if(isset($_POST['toggle'])&&isset($FOLDERS[$_POST['folder']])){$f=basename($_POST['toggle']);$key=$_POST['folder']==='resourcepacks'?'pack':$_POST['folder'];$p=props_read($pf);
  if($key==='pack')$p['pack']=($p['pack']??'')===$f?'':$f;else{$arr=array_values(array_filter(array_map('trim',explode(',',$p[$key]??''))));if(in_array($f,$arr))$arr=array_values(array_diff($arr,[$f]));else $arr[]=$f;$p[$key]=implode(',',$arr);}
  if($f==='core.lua')$p['core']=($p['core']??'true')==='true'?'false':'true';props_write($pf,$p);api('/api/server/reload',null,$hdr);$msg='Изменено: '.$f;}
 // ---- вкладка «Плагины» ----
 if(isset($_POST['ptoggle'])){$f=basename($_POST['ptoggle']);plist_set($pf,fn($a)=>in_array($f,$a)?array_diff($a,[$f]):array_merge($a,[$f]));api('/api/server/reload',null,$hdr);$msg='Плагин: '.$f;}
 if(isset($_POST['pdel'])){$f=basename($_POST['pdel']);$fp="$dir/plugins/$f";if($f!=='core.lua'&&file_exists($fp)){is_dir($fp)?rrm($fp):unlink($fp);plist_set($pf,fn($a)=>array_diff($a,[$f]));api('/api/server/reload',null,$hdr);$msg="Удалено: $f";}}
 if(isset($_POST['builtin'])){$k=$_POST['builtin']==='authme'?'authme':'core';$p=props_read($pf);$cur=($p[$k]??($k==='core'?'true':'false'))==='true';$p[$k]=$cur?'false':'true';props_write($pf,$p);api('/api/server/reload',null,$hdr);if($k==='authme')api('/api/server/cmd',['text'=>'/authme '.($cur?'off':'on')],$hdr);$msg=$k.' '.($cur?'выключен':'включён');}
 if(isset($_POST['pcat'])){$slug=preg_replace('/[^a-z0-9_\-]/','',$_POST['pcat']);if(is_dir("$UP/$slug")){$f='pkg:'.$slug;plist_set($pf,fn($a)=>in_array($f,$a)?array_diff($a,[$f]):array_merge($a,[$f]));api('/api/server/reload',null,$hdr);$msg='Каталог: '.$slug;}}
 if(isset($_FILES['pzip'])&&$_FILES['pzip']['error']===0){$ch=curl_init($API.'/api/upload');curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>1,CURLOPT_POST=>1,CURLOPT_POSTFIELDS=>file_get_contents($_FILES['pzip']['tmp_name']),CURLOPT_HTTPHEADER=>['x-kind: plugins','x-name: '.preg_replace('/[^\w.\-]/u','_',basename($_FILES['pzip']['name'])),'x-panel: '.$uuid,'Content-Type: application/octet-stream']]);$r=json_decode(curl_exec($ch),true);$msg=!empty($r['ok'])?'Опубликовано в каталоге: '.$r['meta']['name'].' (автор '.$r['meta']['author'].')':'Ошибка публикации: '.($r['error']??'нет ответа');}
 if(isset($_FILES['plua'])&&$_FILES['plua']['error']===0){$f=preg_replace('/[^\w.\-]/u','_',basename($_FILES['plua']['name']));if(preg_match('/\.lua$/i',$f)){move_uploaded_file($_FILES['plua']['tmp_name'],"$dir/plugins/$f");plist_set($pf,fn($a)=>array_merge($a,[$f]));api('/api/server/reload',null,$hdr);$msg="Загружен и включён: $f";}else $msg='нужен .lua (пакеты .zip публикуются в каталог)';}
 if(isset($_GET['pdl'])){$slug=preg_replace('/[^a-z0-9_\-]/','',$_GET['pdl']);$src=is_dir("$UP/$slug")?"$UP/$slug":(is_dir("$dir/plugins/$slug")?"$dir/plugins/$slug":null);if($src&&class_exists('ZipArchive')){$tmp=tempnam(sys_get_temp_dir(),'pz');$z=new ZipArchive;$z->open($tmp,ZipArchive::OVERWRITE);$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($src,FilesystemIterator::SKIP_DOTS));foreach($it as $fl){$z->addFile($fl->getPathname(),substr($fl->getPathname(),strlen($src)+1));}$z->close();header('Content-Type: application/zip');header('Content-Disposition: attachment; filename="'.$slug.'.zip"');readfile($tmp);unlink($tmp);exit;}}
 [$c,$info]=api('/api/server/info',null,$hdr);$p=props_read($pf);}
?>
<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>loopcraft — сервер <?=h($code)?></title>
<style>:root{color-scheme:dark}body{margin:0;background:#0b0a0f;color:#e8e2d6;font:17px 'Courier New',monospace;padding:16px}h1{font-size:20px;color:#d8d2c6}h2{font-size:18px;color:#8fd18a;margin:18px 0 6px}
input,button,select,textarea{font:inherit;background:#1a1720;color:#fff;border:1px solid #4a4356;padding:5px;max-width:100%}button{cursor:pointer;background:#4d4858}button:hover{background:#5d5870}button.warn{background:#6a2a2a}button.on{background:#3f6b3a}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:6px 0}.box{background:#1a1720;border:1px solid #333;padding:10px;margin:8px 0}.dim{color:#9a9184}pre{background:#000;border:1px solid #333;padding:8px;max-height:40vh;overflow:auto;white-space:pre-wrap;font-size:14px}
table{border-collapse:collapse;width:100%}td,th{border-bottom:1px solid #333;padding:4px 6px;text-align:left;font-size:15px;vertical-align:top}form.inline{display:inline}.msg{background:#233;border:1px solid #466;padding:8px;white-space:pre-wrap}
nav.tabs{display:flex;gap:6px;flex-wrap:wrap;margin:10px 0}nav.tabs button.act{background:#3f6b3a}.tabsec{display:none}.tabsec.act{display:block}.pcard{border:1px solid #333;padding:8px;margin:6px 0;background:#141219}.pcard b{color:#fff}
label.f{display:flex;flex-direction:column;gap:2px;font-size:14px;color:#9a9184}label.f input,label.f textarea{color:#fff;font-size:16px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px}</style></head><body>
<?php if(!$ok):?><h1>Панель сервера</h1><div class="msg">Ссылка недействительна или истекла (действует 10 минут). Откройте панель заново: <a href="../servers_panel/" style="color:#8fd18a">Мои серверы</a></div></div>
<script>(function(){var bs=document.querySelectorAll('nav.tabs button'),cur=location.hash.replace('#','')||localStorage.getItem('lc_tab')||'players';function go(t){if(!document.getElementById('t_'+t))t='players';document.querySelectorAll('.tabsec').forEach(function(x){x.classList.toggle('act',x.id==='t_'+t);});bs.forEach(function(b){b.classList.toggle('act',b.dataset.t===t);});try{localStorage.setItem('lc_tab',t);}catch(e){}}
bs.forEach(function(b){b.onclick=function(){go(b.dataset.t);};});go(cur);})();</script>
</body></html><?php exit;endif;?>
<h1>Сервер <b style="color:#8fd18a"><?=h($info['name'])?></b> <span class="dim">адрес <?=h($_SERVER['HTTP_HOST'])?>:<?=h($code)?> · <?=count($info['players'])?' онлайн, игроков: '.count($info['players']):'выключен (никого нет)'?></span></h1>
<?php if($msg):?><div class="msg"><?=h($msg)?></div><?php endif;?>
<div class="row"><a href="../servers_panel/"><button>Мои серверы</button></a><a href="../#<?=h($code)?>"><button>Открыть игру</button></a><span class="dim">ссылка на эту панель действует 10 минут с последнего действия</span></div>
<?php $Q='?s='.h($code).'&uuid='.h($uuid); ?>
<nav class="tabs"><button data-t="players">Игроки</button><button data-t="props">Настройки</button><button data-t="plugins">Плагины</button><button data-t="files">Моды и паки</button><button data-t="log">Лог</button></nav>
<div class="tabsec" id="t_players">
<div class="box"><b>Игроки сейчас</b>
<?php if($info['players']):?><table><?php foreach($info['players'] as $pl):?><tr><td><?=h($pl)?><?=in_array(mb_strtolower($pl),$info['ops'])?' <span class="dim">(op)</span>':''?></td><td>
 <form method="post" action="<?=$Q?>" class="inline"><button name="cmd" value="/op <?=h($pl)?>">op</button><button name="cmd" value="/deop <?=h($pl)?>">deop</button><button name="cmd" value="/gamemode <?=h($pl)?> creative">creative</button><button name="cmd" value="/gamemode <?=h($pl)?> survival">survival</button><button name="cmd" value="/kick <?=h($pl)?>">kick</button><button class="warn" name="cmd" value="/ban <?=h($pl)?>">ban</button></form></td></tr><?php endforeach;?></table>
<?php else:?><div class="dim">никого нет</div><?php endif;?>
<form method="post" action="<?=$Q?>" class="row"><input name="cmd" placeholder="/help — команды" style="flex:1;min-width:240px"><button>Выполнить</button></form>
<div class="row"><form method="post" action="<?=$Q?>" class="inline"><button name="cmd" value="/horror <?=($p['horror']??'')==='true'?'disable':'enable'?>">хоррор: <?=($p['horror']??'')==='true'?'ВКЛ → выключить':'выкл → включить'?></button><button name="cmd" value="/time day">день</button><button name="cmd" value="/time night">ночь</button><button name="cmd" value="/broadcast Сервер перезапустится через минуту">объявление</button><button name="cmd" value="/restart">перезапуск</button><button class="warn" name="cmd" value="/stop">остановить</button></form></div>
</div>
</div><div class="tabsec" id="t_props">
<div class="box"><b>server.properties</b>
<form method="post" action="<?=$Q?>"><div class="grid">
 <label class="f">Название<input name="name" value="<?=h($p['name']??'')?>" maxlength="32"></label>
 <label class="f">Приветствие (motd)<input name="motd" value="<?=h($p['motd']??'')?>" maxlength="120"></label>
 <label class="f">Макс. игроков<input name="max-players" value="<?=h($p['max-players']??'16')?>"></label>
 <label class="f">Сид мира<input name="seed" value="<?=h($p['seed']??'')?>"></label>
 <label class="f">Погода (clear/rain/storm)<input name="weather" value="<?=h($p['weather']??'clear')?>"></label>
 <label class="f">Время (пусто = идёт само)<input name="time" value="<?=h($p['time']??'')?>"></label></div>
<div class="row"><label><input type="checkbox" name="public" <?=($p['public']??'true')!=='false'?'checked':''?>> показывать в списке</label><label><input type="checkbox" name="horror" <?=($p['horror']??'')==='true'?'checked':''?>> хоррор</label><label><input type="checkbox" name="core" <?=($p['core']??'true')!=='false'?'checked':''?>> плагин core</label><label><input type="checkbox" name="whitelist-enabled" <?=($p['whitelist-enabled']??'')==='true'?'checked':''?>> белый список включён</label></div>
<div class="grid"><?php foreach($LISTS as $k=>$t):?><label class="f"><?=$t?> (через запятую)<textarea name="<?=$k?>" rows="2"><?=h($p[$k]??'')?></textarea></label><?php endforeach;?></div>
<div class="row"><label class="f">Новый пароль панели (пусто — не менять)<input type="password" name="newpanelpw"></label></div>
<div class="row"><button name="saveprops" value="1">Сохранить и применить</button><span class="dim">владелец: <?=h($p['owner']??'')?></span></div></form></div>
</div><div class="tabsec" id="t_plugins">
<?php $enabledP=array_values(array_filter(array_map('trim',explode(',',$p['plugins']??''))));?>
<div class="box"><b>Встроенные</b>
<table>
<tr><td><b>core</b> <span class="dim">/stop /start /restart /horror /run /broadcast /weather…</span></td><td><form method="post" action="<?=$Q?>" class="inline"><button name="builtin" value="core" class="<?=($p['core']??'true')!=='false'?'on':''?>"><?=($p['core']??'true')!=='false'?'включён':'выключен'?></button></form></td></tr>
<tr><td><b>authme</b> <span class="dim">пароль на сервер: /register /login</span></td><td><form method="post" action="<?=$Q?>" class="inline"><button name="builtin" value="authme" class="<?=($p['authme']??'false')==='true'?'on':''?>"><?=($p['authme']??'false')==='true'?'включён':'выключен'?></button></form></td></tr>
</table></div>
<div class="box"><b>Установлено на сервере</b> <span class="dim">servers/<?=h($code)?>/plugins/</span>
<table><?php $pf_=array_values(array_filter(scandir("$dir/plugins")?:[],fn($f)=>$f[0]!=='.'&&$f!=='core.lua'));foreach($pf_ as $f):$isd=is_dir("$dir/plugins/$f");$m=$isd?pmeta("$dir/plugins/$f"):null;$on=in_array($f,$enabledP);?>
<tr><td><b><?=h($m['name']??$f)?></b><?php if($m):?> <span class="dim">v<?=h($m['version']??'')?> · <?=h($m['author']??'')?></span><div class="dim"><?=h($m['description']??'')?></div><?php endif;?></td>
<td><form method="post" action="<?=$Q?>" class="inline"><button name="ptoggle" value="<?=h($f)?>" class="<?=$on?'on':''?>"><?=$on?'включён':'выключен'?></button> <?php if($isd):?><a href="<?=$Q?>&pdl=<?=h($f)?>"><button type="button">скачать .zip</button></a> <?php endif;?><button class="warn" name="pdel" value="<?=h($f)?>" onclick="return confirm('Удалить <?=h($f)?>?')">удалить</button></form></td></tr>
<?php endforeach;if(!$pf_):?><tr><td colspan="2" class="dim">пусто</td></tr><?php endif;?></table>
<form method="post" action="<?=$Q?>" enctype="multipart/form-data" class="row"><input type="file" name="plua" accept=".lua"><button>Загрузить .lua и включить</button></form></div>
<div class="box"><b>Каталог плагинов</b> <span class="dim">общий для всех серверов — включай на своём</span>
<?php $cat=[];foreach(@scandir($UP)?:[] as $f){if($f[0]==='.')continue;$m=pmeta("$UP/$f");if($m)$cat[$f]=$m;}foreach($cat as $slug=>$m):$on=in_array('pkg:'.$slug,$enabledP);?>
<div class="pcard"><b><?=h($m['name'])?></b> <span class="dim">v<?=h($m['version']??'1.0')?> · автор <?=h($m['author']?:'—')?> · <?=count($m['lua']??[])?> lua</span><div><?=h($m['description']??'')?></div>
<div class="row"><form method="post" action="<?=$Q?>" class="inline"><button name="pcat" value="<?=h($slug)?>" class="<?=$on?'on':''?>"><?=$on?'включён на сервере':'включить на сервере'?></button></form> <a href="<?=$Q?>&pdl=<?=h($slug)?>"><button type="button">скачать .zip</button></a></div></div>
<?php endforeach;if(!$cat):?><div class="dim">каталог пуст — опубликуй первый плагин</div><?php endif;?>
</div>
<div class="box"><b>Опубликовать плагин в каталог</b>
<form method="post" action="<?=$Q?>" enctype="multipart/form-data" class="row"><input type="file" name="pzip" accept=".zip"><button>Опубликовать .zip</button></form>
<div class="dim">Архив: <code>_data.json</code> {"name","description","version"} · <code>data/</code> — файлы .lua · <code>data/files/</code> — картинки, звуки и т.д. Автор берётся из аккаунта, открывшего панель.</div></div>
</div><div class="tabsec" id="t_files">
<?php foreach($FOLDERS as $folder=>$title):$key=$folder==='resourcepacks'?'pack':$folder;$enabled=$key==='pack'?[$p['pack']??'']:array_map('trim',explode(',',$p[$key]??''));?>
<div class="box"><b><?=$title?></b> <span class="dim">servers/<?=h($code)?>/<?=$folder?>/</span>
<table><?php $files=array_values(array_filter(scandir("$dir/$folder")?:[],fn($f)=>$f[0]!=='.'));foreach($files as $f):$on=in_array($f,$enabled)||($f==='core.lua'&&($p['core']??'true')!=='false');?>
<tr><td><?=h($f)?><?=$f==='core.lua'?' <span class="dim">(встроенный)</span>':''?></td><td class="dim"><?=round(filesize("$dir/$folder/$f")/1024)?> КБ</td><td>
 <form method="post" action="<?=$Q?>" class="inline"><input type="hidden" name="folder" value="<?=$folder?>"><button name="toggle" value="<?=h($f)?>" class="<?=$on?'on':''?>"><?=$on?'включён':'выключен'?></button>
 <?php if($f!=='core.lua'):?><button class="warn" name="del" value="<?=h($f)?>" onclick="return confirm('Удалить <?=h($f)?>?')">удалить</button><?php endif;?></form></td></tr>
<?php endforeach;if(!$files):?><tr><td colspan="3" class="dim">пусто</td></tr><?php endif;?></table>
<form method="post" action="<?=$Q?>" enctype="multipart/form-data" class="row"><input type="hidden" name="folder" value="<?=$folder?>"><input type="file" name="up"><button>Загрузить и включить</button></form></div>
<?php endforeach;?>
</div><div class="tabsec" id="t_log">
<h2>Лог сервера</h2><pre><?=h(implode("\n",$info['log'])?:'пусто')?></pre>
</body></html>
