<?php
// loopcraft — страница забаненного аккаунта. Создатель: Winnigames2024
$MOBILE=isset($MOBILE)&&$MOBILE;$name=htmlspecialchars($_GET['name']??'');$reason=htmlspecialchars($_GET['reason']??'');$at=intval($_GET['at']??0);
?><!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>loopcraft — бан</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=VT323&family=Press+Start+2P&display=swap"><?php if($MOBILE):?><base href="../"><?php endif;?>
<style>html,body{height:100%;margin:0;background:#000;color:#eee;font-family:'VT323',monospace;font-size:22px}
body{background:repeating-linear-gradient(0deg,#2a1c0f 0 4px,#33200f 4px 8px),repeating-linear-gradient(90deg,rgba(0,0,0,.25) 0 8px,transparent 8px 16px);display:flex;align-items:center;justify-content:center;padding:16px;box-sizing:border-box}
.box{width:min(560px,100%);background:rgba(0,0,0,.85);border:3px solid #000;box-shadow:0 0 0 2px #333;padding:22px;text-align:center}
h1{font-family:'Press Start 2P',monospace;font-size:18px;color:#f55;text-shadow:3px 3px 0 #3a0000;margin:0 0 16px}
.r{color:#ff8;font-weight:bold;font-size:24px;margin:10px 0}
.d{color:#999;font-size:18px}
a.b{display:inline-block;margin-top:18px;font-family:'Press Start 2P',monospace;font-size:11px;color:#e0e0e0;text-decoration:none;background:linear-gradient(#8b8b8b,#6f6f6f);border:2px solid #000;box-shadow:inset 2px 2px 0 #b0b0b0,inset -2px -2px 0 #3f3f3f;padding:12px 20px;text-shadow:2px 2px 0 #3f3f3f}
</style></head><body><div class="box">
<h1>АККАУНТ ЗАБАНЕН</h1>
<div>Аккаунт <b><?=$name?:'—'?></b> заблокирован администрацией loopcraft.</div>
<div class="r">Причина: <?=$reason?:'нарушение правил'?></div>
<?php if($at):?><div class="d">Дата: <?=date('d.m.Y H:i',intval($at/1000))?></div><?php endif;?>
<div class="d">Играть на серверах и входить в аккаунт нельзя. Если считаешь бан ошибкой — напиши администратору сервера.</div>
<a class="b" href="<?=$MOBILE?'mobile/':'./'?>">В главное меню</a>
</div></body></html>
