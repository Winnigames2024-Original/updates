// Пример мода для loopcraft. Загрузите этот файл через Настройки → Моды.
// Всё API — в window.NC (см. README.md).
(function(){
  // 1) новый предмет-еда
  NC.registerItem({ n:'Пирог из пепла', kind:'food', c:[.4,.4,.45], food:6, dread:-10, desc:'Мод: тёплый и тихий.' });
  // 2) рецепт: 2 пепла + 1 хлеб → пирог
  NC.registerRecipe({ out:['Пирог из пепла',1], ing:[['Пепел',2],['Хлеб',1]] });
  // 3) реакция на события
  NC.on('break', e => { if (e.block === NC.N('Знак-камень')) NC.whisper('мод: ты не должен был'); });
  NC.on('chat', m => { if (/привет/i.test(m.text)) NC.chat('Мод здоровается с ' + m.name); });
  // 4) свой HUD (HTML + CSS)
  NC.addStyle('#modclock{position:absolute;left:50%;top:8px;transform:translateX(-50%);color:#8fd18a;font:20px VT323,monospace;text-shadow:1px 1px 0 #000}');
  const el = NC.addHTML('<div id="modclock">мод активен</div>');
  let t = 0; NC.on('tick', dt => { t += dt; if (t > 1) { t = 0; el.firstChild.textContent = 'мод: тревога ' + (NC.player.dread|0) + '% · мобов ' + NC.mobs.length; } });
  // 5) своя текстура блока (замените URL на свой png 16×16)
  // NC.setBlockTexture('stone', 'uploads/mods/mymod/stone.png');
  // 6) сетевое событие всем игрокам
  // NC.emit('boom', {x:1}); NC.on('net:boom', (data, fromId) => {...});
  NC.chat('example.js загружен. Скрафть «Пирог из пепла».');
})();
