-- Пример плагина loopcraft на Lua. Загрузите через Настройки → Плагины (выполняется у создателя сервера).
-- API: таблица nc. print(...) пишет в консоль.
print("example.lua запущен, игроков: " .. #nc.players())
nc.chat("Плагин приветствует сервер!")

-- команда каждому, кто написал "привет" в чат (data приходит JSON-строкой)
nc.on("chat", function(data)
  if string.find(string.lower(data), "привет") then
    nc.say("Сервер говорит: привет!")
  end
end)

-- каждый тик: ночью раз в ~30 секунд шёпот
local t = 0
nc.on("tick", function(dt)
  t = t + dt
  if t > 30 then
    t = 0
    if nc.night() then nc.whisper("плагин видит тебя") end
  end
end)

-- при поломке знак-камня — наказание
nc.on("break", function(data)
  if string.find(data, '"block":' .. tostring(nc.item("Знак-камень"))) then
    nc.dread(20)
    nc.cmd("say Кто-то сломал знак…")
  end
end)

-- серверные команды из плагина (как оператор): nc.cmd("time night"), nc.cmd("op имя"), nc.cmd("kick имя")
