-- Пример плагина-пакета loopcraft. Все .lua из data/ запускаются по порядку имён.
-- Ассеты: nc.asset("icon.png") -> URL файла из data/files/
print("Плагин " .. nc.pluginName .. " загружен")
nc.on("chat", function(ev)
  local e = js_json and js_json(ev) or nil
end)
nc.on("start", function() nc.chat("Добро пожаловать! Ассеты плагина: " .. nc.asset("icon.png")) end)
