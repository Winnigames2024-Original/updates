<?php
// loopcraft — главная страница. Создатель: Winnigames2024
$MOBILE=isset($MOBILE)&&$MOBILE;
$isPhone=preg_match('/Android|iPhone|iPad|iPod|Mobile|Tablet|Windows Phone/i',$_SERVER['HTTP_USER_AGENT']??'');
$PAGE=$PAGE??''; // '' = главное меню, 'single' = singleplayer.php, 'multi' = multiplayer.php
$self=basename($_SERVER['SCRIPT_NAME']);$self=$self==='index.php'?'':$self;
if(!$MOBILE&&$isPhone&&!isset($_GET['pc'])&&!isset($_COOKIE['nc_pc'])){header('Location: mobile/'.$self.(!empty($_SERVER['QUERY_STRING'])?'?'.$_SERVER['QUERY_STRING']:''));exit;}
$SUB=$MOBILE; $FORCE_TOUCH=$MOBILE||($isPhone&&!isset($_GET['pc']));
$online=@json_decode(@file_get_contents('http://127.0.0.1:3000/api/rooms',false,stream_context_create(['http'=>['timeout'=>1]])),true);
$servers=is_array($online)?count($online):null;
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="theme-color" content="#1a1a1a">
<?php if($SUB):?><base href="../"><?php endif;?><script>window.FORCE_TOUCH=<?=$FORCE_TOUCH?'true':'false'?>;window.PAGE=<?=json_encode($PAGE)?>;window.MOBILE=<?=$MOBILE?'true':'false'?>;</script>
<title>loopcraft</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=VT323&family=Press+Start+2P&display=swap">
<link rel="stylesheet" href="style.css">
</head>
<body>

<div id="app">
<canvas id="gl"></canvas>

<?php $home=$MOBILE?'mobile/':'./';$sp=$MOBILE?'mobile/singleplayer.php':'singleplayer.php';$mp=$MOBILE?'mobile/multiplayer.php':'multiplayer.php';?>
<?php if($PAGE===''):?>
<div id="menu">
  <div class="dirt"></div><div class="scan"></div>
  <div id="logo" class="null">LOOPCЯΛFT<span class="g">LOOPCЯΛFT</span><span class="b">LOOPCЯΛFT</span></div>
  <div id="splash">Loopcraft!</div>
  <div id="accbox"><b>Аккаунт</b> <span class="hint">нужен для серверов и друзей</span><div class="hint" id="accst"></div><div class="srow" id="accform"><input type="text" id="accname" placeholder="имя (English only)" maxlength="16" pattern="[A-Za-z0-9_]{3,16}"><input type="password" id="accpw" placeholder="пароль"><button class="sbtn" id="bLogin">Войти</button><button class="sbtn" id="bReg">Регистрация</button></div><div class="srow"><button class="sbtn" id="bLogout" hidden>Выйти из аккаунта</button><button class="sbtn" id="bMyServers" hidden>Мои серверы</button><button class="sbtn" id="bAdmin" hidden style="background:#6a2a2a">Admin</button></div></div>

  <a class="mbtn" id="bWorlds" href="<?=$sp?>">Одиночная игра</a>
  <a class="mbtn" id="bHost" href="<?=$mp?>">Сетевая игра</a>
  <div class="row">
    <button class="mbtn" id="bOptions">Настройки</button>
    <button class="mbtn" id="bTex">Текстуры</button>
    <button class="mbtn" id="bQuit">Выход</button>
  </div>
  <div class="note">Сетевая игра: создайте мир — ссылка появится в паузе; друзья входят по коду. Моды и ресурс-паки из настроек ставятся всем в мире автоматически.<br>ПК как в классике: WASD, мышь, ЛКМ ломать/бить, ПКМ ставить/есть, Shift красться, Ctrl бег, Space прыжок, E инвентарь, Q выбросить, T чат, / команды, F1 скрыть HUD, F3 координаты, 1–9 и колесо — слоты. Телефон: крестовина слева, прыжок и красться справа, тап по миру — поставить, удержание — ломать, двойной тап ▲ — бег.</div>
  <div id="ver">Loopcraft 1.0 · <?=$servers===null?'игровой сервер спит':('серверов: '.$servers)?></div>
  <div id="credit">Copyright Winnigames2024. Do not distribute!</div>
  <div hidden><a id="bBackMenu" href="<?=$home?>"></a><div id="wpanel">
    <div class="srow"><input type="text" id="wname" placeholder="название нового мира" maxlength="24"><input type="text" id="wseed" placeholder="сид (необязательно)" style="width:140px"><button class="sbtn" id="bNewWorld">Создать</button></div>
    <div class="flist" id="wlist"></div>
    <button class="sbtn" id="bSingle">Быстрый локальный мир</button>
  </div><div id="srvpanel">
    <div class="srow"><input type="text" id="srvip" placeholder="адрес (IP-имя): например my-server" maxlength="24" spellcheck="false"><span class="hint" id="ipst"></span></div>
    <div class="srow"><input type="text" id="srvname" placeholder="название сервера" maxlength="32"><input type="text" id="srvmax" value="16" style="width:60px" title="макс. игроков"><label><input type="checkbox" id="srvpub" checked> в списке</label></div>
    <div class="srow"><input type="password" id="srvpw" placeholder="пароль панели сервера (для admin.php)" maxlength="32"><button class="sbtn" id="bCreate">Создать сервер</button></div>
    <div class="srow"><span class="hint">Серверы (папка servers/)</span><button class="sbtn" id="bRefresh">Обновить</button></div>
    <div class="flist" id="srvlist"></div>
  </div><div id="srvmsg"></div><div id="joinbox"><input id="joincode"><button id="bJoin"></button></div></div>
</div>
<?php elseif($PAGE==='single'):?>
<div id="menu" class="screen">
  <div class="dirt"></div><div class="scan"></div>
  <div class="shead"><a class="mbtn back" id="bBackMenu" href="<?=$home?>">← Назад</a><div class="stitle">ОДИНОЧНАЯ ИГРА</div><div class="sacc" id="accst"></div></div>
  <div id="wpanel" class="spanel">
    <div class="slabel">Мои миры <span class="hint">(хранятся на сервере в worlds/)</span></div>
    <div class="flist big" id="wlist"></div>
    <div class="slabel">Создать новый мир</div>
    <div class="srow"><input type="text" id="wname" placeholder="название нового мира" maxlength="24"><input type="text" id="wseed" placeholder="сид (необязательно)" style="width:140px"><button class="sbtn" id="bNewWorld">Создать</button></div>
    <div class="srow"><button class="sbtn" id="bSingle">Быстрый локальный мир</button><button class="sbtn" id="bOptions">Настройки</button></div>
  </div>
  <div id="srvmsg" class="hint" style="min-height:22px"></div>
  <div hidden><div id="logo"></div><div id="splash"></div><div id="accbox"><div id="accform"><input id="accname"><input id="accpw"><button id="bLogin"></button><button id="bReg"></button></div><button id="bLogout"></button><button id="bMyServers"></button><button id="bAdmin"></button></div><a id="bWorlds"></a><a id="bHost"></a><button id="bTex"></button><button id="bQuit"></button><div id="srvpanel">
    <div class="srow"><input type="text" id="srvip" placeholder="адрес (IP-имя): например my-server" maxlength="24" spellcheck="false"><span class="hint" id="ipst"></span></div>
    <div class="srow"><input type="text" id="srvname" placeholder="название сервера" maxlength="32"><input type="text" id="srvmax" value="16" style="width:60px" title="макс. игроков"><label><input type="checkbox" id="srvpub" checked> в списке</label></div>
    <div class="srow"><input type="password" id="srvpw" placeholder="пароль панели сервера (для admin.php)" maxlength="32"><button class="sbtn" id="bCreate">Создать сервер</button></div>
    <div class="srow"><span class="hint">Серверы (папка servers/)</span><button class="sbtn" id="bRefresh">Обновить</button></div>
    <div class="flist" id="srvlist"></div>
  </div><div id="joinbox"><input id="joincode"><button id="bJoin"></button></div><div id="ver"></div></div>
</div>
<?php else:?>
<div id="menu" class="mc">
  <div class="dirt"></div><div class="scan"></div>
  <div class="mctitle">Сетевая игра</div>
  <div class="mclist"><div id="srvlist" class="mcrows"></div></div>
  <div class="mcbottom">
    <div id="srvmsg" class="mcmsg"></div>
    <div class="mcrow"><button class="mbtn" id="bJoinSel" disabled>Подключиться</button><button class="mbtn" id="bByAddr">По адресу</button><button class="mbtn" id="bAddSrv">Добавить</button></div>
    <div class="mcrow"><button class="mbtn" id="bAccBtn">Аккаунт</button><button class="mbtn" id="bRefresh">Обновить</button><a class="mbtn" id="bBackMenu" href="<?=$home?>">Назад</a></div>
  </div>
  <div class="mcdlg" id="dlgAddr" hidden><div class="mcbox"><div class="mctitle small">Прямое подключение</div><div class="hint">Адрес сервера</div><div id="joinbox"><input id="joincode" placeholder="my-server или 166.1.161.200:my-server" spellcheck="false"></div><div class="mcrow"><button class="mbtn" id="bJoin">Подключиться</button><button class="mbtn mcclose">Отмена</button></div></div></div>
  <div class="mcdlg" id="dlgAdd" hidden><div class="mcbox"><div class="mctitle small">Создать сервер</div>
    <div class="srow"><input type="text" id="srvip" placeholder="адрес (IP-имя): например my-server" maxlength="24" spellcheck="false"><span class="hint" id="ipst"></span></div>
    <div class="srow"><input type="text" id="srvname" placeholder="название сервера" maxlength="32"><input type="text" id="srvmax" value="16" style="width:60px" title="макс. игроков"><label><input type="checkbox" id="srvpub" checked> в списке</label></div>
    <div class="srow"><input type="password" id="srvpw" placeholder="пароль панели сервера (для admin.php)" maxlength="32"></div>
    <div class="mcrow"><button class="mbtn" id="bCreate">Создать</button><button class="mbtn mcclose">Отмена</button></div></div></div>
  <div class="mcdlg" id="dlgAcc" hidden><div class="mcbox"><div class="mctitle small">Аккаунт</div><div id="accbox"><div class="hint" id="accst"></div><div class="srow" id="accform"><input type="text" id="accname" placeholder="имя аккаунта (English)" maxlength="16" pattern="[A-Za-z0-9_]{3,16}"><input type="password" id="accpw" placeholder="пароль"></div><div class="mcrow" id="accbtns"><button class="mbtn" id="bLogin">Войти</button><button class="mbtn" id="bReg">Регистрация</button></div><div class="mcrow"><button class="mbtn" id="bLogout" hidden>Выйти из аккаунта</button><button class="mbtn" id="bMyServers" hidden>Мои серверы</button><button class="mbtn" id="bAdmin" hidden style="background:#6a2a2a">Admin</button></div><div class="mcrow"><button class="mbtn mcclose">Закрыть</button></div></div></div></div>
  <div hidden><div id="logo"></div><div id="splash"></div><a id="bWorlds"></a><a id="bHost"></a><button id="bOptions"></button><button id="bTex"></button><button id="bQuit"></button><div id="wpanel"><input id="wname"><input id="wseed"><button id="bNewWorld"></button><div id="wlist"></div><button id="bSingle"></button></div><div id="ver"></div><div id="srvpanel"></div></div>
</div>
<?php endif;?>

<div id="hud">
  <div id="vignette"></div><div id="static"></div><div id="dmg"></div><div id="flash"></div>
  <div id="cross"></div>
  <div id="lockhint" hidden>Кликни по миру, чтобы захватить мышь (Esc — отпустить)</div>
  <div id="topleft"></div>
  <div id="topright"></div>
  <div id="dread"><i></i></div>
  <div id="chat"></div>
  <input id="chatin" placeholder="сообщение… (/ — команды, Tab — подсказка)" maxlength="120"><div id="hints" hidden></div>
  <div id="sel-name"></div>
  <div id="bars"><div class="bar" id="hp"></div><div class="bar" id="hu"></div></div>
  <div id="hotbar"></div>
</div>

<div id="touch">
  <div id="dpad"><div class="tb dk" id="dU">▲</div><div class="tb dk" id="dL">◀</div><div class="tb dk" id="dR">▶</div><div class="tb dk" id="dD">▼</div></div>
  <div class="tb" id="tjump">⬆</div><div class="tb" id="tsneak">⇩</div><div class="tb" id="tchat">💬</div>
  <div class="tb" id="tinv">E</div><div class="tb" id="tmenu">≡</div><div class="tb" id="ttab">👥</div>
</div>

<div id="inv"><div id="invp">
  <h2 id="invtitle">ИНВЕНТАРЬ</h2>
  <div id="craftwrap"><div class="clabel">Крафт</div><div id="craftarea"></div></div>
  <div id="invgrid"></div>
  <div id="invhot"></div>
  <div id="invinfo">ЛКМ — взять/положить, ПКМ — половина/по одному, Shift+ЛКМ — быстро переложить. Рецепты ниже: клик выкладывает на сетку.</div>
  <div class="clabel">Рецепты</div><div id="recipebook"></div>
  <div><button class="mbtn" id="bCloseInv" style="width:auto;font-size:11px">Закрыть (E)</button></div>
</div></div>
<div id="cursorItem" hidden></div>

<div id="pause">
  <button class="mbtn back" id="bBack">← Назад в игру</button>
  <div id="logo" style="font-size:20px">ПАУЗА</div>
  <button class="mbtn" id="bResume">Продолжить</button>
  <button class="mbtn" id="bSave">Сохранить мир</button>
  <div id="share"><b>Мир по ссылке</b><input id="linkbox" readonly><div style="display:flex;gap:6px"><button class="mbtn" id="bCopy" style="font-size:18px">Копировать ссылку</button></div><div class="st" id="netst">Сеть: не подключено</div><label style="display:flex;gap:8px;align-items:center;cursor:pointer"><input type="checkbox" id="tts"> Озвучивать сообщения чата вслух</label></div>
  <button class="mbtn" id="bSettings2">Настройки</button>
  <button class="mbtn" id="bConsole">Консоль сервера</button>
  <a class="mbtn" id="bPanel" href="servers_panel/" target="_blank" style="text-decoration:none;display:block;text-align:center">Панель моих серверов</a>
  <div id="friends"><b>Друзья</b><div class="srow"><input type="text" id="frname" placeholder="имя друга"><button class="sbtn" id="bFrAdd">Добавить</button></div><div class="flist" id="frlist"></div></div>
  <div id="console" hidden><pre id="conlog"></pre><input id="conin" placeholder="/help — команды (op)"></div>
  <button class="mbtn" id="bToMenu">В главное меню</button>
</div>

<div id="modui"></div>
<div id="settings"><div id="setp">
  <h2>НАСТРОЙКИ</h2>
  <div class="srow"><label>Имя игрока (= аккаунт)</label><input type="text" id="s_name" maxlength="16" disabled></div>
  <div class="srow"><label>Угол обзора (FOV)</label><input type="range" id="s_fov" min="50" max="110" value="75"><span id="s_fov_v">75</span></div>
  <div class="srow"><label>Дальность прорисовки</label><input type="range" id="s_dist" min="30" max="160" value="90"><span id="s_dist_v">90</span></div>
  <div class="srow"><label>Чувствительность мыши</label><input type="range" id="s_sens" min="1" max="20" value="6"><span id="s_sens_v">6</span></div>
  <div class="srow"><label>Инверсия мыши</label><input type="checkbox" id="s_inv"></div>
  <div class="srow"><label>Управление</label><select id="s_touch"><option value="auto">авто</option><option value="off">мышь и клавиатура</option><option value="on">сенсорное (телефон)</option></select><span class="hint">если на ПК не крутится обзор — выбери «мышь и клавиатура»</span></div>
  <div class="srow"><label>Звук</label><input type="range" id="s_vol" min="0" max="100" value="60"><span id="s_vol_v">60</span></div>
  <div class="srow"><label>Озвучивать чат</label><input type="checkbox" id="s_tts"></div>
  <div class="srow"><label>Мистика</label><select id="s_myst"><option value="0.5">тише</option><option value="1" selected>обычно</option><option value="2">громче</option></select></div>
  <div class="srow"><label>Скин / модель</label><input type="file" id="s_skin" accept="image/png,.bbmodel,.json"><button class="sbtn" id="s_skined">Редактор скинов</button><button class="sbtn" id="s_skinoff">Сбросить</button></div>
  <div class="hint" id="s_skin_st">PNG 32×32 (голова 0,0 · тело 16,0 · ноги 0,16 · руки 16,16) или модель из Blockbench (.bbmodel, формат Generic Model с одной текстурой) — модель станет твоим персонажем.</div>
  <div id="skined" hidden><div class="srow"><b>Редактор скинов</b><span class="hint">рисуй мышью; квадраты 16×16: голова · тело / ноги · руки</span></div>
   <div class="srow" style="align-items:flex-start"><canvas id="skcanvas" width="32" height="32"></canvas><canvas id="skprev"></canvas>
   <div style="display:flex;flex-direction:column;gap:6px"><div id="skpal"></div><div class="srow"><span id="skcur" class="skc"></span><input type="color" id="skcolor" value="#e0b090"></div>
   <div class="srow" id="sktools"><button class="sbtn on" data-t="pen">карандаш</button><button class="sbtn" data-t="fill">заливка</button><button class="sbtn" data-t="eraser">ластик</button></div>
   <div class="srow"><input type="file" id="skload" accept="image/png"><button class="sbtn" id="sksave">Сохранить и надеть</button><button class="sbtn" id="skclose">Закрыть</button></div></div></div></div>

  <h3>Ресурс-паки</h3>
  <div class="hint">ZIP с .png файлами 16×16. Имена: <code>stone.png</code>, <code>grass_top.png</code>, <code>grass_side.png</code>, <code>dirt.png</code>, <code>log_top.png</code>… (полный список — кнопка «Список текстур»). Можно класть в подпапки, ищется по имени файла. Выбранный пак ставится всем игрокам в мире.</div>
  <div class="srow"><input type="file" id="s_pack" accept=".zip"><button class="sbtn" id="s_packup">Загрузить на сервер</button><button class="sbtn" id="s_texlist">Список текстур</button><button class="sbtn" id="s_packoff">Без пака</button></div>
  <div class="flist" id="packlist"></div>

  <h3>Моды (JS / HTML / CSS)</h3>
  <div class="hint">Файл <code>.js</code>, <code>.css</code>, <code>.html</code> или ZIP с ними. Включённые моды ставятся всем игрокам в мире. API для модов: <code>window.NC</code> (см. README и <code>mods/example.js</code>).</div>
  <div class="srow"><input type="file" id="s_mod" accept=".js,.css,.html,.zip" multiple><button class="sbtn" id="s_modup">Загрузить на сервер</button></div>
  <div class="flist" id="modlist"></div>

  <h3>Плагины на Lua</h3>
  <div class="hint">Файл <code>.lua</code>. Плагины сервера выполняются у создателя сервера. API — таблица <code>nc</code> (см. README, пример <code>plugins/example.lua</code>). Команды: <code>/help</code>, права — <code>/op имя</code>.</div>
  <div class="srow"><input type="file" id="s_plug" accept=".lua" multiple><button class="sbtn" id="s_plugup">Загрузить на сервер</button></div>
  <div class="flist" id="pluginlist"></div>

  <h3>Голосовой чат</h3>
  <div id="voice"><button class="sbtn" id="s_voice">Включить микрофон</button><span class="hint" id="s_voice_st"></span></div>
  <div><button class="mbtn" id="bCloseSet" style="width:auto;font-size:20px">Закрыть</button></div>
</div></div>
<div id="tablist" hidden></div><div id="bcast"></div><div id="rain"></div>
<div id="dead"><h1 id="deadmsg">Ты умер.</h1><div id="deadsub" style="color:#ffd">Кто-то забрал твои вещи.</div><button class="mbtn" id="bRespawn" style="width:auto">Возродиться</button></div>
</div>


<script src="lib/three.min.js" onerror="var s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';document.head.appendChild(s)"></script>
<script src="lib/jszip.min.js" onerror="var s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js';document.head.appendChild(s)"></script>
<script src="lib/fengari-web.js" onerror="var s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/fengari-web@0.1.4/dist/fengari-web.js';document.head.appendChild(s)"></script>
<script>window.addEventListener("load",function(){var s=document.createElement("script");s.src="game.js";document.body.appendChild(s);});</script>
</body>
</html>
