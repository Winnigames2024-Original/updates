<?php
// loopcraft — страница «multiplayer». Создатель: Winnigames2024
$PAGE='multi';
require __DIR__.'/../index.php';
