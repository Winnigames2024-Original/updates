#!/bin/bash
# loopcraft — утилита управления. Создатель: Winnigames2024
# loopcraft -canplayeropen:true|false  — могут ли игроки открывать игру (админы могут всегда)
# loopcraft start|stop|restart|status  — сервис игрового сервера
ROOT=/var/www/minecraft
case "$1" in
 -canplayeropen:false|-canplayeropen:off|-tehnicalwork:true) mkdir -p $ROOT/data && touch $ROOT/data/closed && chown www-data:www-data $ROOT/data/closed && echo "canplayeropen: false — игроки получают ERR_TEHNICALWORKS, админы играют";;
 -canplayeropen:true|-canplayeropen:on|-tehnicalwork:false) rm -f $ROOT/data/closed $ROOT/data/tehnicalwork && echo "canplayeropen: true — игра открыта всем";;
 -canplayeropen|-canplayeropen:status) [ -f $ROOT/data/closed ] && echo "canplayeropen: false" || echo "canplayeropen: true";;
 start|stop|restart|status) systemctl $1 loopcraft;;
 *) echo "loopcraft -canplayeropen:true|false | start|stop|restart|status";;
esac
