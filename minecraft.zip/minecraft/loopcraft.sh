#!/bin/bash
# loopcraft — утилита управления. Создатель: Winnigames2024
# loopcraft -tehnicalwork:true|false   — технические работы (всем, кроме админов, ERR_TEHNICALWORKS)
# loopcraft start|stop|restart|status  — сервис игрового сервера
ROOT=/var/www/minecraft
case "$1" in
 -tehnicalwork:true|-technicalwork:true|-tehnicalwork:on)  mkdir -p $ROOT/data && touch $ROOT/data/tehnicalwork && chown www-data:www-data $ROOT/data/tehnicalwork && echo "tehnicalwork: ON (все, кроме админов, получают ERR_TEHNICALWORKS)";;
 -tehnicalwork:false|-technicalwork:false|-tehnicalwork:off) rm -f $ROOT/data/tehnicalwork && echo "tehnicalwork: OFF (игра открыта)";;
 -tehnicalwork|-tehnicalwork:status) [ -f $ROOT/data/tehnicalwork ] && echo "tehnicalwork: ON" || echo "tehnicalwork: OFF";;
 start|stop|restart|status) systemctl $1 loopcraft;;
 *) echo "loopcraft -tehnicalwork:true|false | start|stop|restart|status";;
esac
