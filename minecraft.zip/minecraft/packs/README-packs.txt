Ресурс-пак для loopcraft = ZIP-архив с PNG-файлами 16x16 (подпапки допустимы; ищется по имени файла).
Имена файлов (без расширения): stone, dirt, grass_top, grass_side, cobblestone, planks, sand, gravel, log, log_top,
leaves, water, glass, coal_ore, iron_ore, gold_ore, torch, brick, mossy_cobblestone, bookshelf, clay, snow, snow_side,
ice, ash, void_stone, whisper_crystal, moss, bone_block, amber, sigil_stone, mirror_stone, fog_lantern, lunar_ore,
rust_block, dead_log, dead_log_top, salt, shadow_glass, red_leaves, candle, giant_mushroom, giant_mushroom_bottom.
Полный актуальный список: Настройки -> "Список текстур". Неизвестные файлы игнорируются.
