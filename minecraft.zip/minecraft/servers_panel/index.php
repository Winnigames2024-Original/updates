<?php
// loopcraft — /servers/ : выбор своих серверов (вход аккаунтом игры). Создатель: Winnigames2024
session_start();$API='http://127.0.0.1:3000';
function h($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function api($path,$post=null,$hdr=[]){global $API;$ch=curl_init($API.$path);curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);curl_setopt($ch,CURLOPT_TIMEOUT,5);
 if($post!==null){curl_setopt($ch,CURLOPT_POST,1);curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($post,JSON_UNESCAPED_UNICODE));$hdr[]='Content-Type: application/json';}
 curl_setopt($ch,CURLOPT_HTTPHEADER,$hdr);$r=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);return [$code,$r===false?null:json_decode($r,true)];}
$msg='';
if(isset($_GET['logout'])){unset($_SESSION['acc_token'],$_SESSION['acc_name']);header('Location: ./');exit;}
if(isset($_POST['login'])){[$c,$j]=api('/api/account/login',['name'=>$_POST['name']??'','password'=>$_POST['password']??'']);
 if($c===200&&!empty($j['ok'])){$_SESSION['acc_token']=$j['token'];$_SESSION['acc_name']=$j['name'];}else $msg=$j['error']??'игровой сервер не отвечает';}
if(!empty($_GET['tok'])){ // вход по токену аккаунта из игры
 [$c,$me]=api('/api/account/me',null,['x-token: '.$_GET['tok']]);if($c===200&&!empty($me['name'])){$_SESSION['acc_token']=$_GET['tok'];$_SESSION['acc_name']=$me['name'];}else $msg='Сессия игры не подтверждена — войдите вручную';}
$tok=$_SESSION['acc_token']??'';$servers=null;
if($tok){[$c,$servers]=api('/api/myservers',null,['x-token: '.$tok]);if($c!==200){$servers=null;unset($_SESSION['acc_token']);$tok='';$msg='Сессия истекла, войдите снова';}}
if($tok&&is_array($servers)&&count($servers)===1&&!isset($_GET['open'])&&!isset($_GET['list'])){$_GET['open']=$servers[0]['code'];} // один сервер — открываем сразу
if($tok&&isset($_GET['open'])){[$c,$j]=api('/api/server/login',['room'=>$_GET['open'],'token'=>$tok]);
 if($c===200&&!empty($j['ok'])){header('Location: ../server_panel/index.php?s='.rawurlencode($j['code']).'&uuid='.$j['token']);exit;}$msg=$j['error']??'не удалось открыть панель';}
?>
<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>loopcraft — мои серверы</title>
<style>:root{color-scheme:dark}body{margin:0;background:#0b0a0f;color:#e8e2d6;font:17px 'Courier New',monospace;padding:16px}h1{font-size:20px;color:#d8d2c6}
input,button{font:inherit;background:#1a1720;color:#fff;border:1px solid #4a4356;padding:6px}button{cursor:pointer;background:#4d4858}button:hover{background:#5d5870}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:6px 0}.box{background:#1a1720;border:1px solid #333;padding:10px;margin:8px 0}.dim{color:#9a9184}.msg{background:#233;border:1px solid #466;padding:8px}b.n{color:#8fd18a}</style></head><body>
<h1>loopcraft — мои серверы</h1>
<?php if($msg):?><div class="msg"><?=h($msg)?></div><?php endif;?>
<?php if(!$tok):?>
<form method="post" class="box"><b>Вход аккаунтом игры</b><div class="row"><input name="name" placeholder="имя аккаунта"><input type="password" name="password" placeholder="пароль"><button name="login" value="1">Войти</button></div>
<div class="dim">Показываются серверы, где вы создатель или оператор. Если сервер один — панель откроется сразу. Ссылка действует 10 минут.</div></form>
<?php else:?>
<div class="row"><span>Вы: <b class="n"><?=h($_SESSION['acc_name'])?></b><?=!empty($servers[0]['super'])?' <span class="dim">(главный администратор — доступ ко всем серверам)</span>':''?></span><a href="?logout=1"><button>Выйти</button></a><a href="../"><button>В игру</button></a><?php if(!empty($servers[0]["super"])):?><a href="../admin.php"><button style="background:#6a2a2a">Admin</button></a><?php endif;?></div>
<?php if(!$servers):?><div class="box dim">У вас пока нет серверов. Создайте сервер в игре — и он появится здесь.</div><?php endif;?>
<?php foreach((array)$servers as $s):?><div class="box"><b class="n"><?=h($s['name'])?></b> <span class="dim">адрес <?=h($s['code'])?> · владелец <?=h($s['owner'])?> · <?=$s['online']?'онлайн '.$s['players']:'выключен'?></span>
<div class="row"><a href="?open=<?=h($s['code'])?>"><button>Открыть панель сервера</button></a></div></div><?php endforeach;?>
<?php endif;?>
</body></html>
