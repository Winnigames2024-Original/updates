<?php
// loopcraft — бан (мобильная). Создатель: Winnigames2024
$MOBILE=true;
require __DIR__.'/../banned.php';
