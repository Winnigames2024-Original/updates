<?php
// loopcraft — Сетевая игра (мобильная). Создатель: Winnigames2024
$MOBILE=true;
$PAGE='multi';
require __DIR__.'/../index.php';
