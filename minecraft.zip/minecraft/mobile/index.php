<?php
// loopcraft — мобильная версия (та же игра, сенсорное управление, полный экран, landscape). Создатель: Winnigames2024
$MOBILE=true;
require __DIR__.'/../index.php';
