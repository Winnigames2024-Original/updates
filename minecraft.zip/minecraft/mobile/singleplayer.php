<?php
// loopcraft — Одиночная игра (мобильная). Создатель: Winnigames2024
$MOBILE=true;
$PAGE='single';
require __DIR__.'/../index.php';
