// loopcraft server — created by Winnigames2024
// No dependencies. Serves the game, uploads (mods / packs / skins / lua plugins), worlds ("servers") over WebSocket,
// operator commands, admin web console.  Run: node server.js   (port 3000; nginx proxies to it)
const http=require('http'),fs=require('fs'),path=require('path'),url=require('url'),crypto=require('crypto');
const ROOT=__dirname,PORT=process.env.PORT||3000;
const UP=path.join(ROOT,'uploads');for(const d of['mods','packs','skins','plugins'])fs.mkdirSync(path.join(UP,d),{recursive:true});
const DATA=path.join(ROOT,'data');fs.mkdirSync(DATA,{recursive:true});
// admin password: data/admin.json {"password":"..."}; created with a random password on first run (printed to log)
const ADMINF=path.join(DATA,'admin.json');let ADMIN={password:''};
try{ADMIN=JSON.parse(fs.readFileSync(ADMINF));}catch(e){ADMIN={password:''};fs.writeFileSync(ADMINF,JSON.stringify(ADMIN,null,1));}
// внутренний ключ для панели (admin.php на этом же сервере) — не пароль, живёт в data/internal.key
const IKF=path.join(DATA,'internal.key');let IKEY='';try{IKEY=fs.readFileSync(IKF,'utf8').trim();}catch(e){IKEY=crypto.randomBytes(16).toString('hex');fs.writeFileSync(IKF,IKEY);}
const LOG=[];function log(s){const line=new Date().toISOString().slice(11,19)+' '+s;LOG.push(line);if(LOG.length>500)LOG.shift();console.log(line);}
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.zip':'application/zip','.txt':'text/plain; charset=utf-8','.md':'text/plain; charset=utf-8','.lua':'text/plain; charset=utf-8','.ico':'image/x-icon','.mp3':'audio/mpeg','.ogg':'audio/ogg','.wav':'audio/wav'};
const safe=n=>String(n||'').replace(/[^a-zA-Z0-9а-яА-ЯёЁ_.\-]/g,'_').replace(/\.{2,}/g,'.').slice(0,80)||'file';
const CORS={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'*','Access-Control-Allow-Methods':'GET,POST,DELETE,OPTIONS'};
function send(res,code,body,type){res.writeHead(code,Object.assign({'Content-Type':type||'application/json'},CORS));res.end(body);}
function listDir(dir){try{return fs.readdirSync(path.join(UP,dir)).filter(f=>!f.startsWith('.')).map(f=>{const st=fs.statSync(path.join(UP,dir,f));return{name:f,size:st.size,dir:st.isDirectory()};});}catch(e){return[];}}
function walk(dir,base){let out=[];for(const f of fs.readdirSync(dir)){const p=path.join(dir,f);const st=fs.statSync(p);if(st.isDirectory())out=out.concat(walk(p,base));else out.push(path.relative(base,p).split(path.sep).join('/'));}return out;}
function body(req,cb){const chunks=[];let size=0;req.on('data',c=>{size+=c.length;if(size>60e6)req.destroy();chunks.push(c);});req.on('end',()=>cb(Buffer.concat(chunks)));}
/* ================= accounts & friends ================= */
const ACCF=path.join(ROOT,'users.json');let ACC={};try{ACC=JSON.parse(fs.readFileSync(ACCF));}catch(e){try{ACC=JSON.parse(fs.readFileSync(path.join(DATA,'accounts.json')));}catch(e2){}}
function saveAcc(){fs.writeFile(ACCF,JSON.stringify(ACC,null,1),()=>{});}
const WORLDS=path.join(ROOT,'worlds');fs.mkdirSync(WORLDS,{recursive:true});
const sessions=new Map(); // token -> name(lower)
const hashPw=(p,salt)=>crypto.createHash('sha256').update(salt+':'+p).digest('hex');
function accountByToken(req){return sessions.get(String(req.headers['x-token']||''))||null;}
function whereIs(name){for(const r of rooms.values())if(findPlayer(r,name))return {code:r.code,name:r.name};return null;}
function accountApi(p,req,res,u){
 if(p==='/api/account/register'&&req.method==='POST'){body(req,b=>{let j={};try{j=JSON.parse(b);}catch(e){}const name=String(j.name||'').trim().slice(0,16);const key=name.toLowerCase();
  if(!/^[A-Za-z0-9_]{3,16}$/.test(name))return send(res,400,'{"error":"Имя: только английские буквы, цифры и _ (3–16 символов)"}');if(String(j.password||'').length<4)return send(res,400,'{"error":"Пароль от 4 символов"}');
  if(ACC[key])return send(res,409,'{"error":"Имя уже занято"}');const salt=crypto.randomBytes(8).toString('hex');ACC[key]={name,salt,hash:hashPw(j.password,salt),friends:[],created:Date.now()};saveAcc();
  const tok=crypto.randomBytes(16).toString('hex');sessions.set(tok,key);log('account registered: '+name);send(res,200,JSON.stringify({ok:true,token:tok,name}));});return true;}
 if(p==='/api/account/login'&&req.method==='POST'){body(req,b=>{let j={};try{j=JSON.parse(b);}catch(e){}const key=String(j.name||'').trim().toLowerCase();const a=ACC[key];
  if(!a||a.hash!==hashPw(String(j.password||''),a.salt))return send(res,401,'{"error":"Неверное имя или пароль"}');const tok=crypto.randomBytes(16).toString('hex');sessions.set(tok,key);send(res,200,JSON.stringify({ok:true,token:tok,name:a.name}));});return true;}
 const key=accountByToken(req);
 if(p==='/api/account/me'){if(!key)return send(res,401,'{"error":"не вошёл"}'),true;const a=ACC[key];return send(res,200,JSON.stringify({name:a.name,super:isSuper(key),friends:a.friends.map(f=>({name:(ACC[f]||{}).name||f,online:whereIs(f)})),requests:(a.requests||[]).map(f=>(ACC[f]||{}).name||f)})),true;}
 if(p==='/api/account/friend'&&req.method==='POST'){if(!key)return send(res,401,'{"error":"не вошёл"}'),true;body(req,b=>{let j={};try{j=JSON.parse(b);}catch(e){}const f=String(j.name||'').trim().toLowerCase();const act=j.action||'add';const a=ACC[key];
  if(act==='remove'){a.friends=a.friends.filter(x=>x!==f);if(ACC[f])ACC[f].friends=ACC[f].friends.filter(x=>x!==key);saveAcc();return send(res,200,'{"ok":true}');}
  if(!ACC[f]||f===key)return send(res,404,'{"error":"Игрок с таким именем не зарегистрирован"}');
  if(act==='accept'){a.requests=(a.requests||[]).filter(x=>x!==f);if(!a.friends.includes(f))a.friends.push(f);if(!ACC[f].friends.includes(key))ACC[f].friends.push(key);saveAcc();return send(res,200,'{"ok":true}');}
  if(a.friends.includes(f))return send(res,200,'{"ok":true,"already":true}');const rq=ACC[f].requests=(ACC[f].requests||[]);if(!rq.includes(key))rq.push(key);saveAcc();send(res,200,'{"ok":true,"sent":true}');});return true;}
 if(p==='/api/account/exists'){const key2=String(u.query.name||'').trim().toLowerCase();return send(res,200,JSON.stringify({exists:!!ACC[key2]})),true;}
 return false;}
const isAdmin=req=>(ADMIN.password&&req.headers['x-admin']===ADMIN.password)||req.headers['x-internal']===IKEY||isSuper(accountByToken(req)||'');

const server=http.createServer((req,res)=>{
 const u=url.parse(req.url,true);const p=decodeURIComponent(u.pathname);
 if(req.method==='OPTIONS')return send(res,204,'','text/plain');
 if(p.startsWith('/api/account/')&&accountApi(p,req,res,u))return;
 if(p==='/api/list'){const kind=safe(u.query.kind||'mods');const srv=String(u.query.server||'').toLowerCase();let base=path.join(UP,kind);
  if(srv&&CODE_RE.test(srv)&&fs.existsSync(roomDir(srv)))base=path.join(roomDir(srv),kind==='packs'?'resourcepacks':kind);
  let items=[];try{items=fs.readdirSync(base).filter(f=>!f.startsWith('.')).map(f=>{const st=fs.statSync(path.join(base,f));const it={name:f,size:st.size,dir:st.isDirectory()};if(it.dir)it.files=walk(path.join(base,f),base);return it;});}catch(e){}
  return send(res,200,JSON.stringify(items));}
 if(p==='/api/upload'&&req.method==='POST'){
  const kind=safe(req.headers['x-kind']||'mods');if(!['mods','packs','skins','plugins'].includes(kind))return send(res,400,'{"error":"kind"}');
  const rel=String(req.headers['x-name']||'file').split('/').map(safe).join('/');
  const srv=String(req.headers['x-server']||'').toLowerCase();let base=path.join(UP,kind),urlBase='/uploads/'+kind+'/';
  if(srv&&CODE_RE.test(srv)&&fs.existsSync(roomDir(srv))){const sub=kind==='packs'?'resourcepacks':kind;base=path.join(roomDir(srv),sub);urlBase='/servers/'+srv+'/'+sub+'/';}
  const dest=path.join(base,rel);if(!dest.startsWith(base))return send(res,400,'{"error":"path"}');
  fs.mkdirSync(path.dirname(dest),{recursive:true});
  body(req,b=>{fs.writeFileSync(dest,b);log('upload '+urlBase+rel+' ('+b.length+' b)');send(res,200,JSON.stringify({ok:true,url:urlBase+rel}));});return;}
 if(p==='/api/world'){ // worlds/<имя пользователя>/<имя мира>_<uuid>/world.json
  const acc=accountByToken(req);const user=acc?ACC[acc].name:('guest_'+safe(u.query.tok||'').slice(0,16));if(!acc&&(!u.query.tok||String(u.query.tok).length<8))return send(res,400,'{"error":"tok"}');
  const udir=path.join(WORLDS,safe(user));const name=String(u.query.name||'world').replace(/[^\wа-яА-ЯёЁ\- ]/gu,'').trim().slice(0,24)||'world';
  const findDir=()=>{try{for(const d of fs.readdirSync(udir)){const meta=JSON.parse(fs.readFileSync(path.join(udir,d,'meta.json')));if(meta.name===name)return path.join(udir,d);}}catch(e){}return null;};
  if(u.query.list){const out=[];try{for(const d of fs.readdirSync(udir)){try{const meta=JSON.parse(fs.readFileSync(path.join(udir,d,'meta.json')));const st=fs.statSync(path.join(udir,d,'world.json'));out.push({name:meta.name,uuid:meta.uuid,folder:d,updated:st.mtimeMs,size:st.size,created:meta.created});}catch(e){}}}catch(e){}return send(res,200,JSON.stringify(out));}
  if(req.method==='POST'){let dir=findDir();if(!dir){const uuid=crypto.randomUUID();dir=path.join(udir,safe(name).replace(/ /g,'_')+'_'+uuid);fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'meta.json'),JSON.stringify({name,uuid,owner:user,created:new Date().toISOString()}));}
   body(req,b=>{fs.writeFileSync(path.join(dir,'world.json'),b);send(res,200,JSON.stringify({ok:true,folder:path.basename(dir)}));});return;}
  const dir=findDir();
  if(req.method==='DELETE'){if(dir){for(const f of fs.readdirSync(dir))fs.unlinkSync(path.join(dir,f));fs.rmdirSync(dir);}return send(res,200,'{"ok":true}');}
  if(!dir)return send(res,404,'{"error":"nofile"}');fs.readFile(path.join(dir,'world.json'),(e,d)=>{if(e)return send(res,404,'{"error":"nofile"}');send(res,200,d);});return;}
 if(p==='/api/check'){const code=safe(u.query.room||'').toLowerCase();const name=String(u.query.name||'').slice(0,16).toLowerCase();const sname=String(u.query.server||'').slice(0,32).toLowerCase();
  const r=room(code);const out={valid:CODE_RE.test(code),roomExists:!!r,online:!!r&&r.players.size>0,players:r?r.players.size:0,max:r?r.max:16,nameTaken:!!(r&&findPlayer(r,name)),banned:!!(r&&(r.bans.includes(name)||r.blacklist.includes(name))),whitelisted:!r||!r.wlOn||r.whitelist.includes(name)||r.ops.includes(name),serverNameTaken:!!sname&&[...rooms.values()].some(x=>x.name.toLowerCase()===sname)};
  return send(res,200,JSON.stringify(out));}
 // ---- per-server panel login (password set by the creator when the server was created) ----
 if(p==='/api/myservers'){const acc=accountByToken(req);if(!acc)return send(res,401,'{"error":"не вошёл"}');for(const c of allServerCodes())room(c);
  const mine=[...rooms.values()].filter(r=>isSuper(acc)||(r.ownerName||'').toLowerCase()===acc||r.ops.includes(acc)).map(r=>({code:r.code,name:r.name,online:r.players.size>0,players:r.players.size,owner:r.ownerName,super:isSuper(acc)}));
  return send(res,200,JSON.stringify(mine));}
 if(p==='/api/server/login'&&req.method==='POST'){body(req,b=>{let j={};try{j=JSON.parse(b);}catch(e){}const m=/([a-z0-9][a-z0-9_\-]{2,23})\s*$/i.exec(String(j.room||''));const r=m?room(m[1].toLowerCase()):null;
  if(!r)return send(res,404,'{"error":"сервер не найден"}');
  const acc=j.token?sessions.get(String(j.token)):null;const byAcc=acc&&(isSuper(acc)||(r.ownerName||'').toLowerCase()===acc);
  if(!byAcc){if(!r.panelHash)return send(res,404,'{"error":"у сервера нет пароля панели"}');if(crypto.createHash('sha256').update(String(j.password||'')).digest('hex')!==r.panelHash)return send(res,401,'{"error":"неверный пароль"}');}
  const tok=crypto.randomBytes(16).toString('hex');panelTokens.set(tok,{code:r.code,exp:Date.now()+10*60*1000,by:acc||'password'});log('['+r.code+'] panel login by '+(acc||'password'));send(res,200,JSON.stringify({ok:true,token:tok,code:r.code,name:r.name,expires:10*60}));});return;}
 if(p.startsWith('/api/server/')){const tk=String(req.headers['x-panel']||u.query.uuid||'');const pt=panelTokens.get(tk);if(pt&&pt.exp<Date.now())panelTokens.delete(tk);const r=pt&&pt.exp>=Date.now()?rooms.get(pt.code):null;if(!r)return send(res,401,'{"error":"token"}');pt.exp=Date.now()+10*60*1000;
  if(p==='/api/server/reload'){reloadProps(r);bc(r,{t:'mods',mods:r.mods});bc(r,{t:'pack',pack:r.pack});bc(r,{t:'plugins',plugins:r.plugins});bc(r,{t:'horror',horror:r.horror});bc(r,{t:'core',core:r.core});return send(res,200,'{"ok":true}');}
  if(p==='/api/server/info')return send(res,200,JSON.stringify({code:r.code,name:r.name,players:[...r.players.values()].map(c=>c.name),ops:r.ops,bans:r.bans,mods:r.mods,pack:r.pack,plugins:r.plugins,max:r.max,public:r.public,log:LOG.filter(l=>l.includes('['+r.code+']')).slice(-100)}));
  if(p==='/api/server/cmd'&&req.method==='POST'){body(req,b=>{let j={};try{j=JSON.parse(b);}catch(e){}const out=[];command(r,null,'[panel]',String(j.text||''),l=>out.push(l));send(res,200,JSON.stringify(out));});return;}
  return send(res,404,'{"error":"api"}');}
 if(p==='/api/rooms'){for(const c of allServerCodes())room(c);return send(res,200,JSON.stringify([...rooms.values()].filter(r=>r.public!==false).map(r=>({code:r.code,name:r.name,players:r.players.size,max:r.max,online:r.players.size>0,owner:r.ownerName,mods:r.mods.length,pack:!!r.pack,plugins:r.plugins.length,wl:r.wlOn}))));}
 // ---- admin console API ----
 if(p.startsWith('/api/admin/')){if(!isAdmin(req))return send(res,401,'{"error":"password"}');
  if(p==='/api/admin/log')return send(res,200,JSON.stringify(LOG.slice(-200)));
  if(p==='/api/admin/rooms'){for(const c of allServerCodes())room(c);return send(res,200,JSON.stringify([...rooms.values()].map(r=>({code:r.code,name:r.name,players:[...r.players.values()].map(c=>c.name),ops:r.ops,bans:r.bans,mods:r.mods,pack:r.pack,plugins:r.plugins,max:r.max,public:r.public,online:r.players.size>0}))));}
  if(p==='/api/admin/cmd'&&req.method==='POST'){body(req,b=>{let j={};try{j=JSON.parse(b);}catch(e){}const r=room(String(j.room||'').toLowerCase());if(!r)return send(res,404,'{"error":"room"}');const out=[];command(r,null,'[admin]',String(j.text||''),l=>out.push(l));save(r);send(res,200,JSON.stringify(out));});return;}
  return send(res,404,'{"error":"api"}');}
 // static
 if(/\/servers\/[^/]+\/(server\.properties|world\.json)$/.test(p)||p==='/users.json'||p.startsWith('/worlds/'))return send(res,403,'forbidden','text/plain');
 let fp=path.join(ROOT,p==='/'?'index.php':p);if(!fp.startsWith(ROOT)||fp.startsWith(DATA))return send(res,403,'forbidden','text/plain');
 fs.stat(fp,(e,st)=>{if(e||!st.isFile())return send(res,404,'not found','text/plain');res.writeHead(200,Object.assign({'Content-Type':MIME[path.extname(fp).toLowerCase()]||'application/octet-stream','Cache-Control':'no-cache'},CORS));fs.createReadStream(fp).pipe(res);});
});

/* ================= rooms ("servers") ================= */
const rooms=new Map();let nextId=1;const panelTokens=new Map();
const SERVERS=path.join(ROOT,'servers');fs.mkdirSync(SERVERS,{recursive:true});
const CODE_RE=/^[a-z0-9][a-z0-9_\-]{2,23}$/;
const roomDir=code=>path.join(SERVERS,code);
const LISTS=['ops','bans','whitelist','blacklist','mods','plugins'];
function propsRead(fp){const o={};try{for(const line of fs.readFileSync(fp,'utf8').split(/\r?\n/)){const t=line.trim();if(!t||t[0]==='#')continue;const i=t.indexOf('=');if(i<0)continue;o[t.slice(0,i).trim()]=t.slice(i+1).trim();}}catch(e){}return o;}
function propsWrite(fp,o){const lines=['# loopcraft server.properties — редактируется в панели или вручную; списки через запятую','# Winnigames2024'];for(const k of Object.keys(o))lines.push(k+'='+o[k]);fs.writeFileSync(fp,lines.join('\n')+'\n');}
const list=v=>String(v||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
const CORE_LUA=`-- core — встроенный плагин loopcraft (выполняется самим сервером, этот файл — описание).
-- Включить/выключить: server.properties → core=true|false, или /plugins core on|off, или в панели.
-- Команды (op): /stop /start /restart /op /deop /horror enable|disable
--   /run by <игрок> <команда> | /run in <сервер> <команда> | /run from <игрок> <текст>
--   /broadcast <текст> /motd <текст> /weather clear|rain|storm /clearmobs /whitelist on|off|add|remove|list /blacklist add|remove|list
`;
function createServer(code,opts){const d=roomDir(code);if(fs.existsSync(d))return false;for(const sub of['plugins','mods','resourcepacks'])fs.mkdirSync(path.join(d,sub),{recursive:true});
 fs.writeFileSync(path.join(d,'plugins','core.lua'),CORE_LUA);
 propsWrite(path.join(d,'server.properties'),{name:String(opts.name||code).slice(0,32),motd:'Добро пожаловать на '+String(opts.name||code).slice(0,32),'max-players':String(Math.max(1,Math.min(64,+opts.max||16))),public:String(opts.public!==false),horror:'false',core:'true',seed:String(opts.seed||Math.floor(Math.random()*899999+1000)),'whitelist-enabled':'false',whitelist:'',ops:String(opts.owner||'').toLowerCase(),blacklist:'',banned:'',pack:'',mods:'',plugins:'',time:'',weather:'clear',owner:String(opts.owner||''),'panel-password-hash':opts.panelPw?crypto.createHash('sha256').update(String(opts.panelPw)).digest('hex'):'','created':new Date().toISOString()});
 fs.writeFileSync(path.join(d,'world.json'),'{}');log('server created: '+code);return true;}
function room(code){let r=rooms.get(code);if(r){return r;}const d=roomDir(code);if(!fs.existsSync(path.join(d,'server.properties')))return null;
 r={code,name:code,seed:1,edits:{},players:new Map(),mods:[],pack:null,plugins:[],ops:[],bans:[],whitelist:[],blacklist:[],wlOn:false,max:16,public:true,time:null,dirty:false,owner:null,ownerName:null,panelHash:null,horror:false,core:true,motd:'',weather:'clear'};
 reloadProps(r);try{r.edits=JSON.parse(fs.readFileSync(path.join(d,'world.json')))||{};}catch(e){}rooms.set(code,r);return r;}
function reloadProps(r){const p=propsRead(path.join(roomDir(r.code),'server.properties'));r.props=p;
 r.name=p.name||r.code;r.motd=p.motd||'';r.max=Math.max(1,Math.min(64,+p['max-players']||16));r.public=p.public!=='false';r.horror=p.horror==='true';r.core=p.core!=='false';r.seed=+p.seed||1;
 r.wlOn=p['whitelist-enabled']==='true';r.whitelist=list(p.whitelist);r.ops=list(p.ops);r.blacklist=list(p.blacklist);r.bans=list(p.banned);r.pack=p.pack||null;r.mods=list(p.mods);r.plugins=list(p.plugins);
 r.time=p.time===''||p.time==null?null:+p.time;try{r.spawn=p.spawn?JSON.parse(p.spawn):null;}catch(e){r.spawn=null;}r.weather=p.weather||'clear';r.ownerName=p.owner||null;r.panelHash=p['panel-password-hash']||null;}
function save(r){if(!r.dirty)return;r.dirty=false;const p=r.props||{};Object.assign(p,{name:r.name,motd:r.motd||'','max-players':String(r.max),public:String(r.public),horror:String(r.horror),core:String(r.core),seed:String(r.seed),'whitelist-enabled':String(r.wlOn),whitelist:r.whitelist.join(','),ops:r.ops.join(','),blacklist:r.blacklist.join(','),banned:r.bans.join(','),pack:r.pack||'',mods:r.mods.join(','),plugins:r.plugins.join(','),time:r.time==null?'':String(r.time),spawn:r.spawn?JSON.stringify(r.spawn):'',weather:r.weather||'clear',owner:r.ownerName||'','panel-password-hash':r.panelHash||''});
 try{propsWrite(path.join(roomDir(r.code),'server.properties'),p);fs.writeFileSync(path.join(roomDir(r.code),'world.json'),JSON.stringify(r.edits));}catch(e){log('save error '+r.code+': '+e.message);}}
function allServerCodes(){try{return fs.readdirSync(SERVERS).filter(f=>fs.existsSync(path.join(SERVERS,f,'server.properties')));}catch(e){return[];}}
setInterval(()=>rooms.forEach(save),5000);
function bc(r,msg,except){const s=JSON.stringify(msg);for(const [id,c] of r.players){if(id!==except&&c.ws.readyState===1)c.ws.send(s);}}
function tell(r,id,msg){const c=r.players.get(id);if(c&&c.ws.readyState===1)c.ws.send(JSON.stringify(msg));}
const SUPER=['minecraft','winnigames2024','loopcraft'];const isSuper=n=>SUPER.includes(String(n||'').toLowerCase());
const isOp=(r,c)=>!!c&&(r.owner===c.id||r.ops.includes(c.name.toLowerCase())||isSuper(c.name));
function findPlayer(r,name){name=String(name||'').toLowerCase();for(const [id,c] of r.players)if(c.name.toLowerCase()===name)return c;return null;}
// ---- operator / console commands ----
function command(r,c,who,text,out){ // c = calling client (null = admin console)
 const parts=text.trim().replace(/^\//,'').split(/\s+/);const cmd=(parts[0]||'').toLowerCase();const a=parts.slice(1);
 const op=!c||isOp(r,c);const say=l=>{out(l);log('['+r.code+'] '+who+': /'+text.replace(/^\//,'')+' -> '+l);};
 if(cmd==='me'){bc(r,{t:'chat',name:'*',text:who+' '+a.join(' ')});return;}
 if(cmd==='tell'||cmd==='msg'||cmd==='w'){const t=findPlayer(r,a[0]);if(!t)return say('игрок не найден');tell(r,t.id,{t:'chat',name:who+' → тебе',text:a.slice(1).join(' ')});return say('→ '+t.name+': '+a.slice(1).join(' '));}
 if(cmd==='seed')return say('сид: '+r.seed);
 if(cmd==='save-all'||cmd==='save'){r.dirty=true;save(r);return say('мир сохранён');}
 if(cmd==='pardon'){if(!op)return say('нужны права оператора');const n=String(a[0]||'').toLowerCase();r.bans=r.bans.filter(x=>x!==n);r.blacklist=r.blacklist.filter(x=>x!==n);r.dirty=true;return say(n+' прощён');}
 if(cmd==='kill'){let t=c;if(a[0]){if(!op)return say('нужны права оператора');t=findPlayer(r,a[0]);}if(!t)return say('игрок не найден');tell(r,t.id,{t:'kill'});return say(t.name+' убит');}
 if(cmd==='clear'){let t=c;if(a[0]){if(!op)return say('нужны права оператора');t=findPlayer(r,a[0]);}if(!t)return say('игрок не найден');tell(r,t.id,{t:'clearinv'});return say('инвентарь '+t.name+' очищен');}
 if(cmd==='spawnpoint'){if(!c)return say('только из игры');tell(r,c.id,{t:'setspawn',x:c.x,y:c.y,z:c.z,personal:true});return say('личная точка появления установлена');}
 if(cmd==='reloadprops'){if(c)return say('только из панели');save(r);reloadProps(r);bc(r,{t:'mods',mods:r.mods});bc(r,{t:'pack',pack:r.pack});bc(r,{t:'plugins',plugins:r.plugins});bc(r,{t:'horror',horror:r.horror});bc(r,{t:'core',core:r.core});bc(r,{t:'info',name:r.name});for(const [id2,cl] of [...r.players]){const ln=cl.name.toLowerCase();if(r.bans.includes(ln)||r.blacklist.includes(ln)||(r.wlOn&&!r.whitelist.includes(ln)&&!r.ops.includes(ln))){tell(r,id2,{t:'closed',reason:'Тебе закрыт вход на этот сервер'});cl.ws.close(true);}}return say('настройки перечитаны');}
 if(cmd==='help'){say('все: /list /say /me /tell /seed /sleep /kill /clear /heal /fly /spawnpoint · op: /op /deop /kick /ban /pardon /unban /tp /give /gamemode /time set /weather /summon /setblock /fill /setworldspawn /setmax /public /private /name /plugins /reload /clearmobs /broadcast /motd /save-all /whitelist /blacklist');if(r.core)say('плагин core: /stop /start /restart /horror enable|disable /run by|in|from … /whitelist /blacklist /plugins core on|off');return;}
 // ---- built-in server plugin "core" ----
 if(cmd==='plugins'&&a[0]==='core'){if(!op)return say('нужны права оператора');r.core=a[1]!=='off';r.dirty=true;bc(r,{t:'core',core:r.core});return say('плагин core '+(r.core?'включён':'выключен'));}
 if(['stop','start','restart','horror','run','broadcast','motd','weather','clearmobs'].includes(cmd)){
  if(!op)return say('нужны права оператора');
  if(['stop','start','restart','horror','run'].includes(cmd)&&!r.core)return say('плагин core выключен (/plugins core on)');
  if(cmd==='stop'){bc(r,{t:'closed',reason:'Сервер остановлен оператором'});r.dirty=true;save(r);for(const [,c] of r.players)c.ws.close(true);r.players.clear();r.owner=null;return say('сервер остановлен, мир сохранён');}
  if(cmd==='start'){r.stopped=false;return say('сервер запущен: игроки могут входить по адресу '+r.code);}
  if(cmd==='restart'){bc(r,{t:'restart'});r.dirty=true;save(r);return say('перезапуск: все игроки переподключаются');}
  if(cmd==='horror'){r.horror=a[0]==='enable'||a[0]==='on'||a[0]==='вкл';r.dirty=true;bc(r,{t:'horror',horror:r.horror});return say('хоррор '+(r.horror?'ВКЛЮЧЁН — Смотрящий проснулся':'выключен'));}
  if(cmd==='run'){ // /run by <игрок> <команда>  |  /run in <сервер> <команда>  |  /run from <игрок> <текст в чат>
   const mode=(a[0]||'').toLowerCase();const target=a[1];const rest=a.slice(2).join(' ');if(!mode||!target||!rest)return say('/run by <игрок> <команда> | /run in <сервер> <команда> | /run from <игрок> <текст>');
   if(mode==='by'){const t=findPlayer(r,target);if(!t)return say('игрок не найден');command(r,t,who+'→'+t.name,rest.startsWith('/')?rest:'/'+rest,out);return;}
   if(mode==='in'){const rr=[...rooms.values()].find(x=>x.code===target.toLowerCase()||x.name.toLowerCase()===target.toLowerCase());if(!rr)return say('сервер не найден');command(rr,null,who+'@'+r.code,rest.startsWith('/')?rest:'/'+rest,out);return;}
   if(mode==='from'){const t=findPlayer(r,target);bc(r,{t:'chat',name:t?t.name:target,text:rest});return say('отправлено от имени '+target);}
   return say('режим: by | in | from');}
  if(cmd==='broadcast'){bc(r,{t:'broadcast',text:a.join(' ')});return say('объявление показано всем');}
  if(cmd==='motd'){r.motd=a.join(' ').slice(0,120);r.dirty=true;return say('приветствие: '+r.motd);}
  if(cmd==='weather'){r.weather=a[0]||'clear';bc(r,{t:'weather',weather:r.weather});return say('погода: '+r.weather);}
  if(cmd==='clearmobs'){bc(r,{t:'clearmobs'});return say('мобы убраны');}
 }
 if(!op&&!['help','list','me','tell','msg','w','seed','sleep','kill','clear','spawnpoint','heal','fly','save-all','save'].includes(cmd))return say('команды доступны только операторам');
 if(cmd==='list')return say('игроки ('+r.players.size+'/'+r.max+'): '+[...r.players.values()].map(p=>p.name+(isOp(r,p)?'*':'')).join(', '));
 if(cmd==='say')return bc(r,{t:'chat',name:'[сервер]',text:a.join(' ')});
 if(cmd==='sleep'){r.time=40;bc(r,{t:'settime',time:40});return say('утро');}
 if(!op)return say('нужны права оператора');
 if(cmd==='op'){const n=a.join(' ').toLowerCase();if(!n)return say('/op имя');if(!r.ops.includes(n))r.ops.push(n);r.dirty=true;const t=findPlayer(r,n);if(t)tell(r,t.id,{t:'op',op:true});return say(n+' теперь оператор');}
 if(cmd==='deop'){const n=a.join(' ').toLowerCase();r.ops=r.ops.filter(x=>x!==n);r.dirty=true;const t=findPlayer(r,n);if(t)tell(r,t.id,{t:'op',op:false});return say(n+' больше не оператор');}
 if(cmd==='kick'){const t=findPlayer(r,a[0]);if(!t)return say('игрок не найден');tell(r,t.id,{t:'closed',reason:'Тебя выгнали'+(a[1]?': '+a.slice(1).join(' '):'')});t.ws.close(true);return say(t.name+' выгнан');}
 if(cmd==='ban'){const n=String(a[0]||'').toLowerCase();if(!n)return say('/ban имя');if(!r.bans.includes(n))r.bans.push(n);r.dirty=true;const t=findPlayer(r,n);if(t){tell(r,t.id,{t:'closed',reason:'Ты забанен'});t.ws.close(true);}return say(n+' забанен');}
 if(cmd==='whitelist'){const sub=(a[0]||'list').toLowerCase();if(sub==='on'){r.wlOn=true;}else if(sub==='off'){r.wlOn=false;}else if(sub==='add'&&a[1]){const n=a[1].toLowerCase();if(!r.whitelist.includes(n))r.whitelist.push(n);}else if(sub==='remove'&&a[1]){r.whitelist=r.whitelist.filter(x=>x!==a[1].toLowerCase());}r.dirty=true;return say('белый список '+(r.wlOn?'включён':'выключен')+': '+(r.whitelist.join(', ')||'пусто'));}
 if(cmd==='blacklist'){const sub=(a[0]||'list').toLowerCase();if(sub==='add'&&a[1]){const n=a[1].toLowerCase();if(!r.blacklist.includes(n))r.blacklist.push(n);const t=findPlayer(r,n);if(t){tell(r,t.id,{t:'closed',reason:'Ты в чёрном списке'});t.ws.close(true);}}else if(sub==='remove'&&a[1]){r.blacklist=r.blacklist.filter(x=>x!==a[1].toLowerCase());}r.dirty=true;return say('чёрный список: '+(r.blacklist.join(', ')||'пусто'));}
 if(cmd==='unban'){const n=String(a[0]||'').toLowerCase();r.bans=r.bans.filter(x=>x!==n);r.dirty=true;return say(n+' разбанен');}
 if(cmd==='tp'){ // /tp x y z | /tp игрок | /tp кто куда
  if(a.length>=3&&!isNaN(+a[0])){const tgt=c||[...r.players.values()][0];if(tgt)tell(r,tgt.id,{t:'tp',x:+a[0],y:+a[1],z:+a[2]});return say('телепорт');}
  if(a.length===1){const t=findPlayer(r,a[0]);if(!t||!c)return say('игрок не найден');tell(r,c.id,{t:'tp',x:t.x,y:t.y,z:t.z});return say('к '+t.name);}
  if(a.length===2){const w=findPlayer(r,a[0]),t=findPlayer(r,a[1]);if(!w||!t)return say('игрок не найден');tell(r,w.id,{t:'tp',x:t.x,y:t.y,z:t.z});return say(w.name+' → '+t.name);}
  return say('/tp x y z | /tp игрок | /tp кто куда');}
 if(cmd==='give'){ // /give [игрок] предмет [n]
  let t=c,rest=a;if(a.length&&findPlayer(r,a[0])){t=findPlayer(r,a[0]);rest=a.slice(1);}if(!t)return say('кому?');const n=rest.length>1&&!isNaN(+rest[rest.length-1])?+rest.pop():1;tell(r,t.id,{t:'give',item:rest.join(' '),n});return say('выдано '+t.name+': '+rest.join(' ')+' ×'+n);}
 if(cmd==='time'){if(a[0]==='set'||a[0]==='add')a.shift();const v=a[0]==='day'||a[0]==='день'?40:a[0]==='night'||a[0]==='ночь'?260:a[0]==='noon'?100:a[0]==='midnight'?300:+a[0];if(isNaN(v))return say('/time day|night|секунды');r.time=v;bc(r,{t:'settime',time:v});return say('время: '+v);}
 if(cmd==='gamemode'||cmd==='gm'){ // /gamemode [игрок] creative|survival
  let t=c,mode=a[0];if(a.length>=2){t=findPlayer(r,a[0]);mode=a[1];}if(!t)return say('игрок не найден');mode=/^(creative|c|1)$/i.test(mode||'')?'creative':'survival';tell(r,t.id,{t:'gamemode',mode});return say(t.name+': режим '+mode);}
 if(cmd==='teleport'){return command(r,c,who,'/tp '+a.join(' '),out);}
 if(cmd==='xp'||cmd==='effect'||cmd==='difficulty'){return say('в loopcraft нет опыта/эффектов — команда принята для совместимости');}
 if(cmd==='summon'){const t=c||[...r.players.values()][0];if(!t)return say('никого нет');tell(r,t.id,{t:'spawn',mob:a[0]||'klyk',n:+a[1]||1});return say('summon '+(a[0]||'klyk'));}
 if(cmd==='setblock'){if(a.length<4)return say('/setblock x y z блок');const t=c||[...r.players.values()][0];if(!t)return say('никого нет');tell(r,t.id,{t:'setblock',x:+a[0],y:+a[1],z:+a[2],block:a.slice(3).join(' ')});return say('setblock');}
 if(cmd==='fill'){if(a.length<7)return say('/fill x1 y1 z1 x2 y2 z2 блок');const t=c||[...r.players.values()][0];if(!t)return say('никого нет');tell(r,t.id,{t:'fill',a:[+a[0],+a[1],+a[2]],b:[+a[3],+a[4],+a[5]],block:a.slice(6).join(' ')});return say('fill');}
 if(cmd==='setworldspawn'){if(!c)return say('только из игры');r.spawn={x:c.x,y:c.y,z:c.z};r.dirty=true;bc(r,{t:'setspawn',x:c.x,y:c.y,z:c.z});return say('точка появления мира: '+c.x.toFixed(0)+' '+c.y.toFixed(0)+' '+c.z.toFixed(0));}
 if(cmd==='heal'){let t=c;if(a[0])t=findPlayer(r,a[0]);if(!t)return say('игрок не найден');tell(r,t.id,{t:'heal'});return say(t.name+' вылечен');}
 if(cmd==='fly'){let t=c;if(a[0])t=findPlayer(r,a[0]);if(!t)return say('игрок не найден');tell(r,t.id,{t:'fly'});return say('полёт переключён: '+t.name);}
 if(cmd==='spawn'){const t=c||[...r.players.values()][0];if(!t)return say('никого нет');tell(r,t.id,{t:'spawn',mob:a[0]||'klyk',n:+a[1]||1});return say('спавн '+a[0]);}
 if(cmd==='setmax'){r.max=Math.max(1,Math.min(64,+a[0]||16));r.dirty=true;return say('лимит: '+r.max);}
 if(cmd==='public'){r.public=true;r.dirty=true;return say('сервер виден в списке');}
 if(cmd==='private'){r.public=false;r.dirty=true;return say('сервер скрыт из списка');}
 if(cmd==='name'){r.name=a.join(' ').slice(0,32)||r.code;r.dirty=true;bc(r,{t:'info',name:r.name});return say('имя сервера: '+r.name);}
 if(cmd==='plugins')return say('плагины: '+(r.plugins.join(', ')||'нет'));
 if(cmd==='reload'){bc(r,{t:'plugins',plugins:r.plugins});return say('плагины перезапущены');}
 say('неизвестная команда: '+cmd);
}

/* ================= tiny dependency-free WebSocket (RFC 6455) ================= */
class MiniWS{constructor(sock){this.sock=sock;this.readyState=1;this.buf=Buffer.alloc(0);this.onmessage=null;this.onclose=null;
 sock.on('data',d=>{this.buf=Buffer.concat([this.buf,d]);this.parse();});sock.on('close',()=>this.close(false));sock.on('error',()=>this.close(false));}
 parse(){for(;;){const b=this.buf;if(b.length<2)return;const fin=b[0]&0x80,op=b[0]&0x0f,masked=b[1]&0x80;let len=b[1]&0x7f,off=2;
  if(len===126){if(b.length<4)return;len=b.readUInt16BE(2);off=4;}else if(len===127){if(b.length<10)return;len=Number(b.readBigUInt64BE(2));off=10;}
  if(masked)off+=4;if(len>4e6){this.close(true);return;}if(b.length<off+len)return;let data=b.slice(off,off+len);
  if(masked){const m=b.slice(off-4,off);data=Buffer.from(data);for(let i=0;i<data.length;i++)data[i]^=m[i&3];}
  this.buf=b.slice(off+len);
  if(op===8){this.close(true);return;}if(op===9){this.frame(0x8a,data);continue;}if(op===1&&fin&&this.onmessage)this.onmessage(data.toString('utf8'));}}
 frame(op,data){const l=data.length;let h;if(l<126)h=Buffer.from([op,l]);else if(l<65536){h=Buffer.alloc(4);h[0]=op;h[1]=126;h.writeUInt16BE(l,2);}else{h=Buffer.alloc(10);h[0]=op;h[1]=127;h.writeBigUInt64BE(BigInt(l),2);}try{this.sock.write(Buffer.concat([h,data]));}catch(e){}}
 send(s){if(this.readyState===1)this.frame(0x81,Buffer.from(String(s),'utf8'));}
 close(send){if(this.readyState!==1)return;this.readyState=3;if(send)try{this.frame(0x88,Buffer.alloc(0));}catch(e){}try{this.sock.end();}catch(e){}if(this.onclose)this.onclose();}}
server.on('upgrade',(req,sock)=>{const p=url.parse(req.url).pathname;const key=req.headers['sec-websocket-key'];
 if(p!=='/ws'||!key){sock.end('HTTP/1.1 400 Bad Request\r\n\r\n');return;}
 const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
 sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');
 sock.setNoDelay(true);onConnection(new MiniWS(sock));});

/* ================= connections ================= */
function onConnection(ws){let r=null,id=nextId++,me=null;
 ws.onmessage=raw=>{let m;try{m=JSON.parse(raw);}catch(e){return;}if(!m||typeof m.t!=='string')return;
  if(m.t==='join'){const code=String(m.room||'').toLowerCase().trim();const name=String(m.name||'Player').slice(0,16)||'Player';const lname=name.toLowerCase();
   if(!/^[A-Za-z0-9_]{3,16}$/.test(name)){ws.send(JSON.stringify({t:'closed',reason:'Имя должно быть на английском: буквы, цифры, _ (3–16)'}));ws.close(true);return;}
   if(!CODE_RE.test(code)){ws.send(JSON.stringify({t:'closed',reason:'Неверный адрес сервера: латиница, цифры, - и _, 3–24 символа'}));ws.close(true);return;}
   const owner=m.token?sessions.get(String(m.token)):null;if(!owner){ws.send(JSON.stringify({t:'closed',reason:'Для игры на серверах нужен аккаунт'}));ws.close(true);return;}if(owner!==lname){ws.send(JSON.stringify({t:'closed',reason:'Имя не совпадает с аккаунтом'}));ws.close(true);return;}if(ACC[lname]&&owner!==lname){ws.send(JSON.stringify({t:'closed',reason:'Имя '+name+' зарегистрировано — войди в аккаунт'}));ws.close(true);return;}
   let rr=room(code);
   if(!rr){if(!m.create){ws.send(JSON.stringify({t:'closed',reason:'Сервера '+code+' не существует'}));ws.close(true);return;}
    createServer(code,{name:m.serverName,max:m.max,public:m.public,panelPw:m.panelPw,owner:name});rr=room(code);}
   if(rr.bans.includes(lname)||rr.blacklist.includes(lname)){ws.send(JSON.stringify({t:'closed',reason:'Тебе закрыт вход на этот сервер'}));ws.close(true);return;}
   if(rr.wlOn&&!rr.whitelist.includes(lname)&&!rr.ops.includes(lname)&&(rr.ownerName||'').toLowerCase()!==lname){ws.send(JSON.stringify({t:'closed',reason:'Сервер по белому списку — тебя в нём нет'}));ws.close(true);return;}
   if(rr.players.size>=rr.max){ws.send(JSON.stringify({t:'closed',reason:'Сервер полон ('+rr.max+')'}));ws.close(true);return;}
   {const old=findPlayer(rr,name);if(old){ // тот же аккаунт входит снова — вытесняем старую сессию
    try{old.ws.send(JSON.stringify({t:'closed',reason:'Ты вошёл с другого окна'}));}catch(e){}rr.players.delete(old.id);if(rr.owner===old.id)rr.owner=null;try{old.ws.onclose=null;old.ws.close(true);}catch(e){}bc(rr,{t:'left',id:old.id});}}
   r=rr;me={id,ws,name,x:0,y:0,z:0,ry:0,skin:null};
   if(r.players.size===0)reloadProps(r);if(!r.ownerName){r.ownerName=name;r.dirty=true;}if((r.ownerName||'').toLowerCase()===lname)r.owner=id;
   r.players.set(id,me);log('['+r.code+'] '+name+' joined ('+r.players.size+')');
   ws.send(JSON.stringify({t:'welcome',id,owner:r.owner===id,op:isOp(r,me),seed:r.seed,name:r.name,edits:r.edits,mods:r.mods,pack:r.pack,plugins:r.plugins,time:r.time,horror:r.horror,core:r.core,motd:r.motd||'',weather:r.weather||'clear',spawn:r.spawn||null,players:[...r.players].filter(([i])=>i!==id).map(([i,c])=>({id:i,name:c.name,x:c.x,y:c.y,z:c.z,ry:c.ry,skin:c.skin}))}));
   bc(r,{t:'joined',id,name},id);return;}
  if(!r||!me)return;
  if(m.t==='pos'){me.x=+m.x||0;me.y=+m.y||0;me.z=+m.z||0;me.ry=+m.ry||0;if(m.skin!==undefined)me.skin=m.skin?String(m.skin).slice(0,200):null;bc(r,{t:'pos',id,x:me.x,y:me.y,z:me.z,ry:me.ry,name:me.name,skin:me.skin},id);}
  else if(m.t==='block'){const k=(m.x|0)+','+(m.y|0)+','+(m.z|0);r.edits[k]=m.v|0;r.dirty=true;bc(r,{t:'block',x:m.x|0,y:m.y|0,z:m.z|0,v:m.v|0},id);}
  else if(m.t==='chat'){const text=String(m.text||'').slice(0,200);if(text.startsWith('/')){command(r,me,me.name,text,l=>tell(r,id,{t:'console',text:l}));save(r);return;}bc(r,{t:'chat',id,name:me.name,text});}
  else if(m.t==='mods'){if(!isOp(r,me))return tell(r,id,{t:'console',text:'менять моды могут только операторы'});if(Array.isArray(m.mods)){r.mods=m.mods.map(String).slice(0,50);r.dirty=true;bc(r,{t:'mods',mods:r.mods});}}
  else if(m.t==='pack'){if(!isOp(r,me))return tell(r,id,{t:'console',text:'менять пак могут только операторы'});r.pack=m.pack?String(m.pack).slice(0,200):null;r.dirty=true;bc(r,{t:'pack',pack:r.pack});}
  else if(m.t==='plugins'){if(!isOp(r,me))return tell(r,id,{t:'console',text:'менять плагины могут только операторы'});if(Array.isArray(m.plugins)){r.plugins=m.plugins.map(String).slice(0,50);r.dirty=true;bc(r,{t:'plugins',plugins:r.plugins});}}
  else if(m.t==='settime'){if(!isOp(r,me))return;r.time=+m.time||0;bc(r,{t:'settime',time:r.time},id);}
  else if(m.t==='rtc'){const to=r.players.get(+m.to);if(to&&to.ws.readyState===1)to.ws.send(JSON.stringify({t:'rtc',from:id,data:m.data}));}
  else if(m.t==='event'){bc(r,{t:'event',id,name:m.name,data:m.data},id);}
  else if(m.t==='plugin'){ // plugin (runs on owner's client) asks the server to act
   if(r.owner!==id)return;if(m.cmd)command(r,me,'[plugin]',String(m.cmd),l=>tell(r,id,{t:'console',text:l}));}
 };
 ws.onclose=()=>{if(r&&me){r.players.delete(id);log('['+r.code+'] '+me.name+' left');
   if(r.owner===id){r.owner=null;bc(r,{t:'chat',name:'[сервер]',text:'Создатель вышел, сервер продолжает работать.'});}
   bc(r,{t:'left',id});save(r);}};
}
for(const c of allServerCodes())room(c);
server.listen(PORT,'0.0.0.0',()=>{log('loopcraft server on port '+PORT+' (all interfaces)');if(ADMIN.password)log('hosting admin login enabled (data/admin.json)');});
