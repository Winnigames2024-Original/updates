// loopcraft server — created by Winnigames2024
// No dependencies. Serves the game, uploads (mods / packs / skins / lua plugins), worlds ("servers") over WebSocket,
// operator commands, admin web console.  Run: node server.js   (port 3000; nginx proxies to it)
const http=require('http'),fs=require('fs'),path=require('path'),url=require('url'),crypto=require('crypto'),zlib=require('zlib');
const ROOT=__dirname,PORT=process.env.PORT||3000;
const UP=path.join(ROOT,'uploads');for(const d of['mods','packs','skins','plugins'])fs.mkdirSync(path.join(UP,d),{recursive:true});
const DATA=path.join(ROOT,'data');fs.mkdirSync(DATA,{recursive:true});
// admin password: data/admin.json {"password":"..."}; created with a random password on first run (printed to log)
const ADMINF=path.join(DATA,'admin.json');let ADMIN={password:''};
try{ADMIN=JSON.parse(fs.readFileSync(ADMINF));}catch(e){ADMIN={password:''};fs.writeFileSync(ADMINF,JSON.stringify(ADMIN,null,1));}
// внутренний ключ для панели (admin.php на этом же сервере) — не пароль, живёт в data/internal.key
const IKF=path.join(DATA,'internal.key');let IKEY='';try{IKEY=fs.readFileSync(IKF,'utf8').trim();}catch(e){IKEY=crypto.randomBytes(16).toString('hex');fs.writeFileSync(IKF,IKEY);}
const LOG=[];function log(s){const line=new Date().toISOString().slice(11,19)+' '+s;LOG.push(line);if(LOG.length>500)LOG.shift();console.log(line);}
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.zip':'application/zip','.txt':'text/plain; charset=utf-8','.md':'text/plain; charset=utf-8','.lua':'text/plain; charset=utf-8','.ico':'image/x-icon','.mp3':'audio/mpeg','.ogg':'audio/ogg','.wav':'audio/wav'};
const safe=n=>String(n||'').replace(/[^a-zA-Z0-9а-яА-ЯёЁ_.\-]/g,'_').replace(/\.{2,}/g,'.').slice(0,80)||'file';
const CORS={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'*','Access-Control-Allow-Methods':'GET,POST,DELETE,OPTIONS'};
function send(res,code,body,type){res.writeHead(code,Object.assign({'Content-Type':type||'application/json'},CORS));res.end(body);}
function listDir(dir){try{return fs.readdirSync(path.join(UP,dir)).filter(f=>!f.startsWith('.')).map(f=>{const st=fs.statSync(path.join(UP,dir,f));return{name:f,size:st.size,dir:st.isDirectory()};});}catch(e){return[];}}
function walk(dir,base){let out=[];for(const f of fs.readdirSync(dir)){const p=path.join(dir,f);const st=fs.statSync(p);if(st.isDirectory())out=out.concat(walk(p,base));else out.push(path.relative(base,p).split(path.sep).join('/'));}return out;}
function body(req,cb){const chunks=[];let size=0;req.on('data',c=>{size+=c.length;if(size>60e6)req.destroy();chunks.push(c);});req.on('end',()=>cb(Buffer.concat(chunks)));}
/* ================= accounts & friends ================= */
const ACCF=path.join(ROOT,'users.json');let ACC={};try{ACC=JSON.parse(fs.readFileSync(ACCF));}catch(e){try{ACC=JSON.parse(fs.readFileSync(path.join(DATA,'accounts.json')));}catch(e2){}}
function saveAcc(){fs.writeFile(ACCF,JSON.stringify(ACC,null,1),()=>{});}
const WORLDS=path.join(ROOT,'worlds');fs.mkdirSync(WORLDS,{recursive:true});
// секретный ключ обхода AuthMe: ссылка  /minecraft/#<ключ>:noauth:<адрес-сервера>  (ключ в data/noauth.key, можно поменять)
const NOAUTHF=path.join(DATA,'noauth.key');let NOAUTH='';try{NOAUTH=fs.readFileSync(NOAUTHF,'utf8').trim();}catch(e){NOAUTH='1213122';fs.writeFileSync(NOAUTHF,NOAUTH);}
const SESSF=path.join(DATA,'sessions.json');const sessions=new Map(); // token -> name(lower); хранится в data/sessions.json, чтобы входы переживали перезапуск
try{const j=JSON.parse(fs.readFileSync(SESSF));const now=Date.now();for(const k in j){const v=j[k];if(v&&v.n&&(!v.at||now-v.at<30*864e5))sessions.set(k,v.n);}}catch(e){}
let sessT=null;function saveSess(){clearTimeout(sessT);sessT=setTimeout(()=>{const o={};for(const [k,n] of sessions)o[k]={n,at:Date.now()};try{fs.writeFileSync(SESSF,JSON.stringify(o));}catch(e){}},500);}
const _set=sessions.set.bind(sessions),_del=sessions.delete.bind(sessions);sessions.set=(k,v)=>{_set(k,v);saveSess();return sessions;};sessions.delete=k=>{const r=_del(k);saveSess();return r;};
const hashPw=(p,salt)=>crypto.createHash('sha256').update(salt+':'+p).digest('hex');
function accountByToken(req){return sessions.get(String(req.headers['x-token']||''))||null;}
function whereIs(name){for(const r of rooms.values())if(findPlayer(r,name))return {code:r.code,name:r.name};return null;}
/* ---- zip (без зависимостей): читаем central directory, распаковываем deflate/stored ---- */
function unzip(buf){const out=[];let e=buf.length-22;while(e>=0&&buf.readUInt32LE(e)!==0x06054b50)e--;if(e<0)throw new Error('не zip');
 const n=buf.readUInt16LE(e+10);let off=buf.readUInt32LE(e+16);
 for(let i=0;i<n;i++){if(buf.readUInt32LE(off)!==0x02014b50)break;const method=buf.readUInt16LE(off+10),csize=buf.readUInt32LE(off+20),usize=buf.readUInt32LE(off+24),nl=buf.readUInt16LE(off+28),el=buf.readUInt16LE(off+30),cl=buf.readUInt16LE(off+32),lho=buf.readUInt32LE(off+42);
  const name=buf.slice(off+46,off+46+nl).toString('utf8');off+=46+nl+el+cl;
  const lnl=buf.readUInt16LE(lho+26),lel=buf.readUInt16LE(lho+28);const data=buf.slice(lho+30+lnl+lel,lho+30+lnl+lel+csize);
  if(name.endsWith('/'))continue;let content;if(method===0)content=data;else if(method===8)content=zlib.inflateRawSync(data);else continue;
  if(usize>20*1024*1024)continue;out.push({name,data:content});}
 return out;}
const PLUG_SLUG=n=>String(n||'').toLowerCase().replace(/[^a-z0-9_\-]/g,'_').replace(/_+/g,'_').replace(/^_|_$/g,'').slice(0,32)||'plugin';
function installPluginZip(buf,base,author){ // архив: _data.json {name,description}, data/*.lua, data/files/*
 const files=unzip(buf);let prefix='';const dj=files.find(f=>/(^|\/)_data\.json$/.test(f.name));if(!dj)throw new Error('в архиве нет _data.json');
 prefix=dj.name.slice(0,dj.name.length-'_data.json'.length);let meta={};try{meta=JSON.parse(dj.data.toString('utf8'));}catch(e){throw new Error('_data.json — не JSON');}
 if(!meta.name)throw new Error('в _data.json нет name');const slug=PLUG_SLUG(meta.name);const dir=path.join(base,slug);
 const lua=files.filter(f=>f.name.startsWith(prefix+'data/')&&/\.lua$/i.test(f.name)&&!f.name.startsWith(prefix+'data/files/'));if(!lua.length)throw new Error('в data/ нет .lua файлов');
 fs.rmSync(dir,{recursive:true,force:true});fs.mkdirSync(path.join(dir,'data','files'),{recursive:true});let n=0;
 for(const f of files){if(!f.name.startsWith(prefix))continue;const rel=f.name.slice(prefix.length);if(!(rel==='_data.json'||rel.startsWith('data/')))continue;if(rel.includes('..'))continue;const dest=path.join(dir,rel);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,f.data);n++;}
 meta={name:String(meta.name).slice(0,40),description:String(meta.description||'').slice(0,300),version:String(meta.version||'1.0').slice(0,16),author:author||String(meta.author||'').slice(0,16),lua:lua.map(f=>f.name.slice(prefix.length+5)).sort(),installed:Date.now()};
 fs.writeFileSync(path.join(dir,'_data.json'),JSON.stringify(meta,null,1));return {slug,meta,files:n};}
function pluginMeta(dir){try{return JSON.parse(fs.readFileSync(path.join(dir,'_data.json'),'utf8'));}catch(e){return null;}}
function accountApi(p,req,res,u){
 if(p==='/api/account/register'&&req.method==='POST'){body(req,b=>{let j={};try{j=JSON.parse(b);}catch(e){}const name=String(j.name||'').trim().slice(0,16);const key=name.toLowerCase();
  if(!/^[A-Za-z0-9_]{3,16}$/.test(name))return send(res,400,'{"error":"Имя: только английские буквы, цифры и _ (3–16 символов)"}');if(String(j.password||'').length<4)return send(res,400,'{"error":"Пароль от 4 символов"}');
  if(ACC[key])return send(res,409,'{"error":"Имя уже занято"}');const salt=crypto.randomBytes(8).toString('hex');ACC[key]={name,salt,hash:hashPw(j.password,salt),friends:[],created:Date.now()};saveAcc();
  const tok=crypto.randomBytes(16).toString('hex');sessions.set(tok,key);log('account registered: '+name);send(res,200,JSON.stringify({ok:true,token:tok,name}));});return true;}
 if(p==='/api/account/login'&&req.method==='POST'){body(req,b=>{let j={};try{j=JSON.parse(b);}catch(e){}const key=String(j.name||'').trim().toLowerCase();const a=ACC[key];
  if(!a||a.hash!==hashPw(String(j.password||''),a.salt))return send(res,401,'{"error":"Неверное имя или пароль"}');if(a.banned)return send(res,403,JSON.stringify({error:'Аккаунт забанен'+(a.banReason?': '+a.banReason:''),banned:true,reason:a.banReason||'',name:a.name,at:a.bannedAt||0}));const tok=crypto.randomBytes(16).toString('hex');sessions.set(tok,key);send(res,200,JSON.stringify({ok:true,token:tok,name:a.name}));});return true;}
 const key=accountByToken(req);
 if(p==='/api/account/me'){if(!key)return send(res,401,'{"error":"не вошёл"}'),true;const a=ACC[key];if(a.banned)return send(res,403,JSON.stringify({error:'Аккаунт забанен',banned:true,reason:a.banReason||'',name:a.name,at:a.bannedAt||0})),true;return send(res,200,JSON.stringify({name:a.name,super:isSuper(key),warns:a.warns||[],friends:a.friends.map(f=>({name:(ACC[f]||{}).name||f,online:whereIs(f)})),requests:(a.requests||[]).map(f=>(ACC[f]||{}).name||f)})),true;}
 if(p==='/api/account/friend'&&req.method==='POST'){if(!key)return send(res,401,'{"error":"не вошёл"}'),true;body(req,b=>{let j={};try{j=JSON.parse(b);}catch(e){}const f=String(j.name||'').trim().toLowerCase();const act=j.action||'add';const a=ACC[key];
  if(act==='remove'){a.friends=a.friends.filter(x=>x!==f);if(ACC[f])ACC[f].friends=ACC[f].friends.filter(x=>x!==key);saveAcc();return send(res,200,'{"ok":true}');}
  if(!ACC[f]||f===key)return send(res,404,'{"error":"Игрок с таким именем не зарегистрирован"}');
  if(act==='accept'){a.requests=(a.requests||[]).filter(x=>x!==f);if(!a.friends.includes(f))a.friends.push(f);if(!ACC[f].friends.includes(key))ACC[f].friends.push(key);saveAcc();return send(res,200,'{"ok":true}');}
  if(a.friends.includes(f))return send(res,200,'{"ok":true,"already":true}');const rq=ACC[f].requests=(ACC[f].requests||[]);if(!rq.includes(key))rq.push(key);saveAcc();send(res,200,'{"ok":true,"sent":true}');});return true;}
 if(p==='/api/account/exists'){const key2=String(u.query.name||'').trim().toLowerCase();return send(res,200,JSON.stringify({exists:!!ACC[key2]})),true;}
 return false;}
const isAdmin=req=>(ADMIN.password&&req.headers['x-admin']===ADMIN.password)||req.headers['x-internal']===IKEY||isSuper(accountByToken(req)||'');

const server=http.createServer((req,res)=>{
 const u=url.parse(req.url,true);const p=decodeURIComponent(u.pathname);
 if(req.method==='OPTIONS')return send(res,204,'','text/plain');
 if(p.startsWith('/api/account/')&&accountApi(p,req,res,u))return;
 if(p==='/api/list'){const kind=safe(u.query.kind||'mods');const srv=String(u.query.server||'').toLowerCase();let base=path.join(UP,kind);
  if(srv&&CODE_RE.test(srv)&&fs.existsSync(roomDir(srv)))base=path.join(roomDir(srv),kind==='packs'?'resourcepacks':kind);
  let items=[];try{items=fs.readdirSync(base).filter(f=>!f.startsWith('.')).map(f=>{const st=fs.statSync(path.join(base,f));const it={name:f,size:st.size,dir:st.isDirectory()};if(it.dir){it.files=walk(path.join(base,f),base);if(kind==='plugins')it.meta=pluginMeta(path.join(base,f));}return it;});}catch(e){}
  if(kind==='plugins'&&srv){try{for(const f of fs.readdirSync(path.join(UP,'plugins'))){const m=pluginMeta(path.join(UP,'plugins',f));if(m)items.push({name:'pkg:'+f,dir:true,meta:m,global:true});}}catch(e){}}
  return send(res,200,JSON.stringify(items));}
 if(p==='/api/plugins/catalog'){const out=[];try{for(const f of fs.readdirSync(path.join(UP,'plugins'))){const m=pluginMeta(path.join(UP,'plugins',f));if(m)out.push(Object.assign({slug:f},m));}}catch(e){}return send(res,200,JSON.stringify(out));}
 if(p==='/api/upload'&&req.method==='POST'){
  const kind=safe(req.headers['x-kind']||'mods');if(!['mods','packs','skins','plugins'].includes(kind))return send(res,400,'{"error":"kind"}');
  const rel=String(req.headers['x-name']||'file').split('/').map(safe).join('/');
  const srv=String(req.headers['x-server']||'').toLowerCase();let base=path.join(UP,kind),urlBase='/uploads/'+kind+'/';
  if(srv&&CODE_RE.test(srv)&&fs.existsSync(roomDir(srv))){const sub=kind==='packs'?'resourcepacks':kind;base=path.join(roomDir(srv),sub);urlBase='/servers/'+srv+'/'+sub+'/';}
  const dest=path.join(base,rel);if(!dest.startsWith(base))return send(res,400,'{"error":"path"}');
  fs.mkdirSync(path.dirname(dest),{recursive:true});
  if(kind==='plugins'&&/\.zip$/i.test(rel)){body(req,b=>{try{let author=accountByToken(req)||'';if(!author&&req.headers['x-panel']){const pt=panelTokens.get(String(req.headers['x-panel']));if(pt&&pt.by&&pt.by!=='password')author=String(pt.by).toLowerCase();}const r=installPluginZip(b,base,author?(ACC[author]||{}).name||author:'');log('plugin package '+r.slug+' ('+r.files+' files) by '+(author||'?'));send(res,200,JSON.stringify({ok:true,package:r.slug,meta:r.meta}));}catch(e){send(res,400,JSON.stringify({error:'плагин: '+e.message}));}});return;}
  body(req,b=>{fs.writeFileSync(dest,b);log('upload '+urlBase+rel+' ('+b.length+' b)');send(res,200,JSON.stringify({ok:true,url:urlBase+rel}));});return;}
 if(p==='/api/world'){ // worlds/<имя пользователя>/<имя мира>_<uuid>/world.json
  const acc=accountByToken(req);const user=acc?ACC[acc].name:('guest_'+safe(u.query.tok||'').slice(0,16));if(!acc&&(!u.query.tok||String(u.query.tok).length<8))return send(res,400,'{"error":"tok"}');
  const udir=path.join(WORLDS,safe(user));const name=String(u.query.name||'world').replace(/[^\wа-яА-ЯёЁ\- ]/gu,'').trim().slice(0,24)||'world';
  const findDir=()=>{try{for(const d of fs.readdirSync(udir)){const meta=JSON.parse(fs.readFileSync(path.join(udir,d,'meta.json')));if(meta.name===name)return path.join(udir,d);}}catch(e){}return null;};
  if(u.query.list){const out=[];try{for(const d of fs.readdirSync(udir)){try{const meta=JSON.parse(fs.readFileSync(path.join(udir,d,'meta.json')));const st=fs.statSync(path.join(udir,d,'world.json'));out.push({name:meta.name,uuid:meta.uuid,folder:d,updated:st.mtimeMs,size:st.size,created:meta.created});}catch(e){}}}catch(e){}return send(res,200,JSON.stringify(out));}
  if(req.method==='POST'){let dir=findDir();if(!dir){const uuid=crypto.randomUUID();dir=path.join(udir,safe(name).replace(/ /g,'_')+'_'+uuid);fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'meta.json'),JSON.stringify({name,uuid,owner:user,created:new Date().toISOString()}));}
   body(req,b=>{fs.writeFileSync(path.join(dir,'world.json'),b);send(res,200,JSON.stringify({ok:true,folder:path.basename(dir)}));});return;}
  const dir=findDir();
  if(req.method==='DELETE'){if(dir){for(const f of fs.readdirSync(dir))fs.unlinkSync(path.join(dir,f));fs.rmdirSync(dir);}return send(res,200,'{"ok":true}');}
  if(!dir)return send(res,404,'{"error":"nofile"}');fs.readFile(path.join(dir,'world.json'),(e,d)=>{if(e)return send(res,404,'{"error":"nofile"}');send(res,200,d);});return;}
 if(p==='/api/check'){const code=safe(u.query.room||'').toLowerCase();const name=String(u.query.name||'').slice(0,16).toLowerCase();const sname=String(u.query.server||'').slice(0,32).toLowerCase();
  const r=room(code);const out={valid:CODE_RE.test(code),roomExists:!!r,online:!!r&&r.players.size>0,players:r?r.players.size:0,max:r?r.max:16,nameTaken:!!(r&&findPlayer(r,name)),banned:!!(r&&(r.bans.includes(name)||r.blacklist.includes(name))),whitelisted:!r||!r.wlOn||r.whitelist.includes(name)||r.ops.includes(name),serverNameTaken:!!sname&&[...rooms.values()].some(x=>x.name.toLowerCase()===sname)};
  return send(res,200,JSON.stringify(out));}
 // ---- per-server panel login (password set by the creator when the server was created) ----
 if(p==='/api/myservers'){const acc=accountByToken(req);if(!acc)return send(res,401,'{"error":"не вошёл"}');for(const c of allServerCodes())room(c);
  const mine=[...rooms.values()].filter(r=>isSuper(acc)||(r.ownerName||'').toLowerCase()===acc||r.ops.includes(acc)).map(r=>({code:r.code,name:r.name,online:r.players.size>0,players:r.players.size,owner:r.ownerName,super:isSuper(acc)}));
  return send(res,200,JSON.stringify(mine));}
 if(p==='/api/server/login'&&req.method==='POST'){body(req,b=>{let j={};try{j=JSON.parse(b);}catch(e){}const m=/([a-z0-9][a-z0-9_\-]{2,23})\s*$/i.exec(String(j.room||''));const r=m?room(m[1].toLowerCase()):null;
  if(!r)return send(res,404,'{"error":"сервер не найден"}');
  const acc=j.token?sessions.get(String(j.token)):null;const byAcc=acc&&(isSuper(acc)||(r.ownerName||'').toLowerCase()===acc);
  if(!byAcc){if(!r.panelHash)return send(res,404,'{"error":"у сервера нет пароля панели"}');if(crypto.createHash('sha256').update(String(j.password||'')).digest('hex')!==r.panelHash)return send(res,401,'{"error":"неверный пароль"}');}
  const tok=crypto.randomBytes(16).toString('hex');panelTokens.set(tok,{code:r.code,exp:Date.now()+10*60*1000,by:acc||'password'});log('['+r.code+'] panel login by '+(acc||'password'));send(res,200,JSON.stringify({ok:true,token:tok,code:r.code,name:r.name,expires:10*60}));});return;}
 if(p.startsWith('/api/server/')){const tk=String(req.headers['x-panel']||u.query.uuid||'');const pt=panelTokens.get(tk);if(pt&&pt.exp<Date.now())panelTokens.delete(tk);const r=pt&&pt.exp>=Date.now()?rooms.get(pt.code):null;if(!r)return send(res,401,'{"error":"token"}');pt.exp=Date.now()+10*60*1000;
  if(p==='/api/server/reload'){reloadProps(r);bc(r,{t:'mods',mods:r.mods});bc(r,{t:'pack',pack:r.pack});bc(r,{t:'plugins',plugins:r.plugins});bc(r,{t:'horror',horror:r.horror});bc(r,{t:'core',core:r.core});return send(res,200,'{"ok":true}');}
  if(p==='/api/server/info')return send(res,200,JSON.stringify({code:r.code,name:r.name,players:[...r.players.values()].map(c=>c.name),ops:r.ops,bans:r.bans,mods:r.mods,pack:r.pack,plugins:r.plugins,max:r.max,public:r.public,log:LOG.filter(l=>l.includes('['+r.code+']')).slice(-100)}));
  if(p==='/api/server/cmd'&&req.method==='POST'){body(req,b=>{let j={};try{j=JSON.parse(b);}catch(e){}const out=[];command(r,null,'[panel]',String(j.text||''),l=>out.push(l));send(res,200,JSON.stringify(out));});return;}
  return send(res,404,'{"error":"api"}');}
 if(p==='/api/rooms'){for(const c of allServerCodes())room(c);return send(res,200,JSON.stringify([...rooms.values()].filter(r=>r.public!==false).map(r=>({code:r.code,name:r.name,players:r.players.size,max:r.max,online:r.players.size>0,owner:r.ownerName,mods:r.mods.length,pack:!!r.pack,plugins:r.plugins.length,wl:r.wlOn}))));}
 // ---- admin console API ----
 if(p.startsWith('/api/admin/')){if(!isAdmin(req))return send(res,401,'{"error":"password"}');
  if(p==='/api/admin/log')return send(res,200,JSON.stringify(LOG.slice(-200)));
  if(p==='/api/admin/users')return send(res,200,JSON.stringify(Object.keys(ACC).map(k=>{const a=ACC[k];return {name:a.name,admin:!!a.admin||SUPER.includes(k),builtin:SUPER.includes(k),banned:!!a.banned,banReason:a.banReason||'',warns:a.warns||[],friends:(a.friends||[]).length,created:a.created||0,online:whereIs(k)};})));
  if(p==='/api/admin/user'&&req.method==='POST'){body(req,b=>{let j={};try{j=JSON.parse(b);}catch(e){}const k=String(j.name||'').toLowerCase();const a=ACC[k];if(!a)return send(res,404,'{"error":"нет такого аккаунта"}');const act=String(j.action||'');const v=String(j.value||'').slice(0,200);
   const kickAll=(reason,keepSess)=>{for(const r of rooms.values()){const t=findPlayer(r,k);if(t){tell(r,t.id,{t:'closed',reason});t.ws.close(true);}}if(!keepSess)for(const [tok,n] of [...sessions])if(n===k)sessions.delete(tok);};
   if(act==='setpw'){if(v.length<4)return send(res,400,'{"error":"пароль от 4 символов"}');a.salt=crypto.randomBytes(8).toString('hex');a.hash=hashPw(v,a.salt);for(const [tok,n] of [...sessions])if(n===k)sessions.delete(tok);}
   else if(act==='warn'){a.warns=a.warns||[];if(a.warns.length>=3)return send(res,400,'{"error":"уже 3 предупреждения — можно банить"}');a.warns.push({text:v||'нарушение правил',at:Date.now()});for(const r of rooms.values()){const t=findPlayer(r,k);if(t)tell(r,t.id,{t:'broadcast',text:'ПРЕДУПРЕЖДЕНИЕ '+a.warns.length+'/3: '+(v||'нарушение правил')});}}
   else if(act==='unwarn'){a.warns=(a.warns||[]).slice(0,-1);}
   else if(act==='clearwarns'){a.warns=[];}
   else if(act==='ban'){if(SUPER.includes(k))return send(res,400,'{"error":"нельзя забанить главного администратора"}');a.banned=true;a.banReason=v||'';a.bannedAt=Date.now();for(const r of rooms.values()){const t=findPlayer(r,k);if(t)tell(r,t.id,{t:'banned',reason:v||''});}kickAll('Аккаунт забанен'+(v?': '+v:''),true);}
   else if(act==='unban'){a.banned=false;a.banReason='';}
   else if(act==='admin'){a.admin=true;}
   else if(act==='unadmin'){if(SUPER.includes(k))return send(res,400,'{"error":"это встроенный главный администратор"}');a.admin=false;}
   else if(act==='delete'){if(SUPER.includes(k))return send(res,400,'{"error":"нельзя"}');kickAll('Аккаунт удалён');delete ACC[k];}
   else return send(res,400,'{"error":"action"}');
   saveAcc();log('admin: '+act+' '+k+(v?' '+v:''));send(res,200,'{"ok":true}');});return;}
  if(p==='/api/admin/rooms'){for(const c of allServerCodes())room(c);return send(res,200,JSON.stringify([...rooms.values()].map(r=>({code:r.code,name:r.name,players:[...r.players.values()].map(c=>c.name),ops:r.ops,bans:r.bans,mods:r.mods,pack:r.pack,plugins:r.plugins,max:r.max,public:r.public,online:r.players.size>0}))));}
  if(p==='/api/admin/cmd'&&req.method==='POST'){body(req,b=>{let j={};try{j=JSON.parse(b);}catch(e){}const r=room(String(j.room||'').toLowerCase());if(!r)return send(res,404,'{"error":"room"}');const out=[];command(r,null,'[admin]',String(j.text||''),l=>out.push(l));save(r);send(res,200,JSON.stringify(out));});return;}
  return send(res,404,'{"error":"api"}');}
 // static
 if(/\/servers\/[^/]+\/(server\.properties|world\.json)$/.test(p)||p==='/users.json'||p.startsWith('/worlds/'))return send(res,403,'forbidden','text/plain');
 let fp=path.join(ROOT,p==='/'?'index.php':p);if(!fp.startsWith(ROOT)||fp.startsWith(DATA))return send(res,403,'forbidden','text/plain');
 fs.stat(fp,(e,st)=>{if(e||!st.isFile())return send(res,404,'not found','text/plain');res.writeHead(200,Object.assign({'Content-Type':MIME[path.extname(fp).toLowerCase()]||'application/octet-stream','Cache-Control':'no-cache'},CORS));fs.createReadStream(fp).pipe(res);});
});

/* ================= rooms ("servers") ================= */
const rooms=new Map();let nextId=1;const panelTokens=new Map();
const SERVERS=path.join(ROOT,'servers');fs.mkdirSync(SERVERS,{recursive:true});
const CODE_RE=/^[a-z0-9][a-z0-9_\-]{2,23}$/;
const roomDir=code=>path.join(SERVERS,code);
const LISTS=['ops','bans','whitelist','blacklist','mods','plugins'];
function propsRead(fp){const o={};try{for(const line of fs.readFileSync(fp,'utf8').split(/\r?\n/)){const t=line.trim();if(!t||t[0]==='#')continue;const i=t.indexOf('=');if(i<0)continue;o[t.slice(0,i).trim()]=t.slice(i+1).trim();}}catch(e){}return o;}
function propsWrite(fp,o){const lines=['# loopcraft server.properties — редактируется в панели или вручную; списки через запятую','# Winnigames2024'];for(const k of Object.keys(o))lines.push(k+'='+o[k]);fs.writeFileSync(fp,lines.join('\n')+'\n');}
const list=v=>String(v||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
const CORE_LUA=`-- core — встроенный плагин loopcraft (выполняется самим сервером, этот файл — описание).
-- Включить/выключить: server.properties → core=true|false, или /plugins core on|off, или в панели.
-- Команды (op): /stop /start /restart /op /deop /horror enable|disable
--   /run by <игрок> <команда> | /run in <сервер> <команда> | /run from <игрок> <текст>
--   /broadcast <текст> /motd <текст> /weather clear|rain|storm /clearmobs /whitelist on|off|add|remove|list /blacklist add|remove|list
`;
function createServer(code,opts){const d=roomDir(code);if(fs.existsSync(d))return false;for(const sub of['plugins','mods','resourcepacks'])fs.mkdirSync(path.join(d,sub),{recursive:true});
 fs.writeFileSync(path.join(d,'plugins','core.lua'),CORE_LUA);
 propsWrite(path.join(d,'server.properties'),{name:String(opts.name||code).slice(0,32),motd:'Добро пожаловать на '+String(opts.name||code).slice(0,32),'max-players':String(Math.max(1,Math.min(64,+opts.max||16))),public:String(opts.public!==false),horror:'false',core:'true',seed:String(opts.seed||Math.floor(Math.random()*899999+1000)),'whitelist-enabled':'false',whitelist:'',ops:String(opts.owner||'').toLowerCase(),blacklist:'',banned:'',pack:'',mods:'',plugins:'',time:'',weather:'clear',owner:String(opts.owner||''),'panel-password-hash':opts.panelPw?crypto.createHash('sha256').update(String(opts.panelPw)).digest('hex'):'','created':new Date().toISOString()});
 fs.writeFileSync(path.join(d,'world.json'),'{}');log('server created: '+code);return true;}
function room(code){let r=rooms.get(code);if(r){return r;}const d=roomDir(code);if(!fs.existsSync(path.join(d,'server.properties')))return null;
 r={code,name:code,seed:1,edits:{},players:new Map(),mods:[],pack:null,plugins:[],ops:[],bans:[],whitelist:[],blacklist:[],wlOn:false,max:16,public:true,time:null,dirty:false,owner:null,ownerName:null,panelHash:null,horror:false,core:true,motd:'',weather:'clear',regions:[],homes:{},pvp:true,lastpos:{},chests:{},auth:{}};
 reloadProps(r);try{r.edits=JSON.parse(fs.readFileSync(path.join(d,'world.json')))||{};}catch(e){}try{r.regions=JSON.parse(fs.readFileSync(path.join(d,'regions.json')))||[];}catch(e){}try{r.homes=JSON.parse(fs.readFileSync(path.join(d,'homes.json')))||{};}catch(e){}try{r.lastpos=JSON.parse(fs.readFileSync(path.join(d,'lastpos.json')))||{};}catch(e){}try{r.chests=JSON.parse(fs.readFileSync(path.join(d,'chests.json')))||{};}catch(e){}try{r.auth=JSON.parse(fs.readFileSync(path.join(d,'authme.json')))||{};}catch(e){}rooms.set(code,r);return r;}
function reloadProps(r){const p=propsRead(path.join(roomDir(r.code),'server.properties'));r.props=p;
 r.name=p.name||r.code;r.motd=p.motd||'';r.max=Math.max(1,Math.min(64,+p['max-players']||16));r.public=p.public!=='false';r.horror=p.horror==='true';r.core=p.core!=='false';r.authme=p.authme==='true';r.seed=+p.seed||1;
 r.wlOn=p['whitelist-enabled']==='true';r.whitelist=list(p.whitelist);r.ops=list(p.ops);r.blacklist=list(p.blacklist);r.bans=list(p.banned);r.pack=p.pack||null;r.mods=list(p.mods);r.plugins=list(p.plugins);
 r.time=p.time===''||p.time==null?null:+p.time;try{r.spawn=p.spawn?JSON.parse(p.spawn):null;}catch(e){r.spawn=null;}r.weather=p.weather||'clear';r.pvp=p.pvp!=='false';r.rules=p.rules||'';r.ownerName=p.owner||null;r.panelHash=p['panel-password-hash']||null;}
function save(r){if(!r.dirty)return;r.dirty=false;const p=r.props||{};Object.assign(p,{name:r.name,motd:r.motd||'','max-players':String(r.max),public:String(r.public),horror:String(r.horror),core:String(r.core),authme:String(!!r.authme),seed:String(r.seed),'whitelist-enabled':String(r.wlOn),whitelist:r.whitelist.join(','),ops:r.ops.join(','),blacklist:r.blacklist.join(','),banned:r.bans.join(','),pack:r.pack||'',mods:r.mods.join(','),plugins:r.plugins.join(','),time:r.time==null?'':String(r.time),spawn:r.spawn?JSON.stringify(r.spawn):'',weather:r.weather||'clear',pvp:String(r.pvp),rules:r.rules||'',owner:r.ownerName||'','panel-password-hash':r.panelHash||''});
 try{propsWrite(path.join(roomDir(r.code),'server.properties'),p);fs.writeFileSync(path.join(roomDir(r.code),'world.json'),JSON.stringify(r.edits));fs.writeFileSync(path.join(roomDir(r.code),'regions.json'),JSON.stringify(r.regions||[]));fs.writeFileSync(path.join(roomDir(r.code),'homes.json'),JSON.stringify(r.homes||{}));fs.writeFileSync(path.join(roomDir(r.code),'lastpos.json'),JSON.stringify(r.lastpos||{}));fs.writeFileSync(path.join(roomDir(r.code),'chests.json'),JSON.stringify(r.chests||{}));fs.writeFileSync(path.join(roomDir(r.code),'authme.json'),JSON.stringify(r.auth||{}));}catch(e){log('save error '+r.code+': '+e.message);}}
function allServerCodes(){try{return fs.readdirSync(SERVERS).filter(f=>fs.existsSync(path.join(SERVERS,f,'server.properties')));}catch(e){return[];}}
setInterval(()=>rooms.forEach(save),5000);
function bc(r,msg,except){const s=JSON.stringify(msg);for(const [id,c] of r.players){if(id!==except&&c.ws.readyState===1)c.ws.send(s);}}
function tell(r,id,msg){const c=r.players.get(id);if(c&&c.ws.readyState===1)c.ws.send(JSON.stringify(msg));}
const SUPER=['minecraft','winnigames2024','loopcraft'];const isSuper=n=>{n=String(n||'').toLowerCase();return SUPER.includes(n)||!!(ACC[n]&&ACC[n].admin);};
const isOp=(r,c)=>!!c&&(r.owner===c.id||r.ops.includes(c.name.toLowerCase())||isSuper(c.name));
/* ---- clans (global, data/clans.json) ---- */
const CLANS_FILE=path.join(DATA,'clans.json');let clans={};try{clans=JSON.parse(fs.readFileSync(CLANS_FILE))||{};}catch(e){}
function saveClans(){try{fs.writeFileSync(CLANS_FILE,JSON.stringify(clans));}catch(e){}}
function clanOf(name){name=String(name||'').toLowerCase();for(const k in clans)if(clans[k].members.includes(name))return clans[k];return null;}
function clanMap(r){const o={};for(const [,c] of r.players){const cl=clanOf(c.name);if(cl)o[c.name]=cl.tag;}return o;}
function bcClans(r){bc(r,{t:'clans',map:clanMap(r)});}
/* ---- regions (private) ---- */
function regionAt(r,x,y,z){for(const g of r.regions)if(x>=g.x1&&x<=g.x2&&z>=g.z1&&z<=g.z2&&y>=g.y1&&y<=g.y2)return g;return null;}
function canBuild(r,c,x,y,z){const g=regionAt(r,x,y,z);if(!g)return true;if(isOp(r,c))return true;const n=c.name.toLowerCase();if(g.owner===n||g.members.includes(n))return true;const cl=clanOf(g.owner);if(cl&&cl.members.includes(n))return true;return false;}
function overlaps(a,b){return a.x1<=b.x2&&a.x2>=b.x1&&a.z1<=b.z2&&a.z2>=b.z1&&a.y1<=b.y2&&a.y2>=b.y1;}
function findPlayer(r,name){name=String(name||'').toLowerCase();for(const [id,c] of r.players)if(c.name.toLowerCase()===name)return c;return null;}
// ---- operator / console commands ----
function command(r,c,who,text,out){ // c = calling client (null = admin console)
 const parts=text.trim().replace(/^\//,'').split(/\s+/);const cmd=(parts[0]||'').toLowerCase();const a=parts.slice(1);
 const op=!c||isOp(r,c);const say=l=>{out(l);log('['+r.code+'] '+who+': /'+text.replace(/^\//,'')+' -> '+l);};
 if(cmd==='me'){bc(r,{t:'chat',name:'*',text:who+' '+a.join(' ')});return;}
 if(cmd==='tell'||cmd==='msg'||cmd==='w'){const t=findPlayer(r,a[0]);if(!t)return say('игрок не найден');tell(r,t.id,{t:'chat',name:who+' → тебе',text:a.slice(1).join(' ')});return say('→ '+t.name+': '+a.slice(1).join(' '));}
 if(cmd==='seed')return say('сид: '+r.seed);
 if(cmd==='save-all'||cmd==='save'){r.dirty=true;save(r);return say('мир сохранён');}
 if(cmd==='pardon'){if(!op)return say('нужны права оператора');const n=String(a[0]||'').toLowerCase();r.bans=r.bans.filter(x=>x!==n);r.blacklist=r.blacklist.filter(x=>x!==n);r.dirty=true;return say(n+' прощён');}
 if(cmd==='kill'){let t=c;if(a[0]){if(!op)return say('нужны права оператора');t=findPlayer(r,a[0]);}if(!t)return say('игрок не найден');tell(r,t.id,{t:'kill'});return say(t.name+' убит');}
 if(cmd==='clear'){let t=c;if(a[0]){if(!op)return say('нужны права оператора');t=findPlayer(r,a[0]);}if(!t)return say('игрок не найден');tell(r,t.id,{t:'clearinv'});return say('инвентарь '+t.name+' очищен');}
 if(cmd==='spawnpoint'){if(!c)return say('только из игры');tell(r,c.id,{t:'setspawn',x:c.x,y:c.y,z:c.z,personal:true});return say('личная точка появления установлена');}
 if(cmd==='reloadprops'){if(c)return say('только из панели');save(r);reloadProps(r);bc(r,{t:'mods',mods:r.mods});bc(r,{t:'pack',pack:r.pack});bc(r,{t:'plugins',plugins:r.plugins});bc(r,{t:'horror',horror:r.horror});bc(r,{t:'core',core:r.core});bc(r,{t:'info',name:r.name});for(const [id2,cl] of [...r.players]){const ln=cl.name.toLowerCase();if(r.bans.includes(ln)||r.blacklist.includes(ln)||(r.wlOn&&!r.whitelist.includes(ln)&&!r.ops.includes(ln))){tell(r,id2,{t:'closed',reason:'Тебе закрыт вход на этот сервер'});cl.ws.close(true);}}return say('настройки перечитаны');}
 if(cmd==='help'){say('все: /list /say /me /tell /seed /sleep /kill /clear /heal /fly /spawnpoint /sethome /home /wand /rg /clan /c /tpa /tpahere /tpaccept /tpdeny /back /spawn /rtp /afk /ping /playtime /rules /roll /coords /near /register /login /changepassword · op: /vanish /god /speed /sudo /setrules · op: /op /deop /kick /ban /pardon /unban /tp /give /gamemode /time set /weather /summon /setblock /fill /setworldspawn /setmax /public /private /name /plugins /reload /clearmobs /broadcast /motd /save-all /whitelist /blacklist /pvp on|off');if(r.core)say('плагин core: /stop /start /restart /horror enable|disable /run by|in|from … /whitelist /blacklist /plugins core on|off');return;}
 // ---- built-in server plugin "core" ----
 if(cmd==='plugins'&&a[0]==='authme'){if(!op)return say('нужны права оператора');return command(r,c,who,'/authme '+(a[1]==='off'?'off':'on'),out);}
 if(cmd==='plugins'&&a[0]==='core'){if(!op)return say('нужны права оператора');r.core=a[1]!=='off';r.dirty=true;bc(r,{t:'core',core:r.core});return say('плагин core '+(r.core?'включён':'выключен'));}
 if(['stop','start','restart','horror','run','broadcast','motd','weather','clearmobs'].includes(cmd)){
  if(!op)return say('нужны права оператора');
  if(['stop','start','restart','horror','run'].includes(cmd)&&!r.core)return say('плагин core выключен (/plugins core on)');
  if(cmd==='stop'){bc(r,{t:'closed',reason:'Сервер остановлен оператором'});r.dirty=true;save(r);for(const [,c] of r.players)c.ws.close(true);r.players.clear();r.owner=null;return say('сервер остановлен, мир сохранён');}
  if(cmd==='start'){r.stopped=false;return say('сервер запущен: игроки могут входить по адресу '+r.code);}
  if(cmd==='restart'){bc(r,{t:'restart'});r.dirty=true;save(r);return say('перезапуск: все игроки переподключаются');}
  if(cmd==='horror'){r.horror=a[0]==='enable'||a[0]==='on'||a[0]==='вкл';r.dirty=true;bc(r,{t:'horror',horror:r.horror});return say('хоррор '+(r.horror?'ВКЛЮЧЁН — Смотрящий проснулся':'выключен'));}
  if(cmd==='run'){ // /run by <игрок> <команда>  |  /run in <сервер> <команда>  |  /run from <игрок> <текст в чат>
   const mode=(a[0]||'').toLowerCase();const target=a[1];const rest=a.slice(2).join(' ');if(!mode||!target||!rest)return say('/run by <игрок> <команда> | /run in <сервер> <команда> | /run from <игрок> <текст>');
   if(mode==='by'){const t=findPlayer(r,target);if(!t)return say('игрок не найден');command(r,t,who+'→'+t.name,rest.startsWith('/')?rest:'/'+rest,out);return;}
   if(mode==='in'){const rr=[...rooms.values()].find(x=>x.code===target.toLowerCase()||x.name.toLowerCase()===target.toLowerCase());if(!rr)return say('сервер не найден');command(rr,null,who+'@'+r.code,rest.startsWith('/')?rest:'/'+rest,out);return;}
   if(mode==='from'){const t=findPlayer(r,target);bc(r,{t:'chat',name:t?t.name:target,text:rest});return say('отправлено от имени '+target);}
   return say('режим: by | in | from');}
  if(cmd==='broadcast'){bc(r,{t:'broadcast',text:a.join(' ')});return say('объявление показано всем');}
  if(cmd==='motd'){r.motd=a.join(' ').slice(0,120);r.dirty=true;return say('приветствие: '+r.motd);}
  if(cmd==='weather'){r.weather=a[0]||'clear';bc(r,{t:'weather',weather:r.weather});return say('погода: '+r.weather);}
  if(cmd==='clearmobs'){bc(r,{t:'clearmobs'});return say('мобы убраны');}
 }
 if(cmd==='register'||cmd==='reg'){if(!c)return say('только из игры');if(!r.authme)return say('AuthMe на этом сервере выключен');const k=c.name.toLowerCase();if(r.auth[k])return say('ты уже зарегистрирован — /login пароль');const pw=String(a[0]||'');if(pw.length<4)return say('/register пароль пароль (от 4 символов)');if(a[1]!=null&&a[1]!==pw)return say('пароли не совпадают');const salt=crypto.randomBytes(8).toString('hex');r.auth[k]={salt,hash:hashPw(pw,salt),at:Date.now()};r.dirty=true;c.authed=true;tell(r,c.id,{t:'authme',need:false});bc(r,{t:'pos',id:c.id,x:c.x,y:c.y,z:c.z,ry:c.ry,name:c.name,skin:c.skin},c.id);return say('AuthMe: зарегистрирован и вошёл. Приятной игры!');}
 if(cmd==='login'||cmd==='l'){if(!c)return say('только из игры');if(!r.authme)return say('AuthMe на этом сервере выключен');const k=c.name.toLowerCase();const rec=r.auth[k];if(!rec)return say('ты не зарегистрирован — /register пароль пароль');c.authTries=(c.authTries||0)+1;if(c.authTries>5){tell(r,c.id,{t:'closed',reason:'AuthMe: слишком много попыток'});c.ws.close(true);return;}if(rec.hash!==hashPw(String(a[0]||''),rec.salt))return say('неверный пароль ('+c.authTries+'/5)');c.authed=true;tell(r,c.id,{t:'authme',need:false});bc(r,{t:'pos',id:c.id,x:c.x,y:c.y,z:c.z,ry:c.ry,name:c.name,skin:c.skin},c.id);return say('AuthMe: вход выполнен');}
 if(cmd==='changepassword'||cmd==='changepw'){if(!c)return say('только из игры');const k=c.name.toLowerCase();const rec=r.auth[k];if(!rec)return say('ты не зарегистрирован');if(rec.hash!==hashPw(String(a[0]||''),rec.salt))return say('старый пароль неверный');if(String(a[1]||'').length<4)return say('/changepassword старый новый (от 4 символов)');rec.salt=crypto.randomBytes(8).toString('hex');rec.hash=hashPw(String(a[1]),rec.salt);r.dirty=true;return say('пароль изменён');}
 if(cmd==='authme'){if(!op)return say('нужны права оператора');const sub=(a[0]||'').toLowerCase();if(sub==='on'||sub==='off'){r.authme=sub==='on';r.dirty=true;if(!r.authme)for(const [,cl] of r.players)cl.authed=true;bc(r,{t:'authme_state',on:r.authme});return say('AuthMe '+(r.authme?'включён: игроки должны /register и /login':'выключен'));}
  if(sub==='unregister'){const n=String(a[1]||'').toLowerCase();if(!r.auth[n])return say('нет такой записи');delete r.auth[n];r.dirty=true;return say(n+' удалён из AuthMe');}
  if(sub==='list')return say('AuthMe ('+(r.authme?'вкл':'выкл')+'): '+(Object.keys(r.auth).join(', ')||'никто'));
  return say('/authme on|off · /authme unregister имя · /authme list');}
 if(cmd==='tpa'||cmd==='tpahere'){if(!c)return say('только из игры');const t=findPlayer(r,a[0]);if(!t||t===c)return say('игрок не найден');t.tpreq={from:c.id,here:cmd==='tpahere',at:Date.now()};tell(r,t.id,{t:'chat',name:'*',text:c.name+(cmd==='tpahere'?' зовёт тебя к себе':' хочет телепортироваться к тебе')+'. /tpaccept — принять, /tpdeny — отклонить (60 с)'});return say('запрос отправлен '+t.name);}
 if(cmd==='tpaccept'){if(!c)return say('только из игры');const q=c.tpreq;if(!q||Date.now()-q.at>60000)return say('нет запросов');const f=r.players.get(q.from);c.tpreq=null;if(!f)return say('игрок вышел');if(q.here){c.back={x:c.x,y:c.y,z:c.z};tell(r,c.id,{t:'tp',x:f.x,y:f.y,z:f.z});}else{f.back={x:f.x,y:f.y,z:f.z};tell(r,f.id,{t:'tp',x:c.x,y:c.y,z:c.z});}tell(r,f.id,{t:'console',text:c.name+' принял телепорт'});return say('телепорт выполнен');}
 if(cmd==='tpdeny'){if(!c)return say('только из игры');const q=c.tpreq;c.tpreq=null;if(q){const f=r.players.get(q.from);if(f)tell(r,f.id,{t:'console',text:c.name+' отклонил телепорт'});}return say('отклонено');}
 if(cmd==='back'){if(!c)return say('только из игры');const b=c.back;if(!b)return say('некуда возвращаться');c.back={x:c.x,y:c.y,z:c.z};tell(r,c.id,{t:'tp',x:b.x,y:b.y,z:b.z});return say('назад');}
 if(cmd==='spawn'&&!a[0]){if(!c)return say('только из игры');const sp=r.spawn||{x:0,y:40,z:0};c.back={x:c.x,y:c.y,z:c.z};tell(r,c.id,{t:'tp',x:sp.x,y:sp.y,z:sp.z});return say('на спавн');}
 if(cmd==='rtp'){if(!c)return say('только из игры');const now=Date.now();if(c.rtpAt&&now-c.rtpAt<30000)return say('подожди '+Math.ceil((30000-(now-c.rtpAt))/1000)+' с');c.rtpAt=now;const x=Math.floor(Math.random()*2000-1000),z=Math.floor(Math.random()*2000-1000);c.back={x:c.x,y:c.y,z:c.z};tell(r,c.id,{t:'rtp',x,z});return say('случайный телепорт: '+x+' '+z);}
 if(cmd==='afk'){if(!c)return say('только из игры');c.afk=!c.afk;bc(r,{t:'chat',name:'*',text:c.name+(c.afk?' отошёл (AFK)':' вернулся')});return;}
 if(cmd==='ping'){if(!c)return say('pong');tell(r,c.id,{t:'ping',at:Date.now()});return;}
 if(cmd==='playtime'){if(!c)return say('только из игры');const m=Math.floor((Date.now()-(c.joinedAt||Date.now()))/60000);return say('на сервере в этой сессии: '+Math.floor(m/60)+' ч '+(m%60)+' мин');}
 if(cmd==='rules'){return say('Правила сервера: '+(r.rules||'не заданы (op: /setrules текст)'));}
 if(cmd==='setrules'){if(!op)return say('нужны права оператора');r.rules=a.join(' ').slice(0,300);r.props=r.props||{};r.props.rules=r.rules;r.dirty=true;return say('правила: '+r.rules);}
 if(cmd==='roll'){const m=Math.max(2,Math.min(1000,+a[0]||6));bc(r,{t:'chat',name:'*',text:who+' бросил кубик d'+m+': '+(1+Math.floor(Math.random()*m))});return;}
 if(cmd==='coords'){if(!c)return say('только из игры');bc(r,{t:'chat',name:c.name,text:'я тут: '+Math.round(c.x)+' '+Math.round(c.y)+' '+Math.round(c.z)});return;}
 if(cmd==='near'){if(!c)return say('только из игры');const ls=[...r.players.values()].filter(x=>x!==c&&!x.vanish).map(x=>({n:x.name,d:Math.hypot(x.x-c.x,x.z-c.z)})).sort((a,b)=>a.d-b.d).slice(0,5);return say(ls.length?'рядом: '+ls.map(x=>x.n+' ('+Math.round(x.d)+' бл.)').join(', '):'рядом никого');}
 if(cmd==='vanish'){if(!op)return say('нужны права оператора');if(!c)return say('только из игры');c.vanish=!c.vanish;if(c.vanish)bc(r,{t:'left',id:c.id},c.id);return say(c.vanish?'ты невидим для других':'ты снова видим');}
 if(cmd==='god'){if(!op)return say('нужны права оператора');const t=a[0]?findPlayer(r,a[0]):c;if(!t)return say('игрок не найден');t.god=!t.god;tell(r,t.id,{t:'god',on:t.god});return say('режим бога '+(t.god?'включён':'выключен')+' для '+t.name);}
 if(cmd==='speed'){if(!op)return say('нужны права оператора');const v=Math.max(0.5,Math.min(5,+a[0]||1));const t=a[1]?findPlayer(r,a[1]):c;if(!t)return say('игрок не найден');tell(r,t.id,{t:'speed',v});return say('скорость '+v+' для '+t.name);}
 if(cmd==='sudo'){if(!op)return say('нужны права оператора');const t=findPlayer(r,a[0]);if(!t)return say('игрок не найден');command(r,t,t.name,'/'+a.slice(1).join(' '),l=>say('['+t.name+'] '+l));return;}
 if(cmd==='sethome'){if(!c)return say('только из игры');r.homes[c.name.toLowerCase()]={x:+c.x.toFixed(1),y:+c.y.toFixed(1),z:+c.z.toFixed(1)};r.dirty=true;return say('дом установлен: '+(c.x|0)+' '+(c.y|0)+' '+(c.z|0));}
 if(cmd==='home'){if(!c)return say('только из игры');const h=r.homes[c.name.toLowerCase()];if(!h)return say('дом не установлен — /sethome');tell(r,c.id,{t:'tp',x:h.x,y:h.y,z:h.z});return say('дома');}
 if(cmd==='delhome'){if(!c)return say('только из игры');delete r.homes[c.name.toLowerCase()];r.dirty=true;return say('дом удалён');}
 if(cmd==='wand'){if(!c)return say('только из игры');tell(r,c.id,{t:'give',item:'Жезл региона',n:1});return say('жезл выдан: ЛКМ — первая точка, ПКМ — вторая, затем /rg claim имя');}
 if(cmd==='rg'||cmd==='region'){if(!c)return say('только из игры');const sub=(a[0]||'help').toLowerCase();const me_=c.name.toLowerCase();
  if(sub==='claim'){const nm=String(a[1]||'').toLowerCase().replace(/[^a-z0-9_\-]/g,'').slice(0,16);if(!nm)return say('/rg claim имя (сначала /wand и выделить 2 точки)');if(r.regions.find(g=>g.name===nm))return say('регион с таким именем уже есть');
   const v=a.slice(2,8).map(Number);if(v.length<6||v.some(isNaN))return say('сначала выдели две точки жезлом (/wand)');
   const g={name:nm,owner:me_,members:[],x1:Math.min(v[0],v[3]),y1:0,z1:Math.min(v[2],v[5]),x2:Math.max(v[0],v[3]),y2:63,z2:Math.max(v[2],v[5]),pvp:true,created:Date.now()};
   const area=(g.x2-g.x1+1)*(g.z2-g.z1+1);const mine=r.regions.filter(x=>x.owner===me_);
   if(!op){if(area>10000)return say('слишком большой регион ('+area+' блоков, максимум 10000)');if(mine.length>=5)return say('максимум 5 регионов на игрока');}
   const o=r.regions.find(x=>overlaps(x,g)&&x.owner!==me_);if(o&&!op)return say('пересекается с регионом «'+o.name+'» игрока '+o.owner);
   r.regions.push(g);r.dirty=true;bc(r,{t:'regions',regions:r.regions});return say('регион «'+nm+'» создан: '+area+' блоков ('+g.x1+','+g.z1+' — '+g.x2+','+g.z2+'), вся высота');}
  if(sub==='remove'||sub==='delete'){const nm=String(a[1]||'').toLowerCase();const g=r.regions.find(x=>x.name===nm);if(!g)return say('регион не найден');if(g.owner!==me_&&!op)return say('это не твой регион');r.regions=r.regions.filter(x=>x!==g);r.dirty=true;bc(r,{t:'regions',regions:r.regions});return say('регион «'+nm+'» удалён');}
  if(sub==='addmember'||sub==='add'){const nm=String(a[1]||'').toLowerCase(),pl=String(a[2]||'').toLowerCase();const g=r.regions.find(x=>x.name===nm);if(!g)return say('регион не найден');if(g.owner!==me_&&!op)return say('это не твой регион');if(!pl)return say('/rg addmember регион игрок');if(!g.members.includes(pl))g.members.push(pl);r.dirty=true;bc(r,{t:'regions',regions:r.regions});return say(pl+' добавлен в регион «'+nm+'»');}
  if(sub==='removemember'||sub==='rem'){const nm=String(a[1]||'').toLowerCase(),pl=String(a[2]||'').toLowerCase();const g=r.regions.find(x=>x.name===nm);if(!g)return say('регион не найден');if(g.owner!==me_&&!op)return say('это не твой регион');g.members=g.members.filter(x=>x!==pl);r.dirty=true;bc(r,{t:'regions',regions:r.regions});return say(pl+' убран из региона «'+nm+'»');}
  if(sub==='flag'){const nm=String(a[1]||'').toLowerCase();const g=r.regions.find(x=>x.name===nm);if(!g)return say('регион не найден');if(g.owner!==me_&&!op)return say('это не твой регион');if(a[2]==='pvp'){g.pvp=a[3]!=='off'&&a[3]!=='deny';r.dirty=true;bc(r,{t:'regions',regions:r.regions});return say('pvp в «'+nm+'»: '+(g.pvp?'разрешено':'запрещено'));}return say('/rg flag регион pvp on|off');}
  if(sub==='info'){const g=a[1]?r.regions.find(x=>x.name===String(a[1]).toLowerCase()):regionAt(r,Math.floor(c.x),Math.floor(c.y),Math.floor(c.z));if(!g)return say('здесь нет региона');return say('регион «'+g.name+'»: владелец '+g.owner+', участники: '+(g.members.join(', ')||'нет')+', '+g.x1+','+g.z1+' — '+g.x2+','+g.z2+', pvp '+(g.pvp!==false?'on':'off'));}
  if(sub==='list'){const ls=op?r.regions:r.regions.filter(x=>x.owner===me_||x.members.includes(me_));return say('регионы: '+(ls.map(x=>x.name+' ('+x.owner+')').join(', ')||'нет'));}
  return say('/rg claim имя · /rg remove имя · /rg addmember имя игрок · /rg removemember имя игрок · /rg info · /rg list · /rg flag имя pvp on|off');}
 if(cmd==='clan'||cmd==='c'){if(!c)return say('только из игры');const me_=c.name.toLowerCase();const my=clanOf(me_);
  if(cmd==='c'||a[0]==='chat'){const txt=(cmd==='c'?a:a.slice(1)).join(' ').slice(0,200);if(!my)return say('ты не в клане');if(!txt)return say('/c текст');for(const [id2,cl] of r.players)if(my.members.includes(cl.name.toLowerCase()))tell(r,id2,{t:'chat',name:'[клан '+my.tag+'] '+c.name,text:txt});return;}
  const sub=(a[0]||'help').toLowerCase();
  if(sub==='create'){const nm=String(a[1]||'').replace(/[^A-Za-z0-9_]/g,'').slice(0,12);if(nm.length<2)return say('/clan create Имя (латиница, 2–12)');if(my)return say('ты уже в клане '+my.tag);if(clans[nm.toLowerCase()])return say('клан с таким именем уже есть');clans[nm.toLowerCase()]={tag:nm,leader:me_,members:[me_],invites:[],created:Date.now()};saveClans();bcClans(r);return say('клан «'+nm+'» создан. Приглашай: /clan invite игрок');}
  if(sub==='invite'){if(!my)return say('ты не в клане');if(my.leader!==me_)return say('только лидер клана');const pl=String(a[1]||'').toLowerCase();if(!pl)return say('/clan invite игрок');if(clanOf(pl))return say(pl+' уже в клане');if(!my.invites.includes(pl))my.invites.push(pl);saveClans();const t=findPlayer(r,pl);if(t)tell(r,t.id,{t:'chat',name:'*',text:c.name+' приглашает тебя в клан «'+my.tag+'». Прими: /clan accept '+my.tag});return say('приглашение отправлено '+pl);}
  if(sub==='accept'){if(my)return say('ты уже в клане '+my.tag);const k=String(a[1]||'').toLowerCase();let cl=clans[k];if(!cl){for(const kk in clans)if(clans[kk].invites.includes(me_)){cl=clans[kk];break;}}if(!cl||!cl.invites.includes(me_))return say('нет приглашения');cl.invites=cl.invites.filter(x=>x!==me_);cl.members.push(me_);saveClans();bcClans(r);for(const [id2,cc] of r.players)if(cl.members.includes(cc.name.toLowerCase()))tell(r,id2,{t:'chat',name:'*',text:c.name+' вступил в клан «'+cl.tag+'»'});return say('ты в клане «'+cl.tag+'»');}
  if(sub==='leave'){if(!my)return say('ты не в клане');my.members=my.members.filter(x=>x!==me_);if(my.leader===me_){if(my.members.length)my.leader=my.members[0];else delete clans[my.tag.toLowerCase()];}saveClans();bcClans(r);return say('ты вышел из клана');}
  if(sub==='kick'){if(!my)return say('ты не в клане');if(my.leader!==me_)return say('только лидер клана');const pl=String(a[1]||'').toLowerCase();if(pl===me_)return say('используй /clan leave');my.members=my.members.filter(x=>x!==pl);saveClans();bcClans(r);return say(pl+' исключён из клана');}
  if(sub==='info'){const cl=a[1]?clans[String(a[1]).toLowerCase()]:my;if(!cl)return say('клан не найден (ты не в клане)');return say('клан «'+cl.tag+'»: лидер '+cl.leader+', участники ('+cl.members.length+'): '+cl.members.join(', '));}
  if(sub==='list')return say('кланы: '+(Object.values(clans).map(x=>x.tag+' ('+x.members.length+')').join(', ')||'нет'));
  if(sub==='disband'){if(!my)return say('ты не в клане');if(my.leader!==me_&&!op)return say('только лидер клана');delete clans[my.tag.toLowerCase()];saveClans();bcClans(r);return say('клан распущен');}
  return say('/clan create Имя · invite игрок · accept [Имя] · leave · kick игрок · info [Имя] · list · disband · /c текст — чат клана');}
 if(cmd==='pvp'){if(!op)return say('нужны права оператора');r.pvp=a[0]!=='off';r.dirty=true;bc(r,{t:'pvp',pvp:r.pvp});return say('pvp на сервере '+(r.pvp?'включено':'выключено'));}
 if(!op&&!['help','list','me','tell','msg','w','seed','sleep','kill','clear','spawnpoint','heal','fly','save-all','save'].includes(cmd))return say('команды доступны только операторам');
 if(cmd==='list')return say('игроки ('+r.players.size+'/'+r.max+'): '+[...r.players.values()].map(p=>p.name+(isOp(r,p)?'*':'')).join(', '));
 if(cmd==='say')return bc(r,{t:'chat',name:'[сервер]',text:a.join(' ')});
 if(cmd==='sleep'){r.time=40;bc(r,{t:'settime',time:40});return say('утро');}
 if(!op)return say('нужны права оператора');
 if(cmd==='op'){const n=a.join(' ').toLowerCase();if(!n)return say('/op имя');if(!r.ops.includes(n))r.ops.push(n);r.dirty=true;const t=findPlayer(r,n);if(t)tell(r,t.id,{t:'op',op:true});return say(n+' теперь оператор');}
 if(cmd==='deop'){const n=a.join(' ').toLowerCase();r.ops=r.ops.filter(x=>x!==n);r.dirty=true;const t=findPlayer(r,n);if(t)tell(r,t.id,{t:'op',op:false});return say(n+' больше не оператор');}
 if(cmd==='kick'){const t=findPlayer(r,a[0]);if(!t)return say('игрок не найден');tell(r,t.id,{t:'closed',reason:'Тебя выгнали'+(a[1]?': '+a.slice(1).join(' '):'')});t.ws.close(true);return say(t.name+' выгнан');}
 if(cmd==='ban'){const n=String(a[0]||'').toLowerCase();if(!n)return say('/ban имя');if(!r.bans.includes(n))r.bans.push(n);r.dirty=true;const t=findPlayer(r,n);if(t){tell(r,t.id,{t:'closed',reason:'Ты забанен'});t.ws.close(true);}return say(n+' забанен');}
 if(cmd==='whitelist'){const sub=(a[0]||'list').toLowerCase();if(sub==='on'){r.wlOn=true;}else if(sub==='off'){r.wlOn=false;}else if(sub==='add'&&a[1]){const n=a[1].toLowerCase();if(!r.whitelist.includes(n))r.whitelist.push(n);}else if(sub==='remove'&&a[1]){r.whitelist=r.whitelist.filter(x=>x!==a[1].toLowerCase());}r.dirty=true;return say('белый список '+(r.wlOn?'включён':'выключен')+': '+(r.whitelist.join(', ')||'пусто'));}
 if(cmd==='blacklist'){const sub=(a[0]||'list').toLowerCase();if(sub==='add'&&a[1]){const n=a[1].toLowerCase();if(!r.blacklist.includes(n))r.blacklist.push(n);const t=findPlayer(r,n);if(t){tell(r,t.id,{t:'closed',reason:'Ты в чёрном списке'});t.ws.close(true);}}else if(sub==='remove'&&a[1]){r.blacklist=r.blacklist.filter(x=>x!==a[1].toLowerCase());}r.dirty=true;return say('чёрный список: '+(r.blacklist.join(', ')||'пусто'));}
 if(cmd==='unban'){const n=String(a[0]||'').toLowerCase();r.bans=r.bans.filter(x=>x!==n);r.dirty=true;return say(n+' разбанен');}
 if(cmd==='tp'){ // /tp x y z | /tp игрок | /tp кто куда
  if(a.length>=3&&!isNaN(+a[0])){const tgt=c||[...r.players.values()][0];if(tgt)tell(r,tgt.id,{t:'tp',x:+a[0],y:+a[1],z:+a[2]});return say('телепорт');}
  if(a.length===1){const t=findPlayer(r,a[0]);if(!t||!c)return say('игрок не найден');tell(r,c.id,{t:'tp',x:t.x,y:t.y,z:t.z});return say('к '+t.name);}
  if(a.length===2){const w=findPlayer(r,a[0]),t=findPlayer(r,a[1]);if(!w||!t)return say('игрок не найден');tell(r,w.id,{t:'tp',x:t.x,y:t.y,z:t.z});return say(w.name+' → '+t.name);}
  return say('/tp x y z | /tp игрок | /tp кто куда');}
 if(cmd==='give'){ // /give [игрок] предмет [n]
  let t=c,rest=a;if(a.length&&findPlayer(r,a[0])){t=findPlayer(r,a[0]);rest=a.slice(1);}if(!t)return say('кому?');const n=rest.length>1&&!isNaN(+rest[rest.length-1])?+rest.pop():1;tell(r,t.id,{t:'give',item:rest.join(' '),n});return say('выдано '+t.name+': '+rest.join(' ')+' ×'+n);}
 if(cmd==='time'){if(a[0]==='set'||a[0]==='add')a.shift();const v=a[0]==='day'||a[0]==='день'?40:a[0]==='night'||a[0]==='ночь'?260:a[0]==='noon'?100:a[0]==='midnight'?300:+a[0];if(isNaN(v))return say('/time day|night|секунды');r.time=v;bc(r,{t:'settime',time:v});return say('время: '+v);}
 if(cmd==='gamemode'||cmd==='gm'){ // /gamemode [игрок] creative|survival
  let t=c,mode=a[0];if(a.length>=2){t=findPlayer(r,a[0]);mode=a[1];}if(!t)return say('игрок не найден');mode=/^(creative|c|1)$/i.test(mode||'')?'creative':'survival';tell(r,t.id,{t:'gamemode',mode});return say(t.name+': режим '+mode);}
 if(cmd==='teleport'){return command(r,c,who,'/tp '+a.join(' '),out);}
 if(cmd==='xp'||cmd==='effect'||cmd==='difficulty'){return say('в loopcraft нет опыта/эффектов — команда принята для совместимости');}
 if(cmd==='summon'){const t=c||[...r.players.values()][0];if(!t)return say('никого нет');tell(r,t.id,{t:'spawn',mob:a[0]||'klyk',n:+a[1]||1});return say('summon '+(a[0]||'klyk'));}
 if(cmd==='setblock'){if(a.length<4)return say('/setblock x y z блок');const t=c||[...r.players.values()][0];if(!t)return say('никого нет');tell(r,t.id,{t:'setblock',x:+a[0],y:+a[1],z:+a[2],block:a.slice(3).join(' ')});return say('setblock');}
 if(cmd==='fill'){if(a.length<7)return say('/fill x1 y1 z1 x2 y2 z2 блок');const t=c||[...r.players.values()][0];if(!t)return say('никого нет');tell(r,t.id,{t:'fill',a:[+a[0],+a[1],+a[2]],b:[+a[3],+a[4],+a[5]],block:a.slice(6).join(' ')});return say('fill');}
 if(cmd==='setworldspawn'){if(!c)return say('только из игры');r.spawn={x:c.x,y:c.y,z:c.z};r.dirty=true;bc(r,{t:'setspawn',x:c.x,y:c.y,z:c.z});return say('точка появления мира: '+c.x.toFixed(0)+' '+c.y.toFixed(0)+' '+c.z.toFixed(0));}
 if(cmd==='heal'){let t=c;if(a[0])t=findPlayer(r,a[0]);if(!t)return say('игрок не найден');tell(r,t.id,{t:'heal'});return say(t.name+' вылечен');}
 if(cmd==='fly'){let t=c;if(a[0])t=findPlayer(r,a[0]);if(!t)return say('игрок не найден');tell(r,t.id,{t:'fly'});return say('полёт переключён: '+t.name);}
 if(cmd==='spawn'){const t=c||[...r.players.values()][0];if(!t)return say('никого нет');tell(r,t.id,{t:'spawn',mob:a[0]||'klyk',n:+a[1]||1});return say('спавн '+a[0]);}
 if(cmd==='setmax'){r.max=Math.max(1,Math.min(64,+a[0]||16));r.dirty=true;return say('лимит: '+r.max);}
 if(cmd==='public'){r.public=true;r.dirty=true;return say('сервер виден в списке');}
 if(cmd==='private'){r.public=false;r.dirty=true;return say('сервер скрыт из списка');}
 if(cmd==='name'){r.name=a.join(' ').slice(0,32)||r.code;r.dirty=true;bc(r,{t:'info',name:r.name});return say('имя сервера: '+r.name);}
 if(cmd==='plugins')return say('плагины: '+(r.plugins.join(', ')||'нет'));
 if(cmd==='reload'){bc(r,{t:'plugins',plugins:r.plugins});return say('плагины перезапущены');}
 say('неизвестная команда: '+cmd);
}

/* ================= tiny dependency-free WebSocket (RFC 6455) ================= */
class MiniWS{constructor(sock){this.sock=sock;this.readyState=1;this.buf=Buffer.alloc(0);this.onmessage=null;this.onclose=null;
 sock.on('data',d=>{this.buf=Buffer.concat([this.buf,d]);this.parse();});sock.on('close',()=>this.close(false));sock.on('error',()=>this.close(false));}
 parse(){for(;;){const b=this.buf;if(b.length<2)return;const fin=b[0]&0x80,op=b[0]&0x0f,masked=b[1]&0x80;let len=b[1]&0x7f,off=2;
  if(len===126){if(b.length<4)return;len=b.readUInt16BE(2);off=4;}else if(len===127){if(b.length<10)return;len=Number(b.readBigUInt64BE(2));off=10;}
  if(masked)off+=4;if(len>4e6){this.close(true);return;}if(b.length<off+len)return;let data=b.slice(off,off+len);
  if(masked){const m=b.slice(off-4,off);data=Buffer.from(data);for(let i=0;i<data.length;i++)data[i]^=m[i&3];}
  this.buf=b.slice(off+len);
  if(op===8){this.close(true);return;}if(op===9){this.frame(0x8a,data);continue;}if(op===1&&fin&&this.onmessage)this.onmessage(data.toString('utf8'));}}
 frame(op,data){const l=data.length;let h;if(l<126)h=Buffer.from([op,l]);else if(l<65536){h=Buffer.alloc(4);h[0]=op;h[1]=126;h.writeUInt16BE(l,2);}else{h=Buffer.alloc(10);h[0]=op;h[1]=127;h.writeBigUInt64BE(BigInt(l),2);}try{this.sock.write(Buffer.concat([h,data]));}catch(e){}}
 send(s){if(this.readyState===1)this.frame(0x81,Buffer.from(String(s),'utf8'));}
 close(send){if(this.readyState!==1)return;this.readyState=3;if(send)try{this.frame(0x88,Buffer.alloc(0));}catch(e){}try{this.sock.end();}catch(e){}if(this.onclose)this.onclose();}}
server.on('upgrade',(req,sock)=>{const p=url.parse(req.url).pathname;const key=req.headers['sec-websocket-key'];
 if(p!=='/ws'||!key){sock.end('HTTP/1.1 400 Bad Request\r\n\r\n');return;}
 const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
 sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');
 sock.setNoDelay(true);onConnection(new MiniWS(sock));});

/* ================= connections ================= */
function onConnection(ws){let r=null,id=nextId++,me=null;
 ws.onmessage=raw=>{let m;try{m=JSON.parse(raw);}catch(e){return;}if(!m||typeof m.t!=='string')return;
  if(m.t==='join'){const code=String(m.room||'').toLowerCase().trim();const name=String(m.name||'Player').slice(0,16)||'Player';const lname=name.toLowerCase();
   if(!/^[A-Za-z0-9_]{3,16}$/.test(name)){ws.send(JSON.stringify({t:'closed',reason:'Имя должно быть на английском: буквы, цифры, _ (3–16)'}));ws.close(true);return;}
   if(!CODE_RE.test(code)){ws.send(JSON.stringify({t:'closed',reason:'Неверный адрес сервера: латиница, цифры, - и _, 3–24 символа'}));ws.close(true);return;}
   const owner=m.token?sessions.get(String(m.token)):null;if(!owner){ws.send(JSON.stringify({t:'closed',reason:'Для игры на серверах нужен аккаунт'}));ws.close(true);return;}if(owner!==lname){ws.send(JSON.stringify({t:'closed',reason:'Имя не совпадает с аккаунтом'}));ws.close(true);return;}if(ACC[lname]&&owner!==lname){ws.send(JSON.stringify({t:'closed',reason:'Имя '+name+' зарегистрировано — войди в аккаунт'}));ws.close(true);return;}
   if((fs.existsSync(path.join(DATA,'closed'))||fs.existsSync(path.join(DATA,'tehnicalwork')))&&!isSuper(lname)){ws.send(JSON.stringify({t:'closed',reason:'ERR_GAME_CLOSED: технические работы'}));ws.close(true);return;}
   if(ACC[lname]&&ACC[lname].banned){ws.send(JSON.stringify({t:'closed',reason:'Аккаунт забанен'+(ACC[lname].banReason?': '+ACC[lname].banReason:'')}));ws.close(true);return;}
   let rr=room(code);
   if(!rr){if(!m.create){ws.send(JSON.stringify({t:'closed',reason:'Сервера '+code+' не существует'}));ws.close(true);return;}
    createServer(code,{name:m.serverName,max:m.max,public:m.public,panelPw:m.panelPw,owner:name});rr=room(code);}
   if(rr.bans.includes(lname)||rr.blacklist.includes(lname)){ws.send(JSON.stringify({t:'closed',reason:'Тебе закрыт вход на этот сервер'}));ws.close(true);return;}
   if(rr.wlOn&&!rr.whitelist.includes(lname)&&!rr.ops.includes(lname)&&(rr.ownerName||'').toLowerCase()!==lname){ws.send(JSON.stringify({t:'closed',reason:'Сервер по белому списку — тебя в нём нет'}));ws.close(true);return;}
   if(rr.players.size>=rr.max){ws.send(JSON.stringify({t:'closed',reason:'Сервер полон ('+rr.max+')'}));ws.close(true);return;}
   {const old=findPlayer(rr,name);if(old){ // тот же аккаунт входит снова — вытесняем старую сессию
    try{old.ws.send(JSON.stringify({t:'closed',reason:'Ты вошёл с другого окна'}));}catch(e){}rr.players.delete(old.id);if(rr.owner===old.id)rr.owner=null;try{old.ws.onclose=null;old.ws.close(true);}catch(e){}bc(rr,{t:'left',id:old.id});}}
   r=rr;me={id,ws,name,x:0,y:0,z:0,ry:0,skin:null};
   if(r.players.size===0)reloadProps(r);if(!r.ownerName){r.ownerName=name;r.dirty=true;}if((r.ownerName||'').toLowerCase()===lname)r.owner=id;
   r.players.set(id,me);log('['+r.code+'] '+name+' joined ('+r.players.size+')');
   ws.send(JSON.stringify({t:'welcome',id,owner:r.owner===id,op:isOp(r,me),seed:r.seed,name:r.name,edits:r.edits,mods:r.mods,pack:r.pack,plugins:r.plugins,time:r.time,horror:r.horror,core:r.core,authme:!!r.authme,authed:!(r.authme&&!me.authed),motd:r.motd||'',weather:r.weather||'clear',spawn:r.spawn||null,last:r.lastpos[lname]||null,chests:r.chests||{},regions:r.regions,pvp:r.pvp,clans:clanMap(r),players:[...r.players].filter(([i])=>i!==id).map(([i,c])=>({id:i,name:c.name,x:c.x,y:c.y,z:c.z,ry:c.ry,skin:c.skin}))}));
   me.joinedAt=Date.now();me.authed=!r.authme;if(r.authme&&NOAUTH&&m.noauth&&String(m.noauth)===NOAUTH){me.authed=true;log('['+r.code+'] '+name+' joined via noauth link');tell(r,id,{t:'authme',need:false});tell(r,id,{t:'console',text:'Секретная ссылка: AuthMe пропущен.'});}
   if(r.authme&&!me.authed){const reg=!!r.auth[lname];tell(r,id,{t:'authme',need:true,registered:reg});tell(r,id,{t:'console',text:reg?'AuthMe: войди — /login пароль':'AuthMe: зарегистрируйся — /register пароль пароль'});}bc(r,{t:'joined',id,name},id);bcClans(r);if(ACC[lname]&&(ACC[lname].warns||[]).length)tell(r,id,{t:'console',text:'У тебя '+ACC[lname].warns.length+'/3 предупреждений: '+ACC[lname].warns.map(w=>w.text).join('; ')});return;}
  if(!r||!me)return;
  if(r.authme&&!me.authed){if(m.t==='chat'){const t=String(m.text||'');const c0=t.split(/\s+/)[0].toLowerCase();if(['/register','/login','/reg','/l'].includes(c0)){command(r,me,me.name,t,l=>tell(r,id,{t:'console',text:l}));save(r);}else tell(r,id,{t:'console',text:'AuthMe: сначала /login пароль или /register пароль пароль'});}return;}
  if(m.t==='pos'){me.x=+m.x||0;me.y=+m.y||0;me.z=+m.z||0;me.ry=+m.ry||0;if(me.vanish)return;if(!me._lp||Date.now()-me._lp>5000){me._lp=Date.now();r.lastpos[me.name.toLowerCase()]={x:me.x,y:me.y,z:me.z,ry:me.ry,at:Date.now()};r.dirty=true;}if(m.skin!==undefined)me.skin=m.skin?String(m.skin).slice(0,200):null;bc(r,{t:'pos',id,x:me.x,y:me.y,z:me.z,ry:me.ry,name:me.name,skin:me.skin},id);}
  else if(m.t==='block'){const x=m.x|0,y=m.y|0,z=m.z|0;if(!canBuild(r,me,x,y,z)){const g=regionAt(r,x,y,z);tell(r,id,{t:'protect',x,y,z,v:r.edits[x+','+y+','+z],name:g?g.name:'',owner:g?g.owner:''});return;}const k=x+','+y+','+z;r.edits[k]=m.v|0;r.dirty=true;bc(r,{t:'block',x,y,z,v:m.v|0},id);}
  else if(m.t==='chest'){const k=String(m.k||'');if(!/^-?\d+,-?\d+,-?\d+$/.test(k))return;if(m.items===null)delete r.chests[k];else if(Array.isArray(m.items))r.chests[k]=m.items.slice(0,27).map(s=>Array.isArray(s)&&s[0]!=null?[String(s[0]).slice(0,40),Math.max(1,Math.min(999,s[1]|0))]:null);r.dirty=true;bc(r,{t:'chest',k,items:r.chests[k]===undefined?null:r.chests[k]},id);}
  else if(m.t==='hit'){if(!r.pvp)return;const t=r.players.get(+m.id);if(!t||t===me)return;const d=Math.hypot(t.x-me.x,t.y-me.y,t.z-me.z);if(d>6)return;const g1=regionAt(r,Math.floor(t.x),Math.floor(t.y),Math.floor(t.z)),g2=regionAt(r,Math.floor(me.x),Math.floor(me.y),Math.floor(me.z));if((g1&&g1.pvp===false)||(g2&&g2.pvp===false))return tell(r,id,{t:'console',text:'здесь pvp запрещено'});const now=Date.now();if(me.lastHit&&now-me.lastHit<300)return;me.lastHit=now;const dmg=Math.max(1,Math.min(10,+m.dmg||1));tell(r,t.id,{t:'hurt',from:me.name,fromId:id,dmg,x:me.x,y:me.y,z:me.z});}
  else if(m.t==='chat'){const text=String(m.text||'').slice(0,200);if(text.startsWith('/')){command(r,me,me.name,text,l=>tell(r,id,{t:'console',text:l}));save(r);return;}bc(r,{t:'chat',id,name:me.name,text});}
  else if(m.t==='mods'){if(!isOp(r,me))return tell(r,id,{t:'console',text:'менять моды могут только операторы'});if(Array.isArray(m.mods)){r.mods=m.mods.map(String).slice(0,50);r.dirty=true;bc(r,{t:'mods',mods:r.mods});}}
  else if(m.t==='pack'){if(!isOp(r,me))return tell(r,id,{t:'console',text:'менять пак могут только операторы'});r.pack=m.pack?String(m.pack).slice(0,200):null;r.dirty=true;bc(r,{t:'pack',pack:r.pack});}
  else if(m.t==='plugins'){if(!isOp(r,me))return tell(r,id,{t:'console',text:'менять плагины могут только операторы'});if(Array.isArray(m.plugins)){r.plugins=m.plugins.map(String).slice(0,50);r.dirty=true;bc(r,{t:'plugins',plugins:r.plugins});}}
  else if(m.t==='settime'){if(!isOp(r,me))return;r.time=+m.time||0;bc(r,{t:'settime',time:r.time},id);}
  else if(m.t==='rtc'){const to=r.players.get(+m.to);if(to&&to.ws.readyState===1)to.ws.send(JSON.stringify({t:'rtc',from:id,data:m.data}));}
  else if(m.t==='event'){bc(r,{t:'event',id,name:m.name,data:m.data},id);}
  else if(m.t==='plugin'){ // plugin (runs on owner's client) asks the server to act
   if(r.owner!==id)return;if(m.cmd)command(r,me,'[plugin]',String(m.cmd),l=>tell(r,id,{t:'console',text:l}));}
 };
 ws.onclose=()=>{if(r&&me){if(me.x||me.z){r.lastpos[me.name.toLowerCase()]={x:me.x,y:me.y,z:me.z,ry:me.ry,at:Date.now()};r.dirty=true;}r.players.delete(id);log('['+r.code+'] '+me.name+' left');
   if(r.owner===id){r.owner=null;bc(r,{t:'chat',name:'[сервер]',text:'Создатель вышел, сервер продолжает работать.'});}
   bc(r,{t:'left',id});save(r);}};
}
for(const c of allServerCodes())room(c);
server.listen(PORT,'0.0.0.0',()=>{log('loopcraft server on port '+PORT+' (all interfaces)');if(ADMIN.password)log('hosting admin login enabled (data/admin.json)');});
