<?php
// loopcraft — Сетевая игра. Создатель: Winnigames2024
$PAGE='multi';
require __DIR__.'/index.php';
