<?php
// loopcraft — Одиночная игра. Создатель: Winnigames2024
$PAGE='single';
require __DIR__.'/index.php';
